Clazz.declarePackage ("J.awtjs.swing");
Clazz.load (["J.awtjs.swing.TableColumn"], "J.awtjs.swing.AbstractTableModel", null, function () {
Clazz.declareInterface (J.awtjs.swing, "AbstractTableModel", J.awtjs.swing.TableColumn);
});
