Clazz.declarePackage ("J.quantum");
Clazz.load (["J.quantum.QuantumCalculation"], "J.quantum.QuantumPlaneCalculation", null, function () {
c$ = Clazz.declareType (J.quantum, "QuantumPlaneCalculation", J.quantum.QuantumCalculation);
});
