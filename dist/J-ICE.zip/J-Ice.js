
      		
///js// Js/jicefunction.js /////
/*  J-ICE library 

 based on:
 *
 *  Copyright (C) 2010-2014 Pieremanuele Canepa http://j-ice.sourceforge.net/
 *
 *  Contact: pierocanepa@sourceforge.net
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA
 *  02111-1307  USA.
 */


//TODO: isosurface ?.CUBE  plane {0 1 0 1} contour 40   map ?.CUBE 

/////////////////////////////////////////////////////////////////////////////
////////////////////////////////COMMON FUNCTIONS  
//Common functions to manipulate data of forms and objects

runJmolScript = function(script) {
	jmolScript(script);	
}

runJmolScriptAndWait = function(script) {
	jmolScriptWait(script);	
}

function getbyID(id) {
	return document.getElementById(id);
}

function setVbyID(id, val) {
	getbyID(id).value = val;
}

function getbyName(na) {
	return document.getElementsByName(na);
}

function getValue(id) {
	return getbyID(id).value;
}

function getValueSel(id) {
	return getbyID(id)[getbyID(id).selectedIndex].value;
}

function checkID(id) {
	return getbyID(id).checked;
}

function unCheckID(id) {
	return getbyID(id).unchecked;
}

function checkBox(id) {
	getbyID(id).checked = true;
}

function uncheckBox(id) {
	getbyID(id).checked = false;
}

function resetByID(form) {
	var element = "document." + form + ".reset";
	return element;
}

//These functions are used to enabled and disabled an element
function makeDisable(element) {
	var x = getbyID(element);
	x.disabled = true;
}

function makeEnable(element) {
	var x = getbyID(element);
	x.disabled = false;
}

function checkBoxStatus(form, element) {
	if (form.checked == true)
		makeDisable(element);
	if (form.checked == false)
		makeEnable(element);
}

function checkBoxX(form) {
	var value = "";
	var test = getbyID(form);
	value = (test.checked) ? ("on") : ("off");
	return value;
}

function setTextboxValue(nametextbox, valuetextbox) {
	var tbox = getbyID(nametextbox);
	tbox.value = "";
	if (tbox)
		tbox.value = valuetextbox;
}

function uncheckRadio(radio) {
	var radioId = getbyName(radio);
	for ( var i = 0; i < radioId.length; i++)
		radioId[i].checked = false;
}

//this function sorts value given an array and removes duplicates too
function unique(a) {
	var r = new Array();
	o: for ( var i = 0, n = a.length; i < n; i++) {
		for ( var x = 0, y = r.length; x < y; x++)
			if (r[x] == a[i])
				continue o;
		r[r.length] = a[i];
	}
	return r;
}

//This is meant to add new element to a list
function addOption(selectbox, text, value) {
	var optn = document.createElement("OPTION");
	optn.text = text;
	optn.value = value;
	selectbox.options.add(optn);
}

//This is to clean a list
function cleanList(listname) {
	for ( var i = (getbyID(listname).options.length - 1); i >= 0; i--)
		getbyID(listname).remove(i);
}

function toggleDiv(form, me) {
	if (form.checked == true)
		getbyID(me).style.display = "inline";
	if (form.checked == false)
		getbyID(me).style.display = "none";
}

function toggleDivValue(value, me) {
	if (value == true)
		getbyID(me).style.display = "inline";
	if (value == false)
		getbyID(me).style.display = "none";
}

function untoggleDiv(form, me) {
	if (form.checked == true)
		getbyID(me).style.display = "none";
	if (form.checked == false)
		getbyID(me).style.display = "inline";
}

function toggleDivRadioTrans(value, me) {
	if (value == "off") {
		getbyID(me).style.display = "inline";
	} else {
		getbyID(me).style.display = "none";
	}
}

Array.prototype.max = function() {
	var max = this[0];
	var len = this.length;
	for ( var i = 1; i < len; i++)
		if (this[i] > max)
			max = this[i];
	return max;
}

Array.prototype.min = function() {
	var min = this[0];
	var len = this.length;
	for ( var i = 1; i < len; i++)
		if (this[i] < min)
			min = this[i];
	return min;
}

////////////////////////////////END COMMON FUNCTIONS

/////////////////////////////////////////////////////////////////////////////
/////MESSAGE , ERROR and WARNING

function warningMsg(msg) {
	alert("WARNING: " + msg);
}

function errorMsg(msg) {
	alert("ERROR: " + msg);
	return false;
}

function messageMsg(msg) {
	alert("MESSAGE: " + msg);
}

function errCallback(a, b, c, d) {
	errorMsg(c);
}

/////////////////////////////// END MESSAGE , ERROR and WARNING

/////////////////////////////////////////////////////////////////////////////

////////////////////////////////Jmol COMMON FUNCTIONS

//This grabs the value given form the form
function setV(value) {
	runJmolScript(value);
}

//This set the value on or off depending on the Checkbox status
function setVTrueFalse(form, value) {
	(form.checked == true) ? setV(value + " TRUE") : setV(value + " FALSE");
}

function setVCheckbox(form, value) {
	if (form.checked == true)
		var stringa = value + " ON";
	if (form.checked == false)
		var stringa = value + " OFF";
	setV(stringa);
}

//These functions extract values form the model load in Jmol
function extractInfoJmol(whatToExtract) {
	var data = jmolGetPropertyAsArray(whatToExtract);
	return data;
}

function extractInfoJmolString(whatToExtract) {
	var data = jmolGetPropertyAsString(whatToExtract);
	return data;
}

var Info = new Array();
function extractAuxiliaryJmol(path) {
	Info = extractInfoJmol("auxiliaryInfo.models");
	if (path) {
		for (var i = Info.length; --i >= 0;)
			if (!Info[i] || !Info[i].modelProperties || Info[i].modelProperties.PATH != path)
				Info.splice(i, 1);		
	}
	return Info;
}

var InfoAtom = new Array();
function extractAtomInfo() {
	InfoAtom = extractInfoJmol("atomInfo");
	return InfoAtom;
}

//This function saves the current state of Jmol applet
function saveState() {
	setV('set errorCallback "errCallback";');
	setV("save ORIENTATION orienta; save STATE status;");
	setV("set messageCallback 'saveMessageCallback'; message SAVED;");
}

function saveStatejust() {
	setV("save ORIENTATION orienta; save STATE status;");
	// setV("set messageCallback 'saveMessageCallback'; message SAVED;")
}

function loadStatejust() {
	setV('set errorCallback "errCallback";');
	setV("restore ORIENTATION orienta; restore STATE status;");
	// setV("set messageCallback 'saveMessageCallback'; message SAVED;")
}

function saveMessageCallback(a, m) {
	m = "" + m;
	// important to do this to change from Java string to JavaScript string
	if (m.indexOf("SAVED") == 0) {
		setV("echo;");
		reloadFastModels();
		reloadState();
	}
}

//This just saves the orientation of the structure
function saveOrientation() {
	setV('set errorCallback "errCallback";');
	setV('save ORIENTATION oriente');
	setV("set messageCallback 'saveOrientaMessageCallback'; message SAVEDORIENTA;");
}

function saveOrientaMessageCallback(a, m) {
	m = "" + m;
	// important to do this to change from Java string to JavaScript string
	if (m.indexOf("SAVEDORIENTA") == 0) {
	}
}

function reloadOrientation() {
	setV('set errorCallback "errCallback";');
	setV('restore ORIENTATION oriente');
}

//This function reloads the previously saved state after a positive
//saveMessageCallback() == SAVED
function reloadState() {
	setV('set errorCallback "errCallback";');
	setV('restore ORIENTATION orienta; restore STATE status;');
}

function setNameModel(form) {
	if (form.checked == true)
		var stringa = "frame title";
	if (form.checked == false)
		var stringa = "frame title ''";
	setV(stringa);
}

function setTitleEcho() {
	var titleFile = "";
	titleFile = extractInfoJmolString("fileHeader");
	setV('set echo top right; echo "' + titleFile + ' ";');
}

function saveCurrentState() {
	warningMsg("This option save only the state of the currently loaded system.");
	setV('set errorCallback "errCallback";');
	setV('save ORIENTATION orask; save STATE stask; save BOND bask');
	setV("set messageCallback 'saveCurrentAsk'; message SAVEDASK; set echo top left;echo saving state...;refresh;");
}

function saveCurrentAsk(a, m) {
	m = "" + m;
	// important to do this to change from Java string to JavaScript string
	if (m.indexOf("SAVEDASK") == 0) {
		setV("echo;");
	}
}

function reloadCurrentState() {
	setV('set errorCallback "errCallback";');
	setV('restore ORIENTATION orask; restore STATE stask; restore BOND bask;');
	setV("set messageCallback 'reloadCurrentAsk'; message RELOADASK; set echo top left;echo reloading previosu state...;refresh;");
}

function reloadCurrentAsk(a, m) {
	m = "" + m;
	// important to do this to change from Java string to JavaScript string
	if (m.indexOf("RELOADASK") == 0) {
		setV("echo;");
	}
}

////////////////////////////////END Jmol COMMON FUNCTIONS

/////////FUNCTION TO FILL LIST

////This is to select the atom by element

function fillElementlist() {
	var element = new Array();
	element = null;
	element = jmolGetPropertyAsArray("atomInfo");

	var newElement = new Array();
	newElement[0] = "select";
	for ( var i = 1; i < element.length; i++)
		newElement[i] = element[i].element;

	var sortedElement = unique(newElement);

	for ( var i = 0; i < sortedElement.length; i++) {
		addOption(getbyID("colourbyElementList"), sortedElement[i],
				sortedElement[i]);
		addOption(getbyID("polybyElementList"), sortedElement[i],
				sortedElement[i]);
		addOption(getbyID("poly2byElementList"), sortedElement[i],
				sortedElement[i]);
		addOption(getbyID("byElementAtomMotion"), sortedElement[i],
				sortedElement[i]);
		addOption(getbyID("deletebyElementList"), sortedElement[i],
				sortedElement[i]);
		addOption(getbyID("connectbyElementList"), sortedElement[i],
				sortedElement[i]);
		addOption(getbyID("connectbyElementListone"), sortedElement[i],
				sortedElement[i]);
	}
}



function updateListElement(x) {
	for ( var i = (getbyID("colourbyElementList").options.length - 1); i >= 0; i--)
		getbyID("colourbyElementList").remove(i);
	for ( var i = (getbyID("polybyElementList").options.length - 1); i >= 0; i--)
		getbyID("polybyElementList").remove(i);
	for ( var i = (getbyID("poly2byElementList").options.length - 1); i >= 0; i--)
		getbyID("poly2byElementList").remove(i);
	for ( var i = (getbyID("byElementAtomMotion").options.length - 1); i >= 0; i--)
		getbyID("byElementAtomMotion").remove(i);
	for ( var i = (getbyID("deletebyElementList").options.length - 1); i >= 0; i--)
		getbyID("deletebyElementList").remove(i);
	for ( var i = (getbyID("connectbyElementList").options.length - 1); i >= 0; i--)
		getbyID("connectbyElementList").remove(i);
	for ( var i = (getbyID("connectbyElementListone").options.length - 1); i >= 0; i--)
		getbyID("connectbyElementListone").remove(i);
	fillElementlist();
}
///////////END LIST

/////////////////////////////// SHOW

var modelNumber;
//This shows a frame once clicked on the lateral list
function showFrame(i) {
	ModelNumber = null;
	if (counterFreq != 0) {
		var model = i;
		setV("frame " + model);
		selectDesireModel(model);
		getUnitcell(model);
	} else {
		setV("frame " + i);
		modelNumber = i;
		selectDesireModel(i);
		getUnitcell(i);

	}

}

var selectedFrame = null;
var frameNum = null;
var frameValue = null;
function selectDesireModel(i) {
	selectedFrame = null;
	frameNum = null;
	frameValue = null;
	selectedFrame = "{1." + i + "}";
	frameNum = "1." + i;
	frameValue = i;
	if (i == null || i == "") {
		selectedFrame = "{1.1}";
		frameNum = "1.1";
		frameValue = 1;
	}
}
/////////////////////////////// END SHOW

////////////////LOAD And SAVE functions
//export list
var flagCryVasp = true; // if flagCryVasp = true crystal output
var flagGromos = false;
var flagGulp = false;
var flagOutcar = false;
var flagGauss = false;
var flagQuantum = false;
var flagCif = false;
var flagSiesta = false;
var flagDmol = false;
var flagMolde = false;
var flagCast = false;
function onChangeLoad(load) {
	// This is to reset all function
	resetAll();

	switch (load) {
	case "loadC":
		setV('set errorCallback "errCallback";load ?; set defaultDirectory; script ../scripts/name.spt');
		setName();
		break;
	case "loadShel":
		setName();
		typeSystem = "crystal";
		flagCif = true;
		getUnitcell();
		break;
	case "loadxyz":
		setV('set errorCallback "errCallback";load ?.xyz; set defaultDirectory; script ../scripts/name.spt');
		setName();
		break;
	case "loadcrystal":
		flagCryVasp = true;
		flagGulp = false;
		flagQuantum = false;
		flagGauss = false;
		flagSiesta = false;
		flagDmol = false;
		flagCast = false;
		onClickLoadStruc();
		getUnitcell(1);
		break;
	case "loadCUBE":
		cubeLoad();
		break;
	case "loadaimsfhi":
		setV('set errorCallback "errCallback";load ?.in ; set defaultDirectory; script ../scripts/name.spt;');
		setName();
		flagCif = true;
		typeSystem = "crystal";
		getUnitcell();
		break;
	case "loadcastep":
		setV('set errorCallback "errCallback"; load ?.cell ; set defaultDirectory');
		setName();
		flagCif = true;
		typeSystem = "crystal";
		getUnitcell();
		break;
	case "loadVasp":
		typeSystem = "crystal";
		flagCryVasp = false;
		flagOutcar = false;
		flagGauss = false;
		flagQuantum = false;
		flagGulp = false;
		flagSiesta = false;
		flagDmol = false;
		flagCast = false;
		onClickLoadVaspStruct();
		setName();
		getUnitcell();
		break;
	case "loadVASPoutcar":
		typeSystem = "crystal";
		flagGulp = false;
		flagOutcar = true;
		flagCryVasp = false;
		flagQuantum = false;
		flagGauss = false;
		flagSiesta = false;
		flagDmol = false;
		flagCast = false;
		onClickLoadOutcar();
		setName();
		getUnitcell(1);
		break;
	case "loadDmol":
		flagGulp = false;
		flagOutcar = false;
		flagCryVasp = false;
		flagQuantum = false;
		flagGauss = false;
		flagSiesta = false;
		flagDmol = true;
		flagCast = false;
		onClickLoadDmolStruc();
		setName();
		getUnitcell(1);
		break;
	case "loadQuantum":
		typeSystem = "crystal";
		flagGulp = false;
		flagOutcar = false;
		flagCryVasp = false;
		flagGauss = false;
		flagQuantum = true;
		flagSiesta = false;
		flagDmol = false;
		flagCast = false;
		onClickQuantum();
		setName();
		getUnitcell(1);
		break;
	case "loadGulp":
		flagGulp = true;
		flagOutcar = false;
		flagCryVasp = false;
		flagGauss = false;
		flagQuantum = false;
		flagSiesta = false;
		flagDmol = false;
		flagCast = false;
		onClickLoadGulpStruct();
		setName();
		getUnitcell(1);
		break;
	case "loadmaterial":
		setV('set errorCallback "errCallback"; load ?; set defaultDirectory; script ../scripts/name.spt;');
		setName();
		getUnitcell(1);
		break;
	case "loadWien":
		setV('set errorCallback "errCallback"; load ?.struct; set defaultDirectory; script ../scripts/name.spt;');
		setName();
		flagCif = true;
		typeSystem = "crystal";
		getUnitcell(1);
		break;
	case "loadcif":
		setV('set errorCallback "errCallback"; load ?.cif PACKED; set defaultDirectory; script ../scripts/name.spt;');
		setName();
		flagCif = true;
		typeSystem = "crystal";
		getUnitcell(1);
		break;

	case "loadSiesta":
		typeSystem = "crystal";
		flagGulp = false;
		flagOutcar = false;
		flagCryVasp = false;
		flagGauss = false;
		flagQuantum = false;
		flagSiesta = true;
		flagDmol = false;
		flagCast = false;
		loadSiesta();
		setName();
		getUnitcell(1);
		break;
	case "loadpdb":
		setV('set errorCallback "errCallback";load ?.pdb; set defaultDirectory ; script ../scripts/name.spt;');
		setName();
		flagCif = true;
		setV('unitcell on');
		typeSystem = "crystal";
		getUnitcell(1);
		break;
	case "reload":
		setName();
		var reloadStr = "script ./scripts/reload.spt"
			setV(reloadStr);
		resetAll();
		setName();
		getUnitcell(1);
		break;
	case "loadJvxl":
		loadMapJvxl();
		// setV('set errorCallback "errCallback"; zap; isosurface ?.jvxl');
		setName();
		break;
	case "loadstate":
		setV('set errorCallback "errCallback"; zap; load ?.spt; set defaultDirectory; script ../scripts/name.spt;');
		setName();
		break;

	case "loadgromacs":
		setV('set errorCallback "errCallback";load ?.gro; set defaultDirectory; script ../scripts/name.spt;');
		setName();
		getUnitcell(1);
		setV('unitcell on');
		flagGromos = true;
		break;
	case "loadgauss":
		flagCryVasp = false;
		flagGromos = false;
		flagGulp = false;
		flagOutcar = false;
		flagGauss = true;
		flagSiesta = false;
		flagDmol = false;
		flagCast = false;
		typeSystem = "molecule";
		loadGaussian();
		setName();
		break;
	case "loadMolden":
		// WE USE SAME SETTINGS AS VASP
		// IT WORKS
		typeSystem = "molecule";
		flagGulp = false;
		flagOutcar = true;
		flagCryVasp = false;
		flagQuantum = false;
		flagGauss = false;
		flagSiesta = false;
		flagDmol = false;
		flagCast = false;
		onClickLoadMoldenStruct();
		break;
	case "loadXcrysden":
		setV('set errorCallback "errCallback"; load ?.xsf ; set defaultDirectory');
		setName();
		flagCif = true;
		flagGulp = false;
		flagOutcar = false;
		flagCryVasp = false;
		flagQuantum = false;
		flagGauss = false;
		flagSiesta = false;
		flagDmol = false;
		flagCast = false;
		typeSystem = "crystal";
		getUnitcell();
		break;
	case "loadOutcastep":
		setName();
		typeSystem = "crystal";
		flagGulp = false;
		flagOutcar = false;
		flagCryVasp = false;
		flagQuantum = false;
		flagGauss = false;
		flagSiesta = false;
		flagDmol = false;
		flagCast = true;
		onClickLoadCastep();
		setName();
		getUnitcell(1);
		break;
	}
	document.fileGroup.reset();
}

function setName() {
	setTextboxValue("filename", "Filename:");
	var name = jmolGetPropertyAsJSON("filename");
	name = "Filename: "
		+ name
		.substring(name.indexOf('\"') + 13,
				name.lastIndexOf('}') - 1);
	setTextboxValue("filename", name);
}

var quantumEspresso = false;
function onChangeSave(save) {
	// see menu.js

	if (save == "savePNG")
		setV('set errorCallback "errCallback";write PNG "jice.png"');
	if (save == "savePNGJ")
		setV('set errorCallback "errCallback";write PNGJ "jice.png"');
	if (save == "saveXYZ")
		setV('set errorCallback "errCallback";write COORDS XYZ jice.xyz');
	if (save == "saveFrac")

		saveFractionalCoordinate();
	if (save == "saveCRYSTAL") {
		flagCryVasp = true;
		// magnetic = false;
		exportCRYSTAL();
	}
	if (save == "saveGROMACS")
		exportGromacs();
	if (save == "saveCASTEP")
		exportCASTEP();
	if (save == "saveQuantum") {
		// magnetic = false;
		quantumEspresso = true;
		flagCryVasp = false;
		exportQuantum();
	}
	if (save == "savePOV")
		setV('set errorCallback "errCallback"; write POVRAY jice.pov');
	if (save == "savepdb")
		setV('set errorCallback "errCallback"; write PDB jice.pdb');
	if (save == "saveVASP") {
		// magnetic = false;
		flagCryVasp = false;
		exportVASP();
	}
	if (save == "saveState")
		setV('set errorCallback "errCallback";write STATE jice.spt');
	if (save == "saveGULP") {
		flagGulp = true;
		flagCryVasp = false;
		exportGULP();
	}
	if (save == "savefreqHtml") {
		newAppletWindowFreq();
	}

	document.fileGroup.reset();
}

/////////////// END OPEN AND SAVE FUNCTIONS

///////////////
/////////////// EDIT FUNCTION
///////////////

function deleteAtom() {
	setV(deleteMode);
	setV('draw off');
}

function hideAtom() {
	setV(hideMode);
	setV('draw off');
}

function connectAtom() {
	var styleBond = getValue("setBondFashion");
	if (styleBond == "select") {
		errorMsg("Please select type of bond!");
		return false;
	}

	if (radbondVal == "all") {
		if (radBondRange == "just") {
			var bondRadFrom = getValue("radiuscoonectFrom");
			if (bondRadFrom == "") {
				errorMsg("Please, check values entered in the textboxes");
				return false;
			}
			// alert(bondRadFrom)
			setV("connect (all) (all) DELETE; connect " + bondRadFrom
					+ " (all) (all) " + styleBond + " ModifyOrCreate;");
		} else {
			var bondRadFrom = getValue("radiuscoonectFrom");
			var bondRadTo = getValue("radiuscoonectTo");
			if (bondRadFrom == "" && bondRadTo == "") {
				errorMsg("Please, check values entered in the textboxes.");
				return false;
			}
			if (bondRadTo <= bondRadFrom) {
				errorMsg("Please, check the range value entered.");
				return false;
			}
			setV("connect (all) (all) DELETE; connect " + bondRadFrom + " "
					+ bondRadTo + " (all) (all) " + styleBond
					+ " ModifyOrCreate;");
		}
	} else if (radbondVal == "atom") {
		var atomFrom = getValue("connectbyElementList");
		var atomTo = getValue("connectbyElementListone");
		if (radBondRange == "just") {
			var bondRadFrom = getValue("radiuscoonectFrom");
			if (bondRadFrom == "") {
				errorMsg("Please, check values entered in the textboxes");
				return false;
			}
			// alert(bondRadFrom)
			setV("connect (" + atomFrom + ") (" + atomTo + ") DELETE; connect "
					+ bondRadFrom + " (" + atomFrom + ") (" + atomTo + ") "
					+ styleBond + " ModifyOrCreate;");
		} else {
			var bondRadFrom = getValue("radiuscoonectFrom");
			var bondRadTo = getValue("radiuscoonectTo");
			if (bondRadFrom == "" && bondRadTo == "") {
				errorMsg("Please, check values entered in the textboxes.");
				return false;
			}
			if (bondRadTo <= bondRadFrom) {
				errorMsg("Please, check the range value entered.");
				return false;
			}
			setV("connect (" + atomFrom + ") (" + atomTo + ") DELETE; connect "
					+ bondRadFrom + " " + bondRadTo + " (" + atomFrom + ") ("
					+ atomTo + ") " + styleBond + " ModifyOrCreate;");
		}

	} else if (radbondVal == "selection") {
		setV("connect (selected) (selected) " + styleBond + " ModifyOrCreate;");
	}
}

function deleteBond() {
	var styleBond = getValue("setBondFashion");

	if (radbondVal == "all") {
		if (radBondRange == "just") {
			var bondRadFrom = getValue("radiuscoonectFrom");
			if (bondRadFrom == "") {
				setV("connect (all) (all)  DELETE;");
				return false;
			}
			// alert(bondRadFrom)
			setV("connect " + bondRadFrom + " (all) (all)  DELETE;");
		} else {
			var bondRadFrom = getValue("radiuscoonectFrom");
			var bondRadTo = getValue("radiuscoonectTo");
			if (bondRadFrom == "" && bondRadTo == "") {
				setV("connect (all) (all)  DELETE;");
				return false;
			}
			setV("connect " + bondRadFrom + " " + bondRadTo
					+ " (all) (all)  DELETE;");
		}
	} else if (radbondVal == "atom") {
		var atomFrom = getValue("connectbyElementList");
		var atomTo = getValue("connectbyElementListone");
		if (radBondRange == "just") {
			var bondRadFrom = getValue("radiuscoonectFrom");
			if (bondRadFrom == "") {
				setV("connect (" + atomFrom + ") (" + atomTo + ") DELETE;");
				return false;
			}
			// alert(bondRadFrom)
			setV(" connect " + bondRadFrom + " (" + atomFrom + ") (" + atomTo
					+ ") DELETE;");
		} else {
			var bondRadFrom = getValue("radiuscoonectFrom");
			var bondRadTo = getValue("radiuscoonectTo");
			if (bondRadFrom == "" && bondRadTo == "") {
				setV("connect (" + atomFrom + ") (" + atomTo + ") DELETE;");
				return false;
			}
			setV("connect " + bondRadFrom + " " + bondRadTo + " (" + atomFrom
					+ ") (" + atomTo + ") DELETE;");
		}

	} else if (radbondVal == "selection") {
		setV("connect (selected) (selected) " + styleBond + " DELETE;");
	}
}

var radbondVal;
function checkBondStatus(radval) {
	setV("select *; halos off; label off; select none;");
	radbondVal = radval;
	if (radbondVal == "selection") {
		for ( var i = 0; i < document.editGroup.range.length; i++)
			document.editGroup.range[i].disabled = true;
		setV('showSelections TRUE; select none; set picking on; set picking LABEL; set picking SELECT atom; halos on;');
		getbyID("connectbyElementList").disabled = true;
		getbyID("connectbyElementListone").disabled = true;
	} else {
		for ( var i = 0; i < document.editGroup.range.length; i++)
			document.editGroup.range[i].disabled = false;

		getbyID("radiuscoonectFrom").disabled = true;
		getbyID("radiuscoonectTo").disabled = true;
		getbyID("connectbyElementList").disabled = true;
		getbyID("connectbyElementListone").disabled = true;

		if (radbondVal == "atom") {
			getbyID("connectbyElementList").disabled = false;
			getbyID("connectbyElementListone").disabled = false;
		}
	}

}

var radBondRange;
function checkWhithin(radVal) {
	radBondRange = radVal;
	if (radBondRange == "just") {
		getbyID("radiuscoonectFrom").disabled = false;
		getbyID("radiuscoonectTo").disabled = true;
	} else {
		getbyID("radiuscoonectFrom").disabled = false;
		getbyID("radiuscoonectTo").disabled = false;
	}

}

//Fix .AtomName
function changeElement(value) {
	setV('{selected}.element = "' + value + '";');
	setV('{selected}.ionic = "' + value + '";');
	setV('label "%e";font label 16;')
	setV("draw off; set messageReList 'saveIsoCallback'; message LIST; ");
	updateListElement(null);
}

function messageReList(a, m) {
	m = "" + m;
	// important to do this to change from Java string to JavaScript string
	if (m.indexOf("LIST") == 0) {
		var flag = false;
		setV("echo");
		enterTab();
	}
}
/////////////// END EDIT FUNCTION

//////////////POLYHEDRA FUNCT
/////////////
var polyString = "";
function createPolyedra() {

	var vertNo, from, to, distance, style, selected, face;
	vertNo = getValue("polyEdge");
	from = getValue("polybyElementList");
	to = getValue("poly2byElementList");
	style = getValue("polyVert");
	face = getValue("polyFace");

	setV("polyhedra DELETE");

	// if( from == to){
	// errorMsg("Use a different atom as Vertex");
	// return false;
	// }

	distance = getValue("polyDistance");

	if (distance == "") {
		setV("polyhedra 4, 6" + " faceCenterOffset " + face + " " + style);
		return;
	}

	/*
	 * if(checkID("byselectionPoly")){ setV("polyhedra " + vertNo + " BOND { "+
	 * selected +" } faceCenterOffset " + face + " " + style); }
	 */

	if (checkID("centralPoly")) {
		setV("polyhedra BOND " + "{ " + from + " } faceCenterOffset " + face
				+ " " + style);
	} else {

		if (checkID("bondPoly")) {
			setV("polyhedra " + vertNo + " BOND faceCenterOffset " + face + " "
					+ style);
			// polyString = "polyhedra "+ vertNo + " BOND faceCenterOffset " +
			// face + " " + style;
		}
		if (checkID("bondPoly1")) {
			setV("polyhedra " + vertNo + " " + distance + " (" + from + ") to "
					+ "(" + to + ")   faceCenterOffset " + face + " " + style);
			// polyString = "polyhedra "+ vertNo + " " + distance + " (" +from +
			// ") to " + "(" + to + ") faceCenterOffset " + face + " ";
		}

	}

}

function checkPolyValue(value) {
	(value == "collapsed") ? (makeEnable("polyFace"))
			: (makeDisable("polyFace"));
}

function setPolyString(value) {
	polyString = "";
	polyString = "polyhedra 4, 6" + "  faceCenterOffset " + face + " " + value;
	setV(polyString);
}

function setPolybyPicking(element) {
	setPicking(element);
	checkBoxStatus(element, "polybyElementList");
	checkBoxStatus(element, "poly2byElementList");
}
///// END POLYHEDRA FUNCT

/////////
///////////////////// MEASUREMENT FUNCTIONS

var unitMeasure = "";
function setMeasureUnit(value) {
	unitMeasure = value;
	setV("set measurements " + value);
}

function setMeasurement() {
	setV("set measurements ON");
}

var mesCount = 0;
function checkMeasure(value) {
	var radiobutton = value;
	var unit = getbyID('measureDist').value;
	mesReset();
	setV('set pickingStyle MEASURE ON;');
	if (radiobutton == "distance") {
		if (unit == 'select') {
			measureHint('Select the desired measure unit.');
			uncheckRadio("distance");
			return false;
		}
		measureHint('Pick two atoms');
		setV('set defaultDistanceLabel "%10.2VALUE %UNITS"');
		setV('showSelections TRUE; select none;  label on ; set picking on; set picking LABEL; set picking SELECT atom; set picking DISTANCE;');
		setV("measure ON; set measurements ON; set showMeasurements ON; set measurements ON; set measurementUnits "
				+ unit
				+ ";set picking MEASURE DISTANCE; set MeasureCallback 'measuramentCallback';");
		setV('set measurements ' + unitMeasure + ';')
		setV('label ON');

	} else if (radiobutton == "angle") {
		measureHint('Pick three atoms');
		setV('set defaultAngleLabel "%10.2VALUE %UNITS"');
		setV('showSelections TRUE; select none;  label on ; set picking on; set picking LABEL; set picking SELECT atom; set picking ANGLE;');
		setV("measure ON; set measurements ON; set showMeasurements ON; set picking MEASURE ANGLE; set MeasureCallback 'measuramentCallback';");
		setV('set measurements ' + unitMeasure + ';')
		setV('label ON');

	} else if (radiobutton == "torsional") {
		measureHint('Pick four atoms');
		setV('set defaultTorsionLabel "%10.2VALUE %UNITS"');
		setV('showSelections TRUE; select none;  label on ; set picking on; set picking TORSION; set picking SELECT atom; set picking ANGLE;');
		setV("measure ON; set measurements ON; set showMeasurements ON; set picking MEASURE TORSION; set MeasureCallback 'measuramentCallback';");
		// setV('set measurements ' + unitMeasure + ';')
		setV('label ON');

	}

}


var measureHint = function(msg) {	
	// BH 2018
	document.measureGroup.textMeasure.value = msg + "...";
}

function measuramentCallback(app, msg, type, state, value) {
	// BH 2018
	if (state == "measurePicked")
		setMeasureText(msg);
}

function setMeasureText(value) {
	setV("show measurements");
	var init = "\n";
	// BH 2018
	if (mesCount == 0)
		document.measureGroup.textMeasure.value = init = '';
	document.measureGroup.textMeasure.value += init + ++mesCount + " " + value;
}

function mesReset() {
	mesCount = 0;
	// setV ('showSelections TRUE; select none; halos on;')
	getbyID("textMeasure").value = "";
	setV('set pickingStyle MEASURE OFF; select *; label off; halos OFF; selectionHalos OFF; measure OFF; set measurements OFF; set showMeasurements OFF;  measure DELETE;');
	// document.measureGroup.reset();
}

///////////END MEASURAMENT FUNCTIONS

/////////// CELL FUNCTIONS

function saveFrame() {
	messageMsg("This is to save frame by frame your geometry optimization.");
	var value = checkBoxX("saveFrames");
	if (value == "on")
		setV('write frames {*} "fileName.jpg"');
}

//This saves fractional coordinates
function saveFractionalCoordinate() {
	warningMsg("Make sure you had selected the model you would like to export.");

	if (selectedFrame == null)
		getUnitcell(1);

	var x = "var cellp = [" + roundNumber(aCell) + ", " + roundNumber(bCell)
	+ ", " + roundNumber(cCell) + ", " + roundNumber(alpha) + ", "
	+ roundNumber(beta) + ", " + roundNumber(gamma) + "];"
	+ 'var cellparam = cellp.join(" ");' + 'var xyzfrac = '
	+ selectedFrame + '.label("%a %16.9[fxyz]");'
	+ 'var lista = [cellparam, xyzfrac];'
	+ 'WRITE VAR lista "?.XYZfrac" ';
	setV(x);
}

//This reads out cell parameters given astructure.
var aCell, bCell, cCell, alpha, beta, gamma, typeSystem;
function getUnitcell(i) {
	// document.cellGroup.reset();
	typeSystem = "";
	var StringUnitcell = "auxiliaryinfo.models[" + i + "].infoUnitCell";

	if (i == null || i == "" || i == 0)
		StringUnitcell = " auxiliaryInfo.models[1].infoUnitCell ";

	var cellparam = extractInfoJmol(StringUnitcell);

	aCell = roundNumber(cellparam[0]);
	bCell = roundNumber(cellparam[1]);
	cCell = roundNumber(cellparam[2]);
	dimensionality = parseFloat(cellparam[15]);
	volumeCell = roundNumber(cellparam[16]);

	var bOvera = roundNumber(parseFloat(bCell / cCell));
	var cOvera = roundNumber(parseFloat(cCell / aCell));

	if (dimensionality == 1) {
		bCell = 0.000;
		cCell = 0.000;
		makeEnable("par_a");
		setVbyID("par_a", "");
		makeDisable("par_b");
		setVbyID("par_b", "1");
		makeDisable("par_c");
		setVbyID("par_c", "1");
		setVbyID("bovera", "0");
		setVbyID("covera", "0");
		typeSystem = "polymer";
	} else if (dimensionality == 2) {
		cCell = 0.000;
		typeSystem = "slab";
		makeEnable("par_a");
		setVbyID("par_a", "");
		makeEnable("par_b");
		setVbyID("par_b", "");
		makeDisable("par_c");
		setVbyID("par_c", "1");
		setVbyID("bovera", bOvera);
		setVbyID("covera", "0");
	} else if (dimensionality == 3) {
		typeSystem = "crystal";
		alpha = cellparam[3];
		beta = cellparam[4];
		gamma = cellparam[5];
		makeEnable("par_a");
		setVbyID("par_a", "");
		makeEnable("par_b");
		setVbyID("par_b", "");
		makeEnable("par_c");
		setVbyID("par_c", "");
		setVbyID("bovera", bOvera);
		setVbyID("covera", cOvera);
	} else if (!cellparam[0] && !cellparam[1] && !cellparam[2] && !cellparam[4]) {
		aCell = 0.00;
		bCell = 0.00;
		cCell = 0.00;
		alpha = 0.00;
		beta = 0.00;
		gamma = 0.00;
		typeSystem = "molecule";
		setVbyID("bovera", "0");
		setVbyID("covera", "0");
	}
	setVbyID("aCell", roundNumber(aCell));
	setVbyID("bCell", roundNumber(bCell));
	setVbyID("cCell", roundNumber(cCell));
	setVbyID("alphaCell", roundNumber(alpha));
	setVbyID("betaCell", roundNumber(beta));
	setVbyID("gammaCell", roundNumber(gamma));
	setVbyID("volumeCell", roundNumber(volumeCell));

}

function setUnitCell() {
	getUnitcell(frameValue);
	if (selectedFrame == null || selectedFrame == "" || frameValue == ""
		|| frameValue == null) {
		selectedFrame = "{1.1}";
		frameNum = 1.1;
		getUnitcell("1");
	}
}
////END OPEN SAVE FUNCTIONS

///////////////
//////////////CELL AND ORIENTATION FUNCTION
/////////////

function setCellMeasure(value) {
	typeSystem = "";
	var StringUnitcell = "auxiliaryinfo.models[" + i + "].infoUnitCell";

	if (i == null || i == "")
		StringUnitcell = " auxiliaryInfo.models[1].infoUnitCell ";

	var cellparam = extractInfoJmol(StringUnitcell);
	aCell = cellparam[0];
	bCell = cellparam[1];
	cCell = cellparam[2];
	if (value == "a") {
		setVbyID("aCell", roundNumber(aCell));
		setVbyID("bCell", roundNumber(bCell));
		setVbyID("cCell", roundNumber(cCell));
	} else {
		aCell = aCell * 1.889725989;
		bCell = bCell * 1.889725989;
		cCell = cCell * 1.889725989;
		setVbyID("aCell", roundNumber(aCell));
		setVbyID("bCell", roundNumber(bCell));
		setVbyID("cCell", roundNumber(cCell));
	}

}
function setCellDotted() {
	var cella = checkBoxX('cellDott');
	if (cella == "on") {
		setV("unitcell DOTTED ;");
	} else {
		setV("unitcell ON;");
	}
}

//This gets values from textboxes using them to build supercells
function setPackaging() {
	var kindCell = null;
	kindCell = getbyName("cella");
	var checkboxSuper = checkBoxX("supercellForce");
	var kindCellfinal = null;
	var typePack = null;

	for ( var i = 0; i < kindCell.length; i++) {
		if (kindCell[i].checked)
			kindCellfinal = kindCell[i].value;
	}

	typePack = (kindCellfinal == "conventional") ? (' filter "conventional" ')
			: (typePack = ' filter "primitive" ');

	if (getValue("par_a") == "" || getValue("par_b") == ""
		|| getValue("par_c") == "") {
		errorMsg("Please, check values entered in the textboxes.");
		return false;
	}
	if (checkboxSuper == "on") {
		warningMsg("You decided to constrain your original supercell to form a supercell. \n The symmetry was reduced to P1.");
		setV('load "" {1 1 1} SUPERCELL {' + getValue("par_a") + ' '
				+ getValue("par_b") + ' ' + getValue("par_c") + '}' + typePack);
		setV("set messageCallback 'superCellParams'; message SUPERCELL;");
	} else {
		setV('load "" {' + getValue("par_a") + ' ' + getValue("par_b") + ' '
				+ getValue("par_c") + '}' + typePack);
	}
}

function setPackRange() {

	kindCell = getbyName("cella");
	var kindCellfinal = null;
	for ( var i = 0; i < kindCell.length; i++) {
		if (kindCell[i].checked)
			kindCellfinal = kindCell[i].value;
	}
	stringa = "load '' {1 1 1} RANGE " + packRange + " FILTER '"
	+ kindCellfinal
	+ "'; set messageCallback 'cellOperation'; message CELL;";
	setV(stringa);
}

function checkPack() {
	uncheckBox("superPack");
	// This initialize the bar
	getbyID("packMsg").innerHTML = 0 + " &#197";
}

function uncheckPack() {
	uncheckBox("chPack");
	getbyID("packDiv").style.display = "none";
	kindCell = getbyName("cella");
	var kindCellfinal = null;
	for ( var i = 0; i < kindCell.length; i++) {
		if (kindCell[i].checked)
			kindCellfinal = kindCell[i].value;
	}
	setCellType(kindCellfinal);
}

function setCellType(value) {
	var valueConv = checkBoxX("superPack");
	var checkBoxchPack = checkBoxX("chPack");
	var stringa = "load '' FILTER '" + value
	+ "'; set messageCallback 'cellOperation'; message CELL;";
	if (valueConv == "on" && checkBoxchPack == "off") {
		stringa = "load '' FILTER '" + value
		+ "'; set messageCallback 'cellOperation'; message CELL;";
		(value == "primitive") ? (setV(stringa)) : (setV(stringa));
	} else if (valueConv == "off" && checkBoxchPack == "on") {
		stringa = "load '' {1 1 1} RANGE " + packRange + " FILTER '" + value
		+ "'; set messageCallback 'cellOperation'; message CELL;";
		(value == "primitive") ? (setV(stringa)) : (setV(stringa));
	}
}

function setManualOrigin() {

	var x = getValue("par_x");
	var y = getValue("par_y");
	var z = getValue("par_z");

	if (x == "" || y == "" || z == "") {
		errorMsg("Please, check values entered in the textboxes");
		return false;
	}

	setV("unitcell { " + x + " " + y + " " + z
			+ " }; set messageCallback 'cellOperation'; message CELL;");

}

//This controls the refined motion of the structure
var motion = "";
function setKindMotion(valueList) {
	motion = valueList;
	if (motion == "select")
		errorMsg("Please select the motion");
	return motion;
}

function setMotion(axis) {
	var magnitudeMotion = getbyID("fineOrientMagn").value;

	if (motion == "select" || motion == "") {
		errorMsg("Please select the motion");
		return false;
	}

	// /(motion == "translate" )? (makeDisable("-z") + makeDisable("z")) :
	// (makeEnable("-z") + makeEnable("z"))

	if (magnitudeMotion == "") {
		errorMsg("Please, check value entered in the textbox");
		return false;
	}

	var stringa = "Selected" + " " + axis + " " + magnitudeMotion;
	if (motion == "translate" && (axis == "-x" || axis == "-y" || axis == "-z")) {
		axis = axis.replace("-", "");
		stringa = "Selected" + " " + axis + " -" + magnitudeMotion;
	}

	(!getbyID("moveByselection").checked) ? setV(motion + " " + axis + " "
			+ magnitudeMotion) : setV(motion + stringa);

}

function setFashionAB(valueList) {

	var radio = getbyName("abFashion");
	for ( var i = 0; i < radio.length; i++) {
		if (radio[i].checked == true)
			var radioValue = radio[i].value;
	}

	var fashion = (radioValue == "on") ? 'OPAQUE' : 'TRANSLUCENT';

	if (valueList != "select")
		setV('color ' + valueList + ' ' + fashion);
}

function setUnitCellOrigin(value) {
	setV("unitcell { " + value + " }");
}

function getSymInfo() {

	// update all of the model-specific page items

	SymInfo = {};
	var s = "";
	var info = jmolEvaluate('script("show spacegroup")');
	if (info.indexOf("x,") < 0) {
		s = "no space group";
	} else {
		var S = info.split("\n");
		var hm = "?";
		var itcnumber = "?";
		var hallsym = "?";
		var latticetype = "?";
		var nop = 0;
		var slist = "";
		for ( var i = 0; i < S.length; i++) {
			var line = S[i].split(":");
			if (line[0].indexOf("Hermann-Mauguin symbol") == 0)
				s += "<br>"
					+ S[i]
			.replace(
					/Hermann\-Mauguin/,
			"<a href=http://en.wikipedia.org/wiki/Hermann%E2%80%93Mauguin_notation target=_blank>Hermann-Mauguin</a>");
			else if (line[0].indexOf("international table number") == 0)
				s += "<br>"
					+ S[i]
			.replace(
					/international table number/,
			"<a href=http://it.iucr.org/ target=_blank id='prova'>international table</a> number");
			else if (line[0].indexOf("lattice type") == 0)
				s += "<br>"
					+ S[i]
			.replace(
					/lattice type/,
			"<a href=http://cst-www.nrl.navy.mil/bind/static/lattypes.html target=_blank>lattice type</a>");
			else if (line[0].indexOf(" symmetry operation") >= 0)
				nop = parseInt(line[0]);
			else if (nop > 0 && line[0].indexOf(",") >= 0)
				slist += "\n" + S[i];

		}

		s += "<br> Symmetry operators: " + nop;

		var S = slist.split("\n");
		var n = 0;
		var i = -1;
		while (++i < S.length && S[i].indexOf(",") < 0) {
		}
		s += "<br><select id='symselect' onchange=getSelect() onkeypress=\"setTimeout('getSelect()',50)\" class='select'><option value=0>select a symmetry operation</option>";
		for (; i < S.length; i++)
			if (S[i].indexOf("x") >= 0) {
				var sopt = S[i].split("|")[0].split("\t");
				SymInfo[sopt[1]] = S[i].replace(/\t/, ": ").replace(/\t/, "|");
				sopt = sopt[0] + ": " + sopt[2] + " (" + sopt[1] + ")";
				s += "<option value='" + parseInt(sopt) + "'>" + sopt
				+ "</option>";
			}
		s += "</select>";

		var info = jmolEvaluate('{*}.label("#%i %a {%[fxyz]/1}")').split("\n");
		var nPoints = info.length;
		var nBase = jmolEvaluate('{symop=1555}.length');
		s += "<br><select id='atomselect' onchange=getSelect() onkeypress=\"setTimeout('getSelect()',50)\"  class='select'><option value=0>base atoms</option>";
		s += "<option value='{0 0 0}'>{0 0 0}</option>";
		s += "<option value='{1/2 1/2 1/2}'>{1/2 1/2 1/2}</option>";
		for ( var i = 0; i < nPoints; i++)
			s += "<option value=" + i + (i == 0 ? " selected" : "") + ">"
			+ info[i] + "</option>";
		s += "</select>";

		s += "</br><input type=checkbox id=chkatoms onchange=getSelect() checked=true />superimpose atoms";
		s += " opacity:<select id=selopacity onchange=getSelect() onkeypress=\"setTimeout('getSelect()',50)\"  class='select'>"
			+ "<option value=0.2 selected>20%</option>"
			+ "<option value=0.4>40%</option>"
			+ "<option value=0.6>60%</option>"
			+ "<option value=1.0>100%</option>" + "</select>";

	}
	getbyID("syminfo").innerHTML = s;
}

function getSelect(symop) {
	var d = getbyID("atomselect");
	var atomi = d.selectedIndex;
	var pt00 = d[d.selectedIndex].value;
	var showatoms = (getbyID("chkatoms").checked || atomi == 0);
	setV("display " + (showatoms ? "all" : "none"));
	var d = getbyID("symselect");
	var iop = parseInt(d[d.selectedIndex].value);
	// if (!iop && !symop) symop = getbyID("txtop").value
	if (!symop) {
		if (!iop) {
			setV("select *;color opaque;draw sym_* delete");
			return

		}
		symop = d[d.selectedIndex].text.split("(")[1].split(")")[0];
		// getbyID("txtop").value
		// = symop
	}
	if (pt00.indexOf("{") < 0)
		pt00 = "{atomindex=" + pt00 + "}";
	var d = getbyID("selopacity");
	var opacity = parseFloat(d[d.selectedIndex].value);
	if (opacity < 0)
		opacity = 1;
	var script = "select *;color atoms translucent " + (1 - opacity);
	script += ";draw symop \"" + symop + "\" " + pt00 + ";";
	if (atomi == 0) {
		script += ";select symop=1555 or symop=" + iop + "555;color opaque;";
	} else if (atomi >= 3) {
		script += ";pt1 = "
			+ pt00
			+ ";pt2 = all.symop(\""
			+ symop
			+ "\",pt1).uxyz.xyz;select within(0.2,pt1) or within(0.2, pt2);color opaque;";
	}
	secho = SymInfo[symop];
	if (!secho) {
		secho = jmolEvaluate("all.symop('" + symop + "',{0 0 0},'draw')")
		.split("\n")[0];
		if (secho.indexOf("//") == 0) {
			secho = secho.substring(2);
		} else {
			secho = symop;
		}
	}
	script = "set echo top right;echo " + secho + ";" + script;
	setV(script);
}
function resetSymmetryView() {
	setV('select *;color atoms opaque; echo; draw off');
}

function deleteSymmetry() {
	getbyID("syminfo").removeChild;
}

function cellOperation(a, m) {
	m = "" + m;
	// important to do this to change from Java string to JavaScript string
	if (m.indexOf("CELL") == 0) {
		deleteSymmetry();
		getSymInfo();
		for ( var i = 0; i < 2; i++)
			setUnitCell();
	}
}

function superCellParams(a, m) {
	m = "" + m;
	// important to do this to change from Java string to JavaScript string
	if (m.indexOf("SUPERCELL") == 0)
		setUnitCell();
}

var kindCoord;
var measureCoord = false;
function viewCoord(value) {
	kindCoord = value;
	measureCoord = true;
	setV("select *; label off");
	messageMsg("Pick the atom your interested, please.");
	setV('set defaultDistanceLabel "%10.7VALUE %UNITS"');
	setV('showSelections TRUE; select none; set picking ON;set picking LABEL; set picking SELECT atom; halos on; set LABEL on; set PickCallback "showCoord"');
}

function showCoord(a, b, c, d, e, f) {
	// setMeasureText(b);
	if (measureCoord) {
		if (kindCoord == "fractional") {
			setV('Label "%a: %.2[fX] %.2[fY] %.2[fZ]"');
		} else {
			setV('Label "%a: %1.2[atomX] %1.2[atomY] %1.2[atomZ]"');
		}
	}
}
////////////END CELL and MOTION FUNCTIONS

////////////////////BUILD FUNCTIONS

function addAtomfrac() {
	var value = checkBoxX("addNewFrac");
	if (value == "on") {
		messageMsg("Enter the three fractional positions of the atom you would like to add. \n ADVICE: use the functions view fractional/Cartesian coordinates of of neighbor atom/s. ");
		makeEnable("x_frac");
		makeEnable("y_frac");
		makeEnable("z_frac");
		makeEnable("addNewFracList");
		makeEnable("addNewFracListBut");
	} else {
		makeDisable("x_frac");
		makeDisable("y_frac");
		makeDisable("z_frac");
		makeDisable("addNewFracList");
		makeDisable("addNewFracListBut");
	}
}

function addNewatom() {
	var type = getValue("addNewFracList");
	var x, y, z;
	x = parseFloat(getValue("x_frac"));
	y = parseFloat(getValue("y_frac"));
	z = parseFloat(getValue("z_frac"));

	if (x == null || y == null || z == null) {
		errorMsg("You didn't properly set the coordinate");
		return false;
	} else {

		var question = confirm("Would you like to add the atom to the current structure (OK) or create a new structure (Cancel)?");
		if (!question) {
			// setV('var mol = \"' + atomString + ' \" ;');
			messageMsg("Your coordinate will be treated as Cartesian.")
			var atomString = "1\n\n" + type + " " + parseFloat(x) + " "
			+ parseFloat(y) + " " + parseFloat(z);
			setV('set appendNew TRUE; DATA "model"' + atomString
					+ ' end "model"');
		} else {
			var fractional = confirm("Are these coordinates fractionals (OK) or Cartesians (Cancel)?");
			getUnitcell(frameValue);
			setUnitCell();
			setV('var noatoms =' + selectedFrame + '.length  + 1;');
			if (!fractional) {
				var atomString = "\n 1\n\n" + type + " " + parseFloat(x) + " "
				+ parseFloat(y) + " " + parseFloat(z);
				setV('set appendNew FALSE; DATA "append"' + atomString
						+ '\n end "append"');
			} else {
				setV("set appendNew FALSE;");
				var script = "script inline @{'DATA \"append\"1\\n\\n TE ' + format('%12.3p',{X,Y,Z}.xyz) +'\\nend \"append\" '}"
					setV(script.replace(/X/, parseFloat(x)).replace(/Y/,
							parseFloat(y)).replace(/Z/, parseFloat(z)).replace(
									/TE/, type));
			}
			// alert(atomString)

		}
		setVbyID("x_frac", "");
		setVbyID("y_frac", "");
		setVbyID("z_frac", "");
		getbyID("addAtomCrystal").style.display = "none";
	}
}

function addAtomZmatrix(form) {
	loadScriptZMatrix();
	selectElementZmatrix(form);
}

function loadScriptZMatrix() {

	// here we must check for crystal surface oo polymer because the routine
	// it's shlighthly different
	setV("function zAdd(type, dist, a, ang, b, tor, c) {\n"
			+ "var vbc = c.xyz - b.xyz\n" + "var vba = a.xyz - b.xyz\n"
			+ "var p = a.xyz - (vba/vba) * dist\n"
			+ 'var mol = "1 \n\n" + type + " " + p.x + " " + p.y + " " + p.z\n'
			+ "var p = a.xyz + cross(vbc, vba) \n" + "set appendNew FALSE \n"
			+ 'DATA "append" \\n\\n' + '+ mol + ' + '\\n end "append" \n'
			+ 'var newAtom = {*}[0]\n' + 'connect @a @newAtom\n'
			+ 'rotate Selected molecular @a @p @ang @newAtom \n'
			+ 'rotate Selected molecular @b @a @tor @newAtom \n' + '}');
}

var counterClicZ = 0;
function selectElementZmatrix(form) {

	if (form.checked) {
		counterClicZ = 0;
		for ( var i = 0; i < 3; i++) {

			if (i == 0) {
				messageMsg("This procedure allows the user to introduce a new atom (or more), \n just by knowing its relationship with its neighbour atoms.")
				messageMsg("Select the 1st atom where to attach the new atom.");
			}

			if (counterClicZ == 1) {
				messageMsg("Select the 2nd atom to form the angle.");
			} else if (counterClicZ == 2) {
				messageMsg("Select the 3rd atom to form the torsional angle.");
			}
			setV("draw off; showSelections TRUE; select none; set picking on; set picking LABEL; set picking SELECT atom; halos on; set PickCallback 'pickZmatrixCallback'");
		}
	}
}

var distanceZ, angleZ, torsionalZ
var arrayAtomZ = new Array(3);
function pickZmatrixCallback(a, b, c, d, e) {
	if (counterClicZ == 0) { // distance
		var valuedist = prompt(
				"Now enter the distance (in \305) from which you want to add the new atom. \n Seletion is done by symply clikking ont the desire atom",
		"1.0");
		distanceZ = parseFloat(valuedist);
		arrayAtomZ[0] = parseInt(b.substring(b.indexOf('#') + 1,
				b.indexOf('.') - 2));

	}
	if (counterClicZ == 1) { // angle

		var valueangle = prompt(
				"Now the enter the angle (in degrees) formed between the new atom, the 1st and the 2nd ones. \n Seletion is done by symply clikking ont the desire atoms",
		"109.7");
		angleZ = parseFloat(valueangle);
		arrayAtomZ[1] = parseInt(b.substring(b.indexOf('#') + 1,
				b.indexOf('.') - 2));

	}
	if (counterClicZ == 2) {// torsional

		var valuetorsion = prompt(
				"Enter the torsional angle(in degrees) formed between the new atom, the 1st, the 2nd and the 3rd ones. \n Seletion is done by symply clikking ont the desire atoms",
		"180.0");
		torsionalZ = parseFloat(valuetorsion);
		setV("set messageCallback 'elementZcallback'; message ELEMENTZ;")
		arrayAtomZ[2] = parseInt(b.substring(b.indexOf('#') + 1,
				b.indexOf('.') - 2));
	}
	counterClicZ++;
}

function elementZcallback(a, m) {
	m = "" + m;
	// important to do this to change from Java string to JavaScript string
	if (m.indexOf("ELEMENTZ") == 0) {
		messageMsg("distance: " + distanceZ + " from atom " + arrayAtomZ[0]
		+ " angle: " + angleZ + " formed by atoms: new, "
		+ arrayAtomZ[0] + ", " + arrayAtomZ[1] + "\n and torsional: "
		+ torsionalZ + " formed by atoms: new, " + arrayAtomZ[0] + ", "
		+ arrayAtomZ[1] + ", " + arrayAtomZ[2])
		messageMsg("Now, select the desire element.");
	}
}

function addZatoms() {
	setV('zAdd(\"' + getValue('addEleZ') + '\",' + distanceZ + ',{'
			+ arrayAtomZ[0] + '}, ' + angleZ + ', {' + arrayAtomZ[1] + '},'
			+ torsionalZ + ', {' + arrayAtomZ[2] + '})')
}

function createCrystalStr(form) {
	if (form.checked) {
		makeDisable("periodMole");
		// messageMsg("Do you want to create a Crystal?");

	} else {

	}
}

var makeCrystalSpaceGroup = null;
function checkIfThreeD(value) {
	makeEnablePeriodicityMol()
	if (value == "crystal") {

		makeEnable("periodMole");
		setVbyID("a_frac", "");
		setVbyID("b_frac", "");
		setVbyID("c_frac", "");
	} else if (value == "slab") {
		makeDisable("periodMole");
		makeCrystalSpaceGroup = "P-1"; // / set P-1 as symmetry for film and
		// polymer
		setVbyID("a_frac", "");
		setVbyID("b_frac", "");
		setVbyID("c_frac", "0");
		makeDisable("c_frac");
		setVbyID("alpha_frac", "");
		setVbyID("beta_frac", "");
		setVbyID("gamma_frac", "90");
		makeDisable("gamma_frac");
	} else if (value == "polymer") {
		makeDisable("periodMole");
		makeCrystalSpaceGroup = "P-1"; // / set P-1 as symmetry for film and
		// polymer
		setVbyID("a_frac", "");
		setVbyID("b_frac", "0");
		makeDisable("b_frac");
		setVbyID("c_frac", "0");
		makeDisable("c_frac");
		setVbyID("alpha_frac", "90");
		makeDisable("alpha_frac");
		setVbyID("beta_frac", "90");
		makeDisable("beta_frac");
		setVbyID("gamma_frac", "90");
		makeDisable("gamma_frac");
	} else if (value == "") {
		setVbyID("a_frac", "");
		makeDisable("a_frac");
		setVbyID("b_frac", "");
		makeDisable("b_frac");
		setVbyID("c_frac", "");
		makeDisable("c_frac");
		setVbyID("alpha_frac", "");
		makeDisable("alpha_frac");
		setVbyID("beta_frac", "");
		makeDisable("beta_frac");
		setVbyID("gamma_frac", "");
		makeDisable("gamma_frac");
	}
}

function setCellParamSpaceGroup(spaceGroup) {
	// /from crystal manual http://www.crystal.unito.it/Manuals/crystal09.pdf
	var trimSpaceGroup = null;

	if (spaceGroup.search(/:/) == -1) {
		if (spaceGroup.search(/\*/) == -1) {
			trimSpaceGroup = spaceGroup;
		} else {
			trimSpaceGroup = spaceGroup.substring(0, spaceGroup.indexOf('*'));
		}
	} else {
		trimSpaceGroup = spaceGroup.substring(0, spaceGroup.indexOf(':'));
	}
	switch (true) {

	case ((trimSpaceGroup <= 2)): // Triclinic lattices
		setVbyID("a_frac", "");
	setVbyID("b_frac", "");
	setVbyID("c_frac", "");
	setVbyID("alpha_frac", "");
	setVbyID("beta_frac", "");
	setVbyID("gamma_frac", "");
	makeEnable("a_frac");
	makeEnable("b_frac");
	makeEnable("c_frac");
	makeEnable("alpha_frac");
	makeEnable("beta_frac");
	makeEnable("gamma_frac");

	break;

	case ((trimSpaceGroup > 2) && (trimSpaceGroup <= 15)): // Monoclinic
		// lattices
		setVbyID("a_frac", "");
	setVbyID("b_frac", "");
	setVbyID("c_frac", "");
	setVbyID("alpha_frac", "");
	setVbyID("beta_frac", "90.000");
	setVbyID("gamma_frac", "90.000");
	makeEnable("a_frac");
	makeEnable("b_frac");
	makeEnable("c_frac");
	makeEnable("alpha_frac");
	makeDisable("beta_frac");
	makeDisable("gamma_frac");
	break;

	case ((trimSpaceGroup > 15) && (trimSpaceGroup <= 74)): // Orthorhombic
		// lattices
		setVbyID("a_frac", "");
	setVbyID("b_frac", "");
	setVbyID("c_frac", "");
	setVbyID("alpha_frac", "90.000");
	setVbyID("beta_frac", "90.000");
	setVbyID("gamma_frac", "90.000");
	makeEnable("a_frac");
	makeEnable("b_frac");
	makeEnable("c_frac");
	makeDisable("alpha_frac");
	makeDisable("beta_frac");
	makeDisable("gamma_frac");

	break;

	case ((trimSpaceGroup > 74) && (trimSpaceGroup <= 142)): // Tetragonal
		// lattices
		setVbyID("a_frac", "");
	setVbyID("b_frac", "");
	setVbyID("c_frac", "");
	setVbyID("alpha_frac", "90.000");
	setVbyID("beta_frac", "90.000");
	setVbyID("gamma_frac", "90.000");
	makeEnable("a_frac");
	makeEnable("b_frac");
	makeEnable("c_frac");
	makeDisable("alpha_frac");
	makeDisable("beta_frac");
	makeDisable("gamma_frac");

	break;

	case ((trimSpaceGroup > 142) && (trimSpaceGroup <= 167)): // Trigonal
		// lattices
		setVbyID("a_frac", "");
	setVbyID("b_frac", "");
	setVbyID("c_frac", "");
	setVbyID("alpha_frac", "");
	setVbyID("beta_frac", "");
	setVbyID("gamma_frac", "");
	makeEnable("a_frac");
	makeEnable("b_frac");
	makeEnable("c_frac");
	makeEnable("alpha_frac");
	makeEnable("beta_frac");
	makeEnable("gamma_frac");

	break;

	case ((trimSpaceGroup > 167) && (trimSpaceGroup <= 194)): // Hexagonal
		// lattices
		setVbyID("a_frac", "");
	setVbyID("b_frac", "");
	setVbyID("c_frac", "");
	setVbyID("alpha_frac", "90.000");
	setVbyID("beta_frac", "90.000");
	setVbyID("gamma_frac", "120.000");
	makeEnable("a_frac");
	makeEnable("b_frac");
	makeEnable("c_frac");
	makeDisable("alpha_frac");
	makeDiable("beta_frac");
	makeDisable("gamma_frac");

	break;
	case ((trimSpaceGroup > 194) && (trimSpaceGroup <= 230)): // Cubic
		// lattices
		setVbyID("a_frac", "");
	setVbyID("b_frac", "");
	setVbyID("c_frac", "");
	setVbyID("alpha_frac", "90.000");
	setVbyID("beta_frac", "90.000");
	setVbyID("gamma_frac", "90.000");
	makeEnable("a_frac");
	makeEnable("b_frac");
	makeEnable("c_frac");
	makeDisable("alpha_frac");
	makeDisable("beta_frac");
	makeDisable("gamma_frac");
	break;

	default:
		errorMsg("SpaceGroup not found in range.");
	return false;
	break;

	}// end switch
}

function createMolecularCrystal() {
	var value = getValue('typeMole')
	if (value == "") {
		errorMsg("You must select which sort of structure you would like to build.")
	} else if (value == "crystal") {
		makeCrystalSpaceGroup = getValue('periodMole');
		getValueMakeCrystal();
	} else {
		getValueMakeCrystal();
	}
}

///TODO SAVE state before creating crystal
function getValueMakeCrystal() {
	setV('load \'\' {1 1 1} spacegroup "' + makeCrystalSpaceGroup
			+ '" unitcell [ ' + parseFloat(getValue('a_frac')) + ' '
			+ parseFloat(getValue('b_frac')) + ' '
			+ parseFloat(getValue('c_frac')) + ' '
			+ parseFloat(getValue('alpha_frac')) + ' '
			+ parseFloat(getValue('beta_frac')) + ' '
			+ parseFloat(getValue('gamma_frac')) + ' ];unitcell ');
	messageMsg("Now save you structure and reaload it!");
	getbyID("createmolecularCrystal").style.display = "none";
	// setV("write COORDS SPT ?.spt; set defaultdirectory");
	// setV("load ?");
}

function makeEnablePeriodicityMol() {
	makeEnable("a_frac");
	makeEnable("b_frac");
	makeEnable("c_frac");
	makeEnable("alpha_frac");
	makeEnable("beta_frac");
	makeEnable("gamma_frac");
	setVbyID("a_frac", "");
	setVbyID("b_frac", "");
	setVbyID("c_frac", "");
	setVbyID("alpha_frac", "");
	setVbyID("beta_frac", "");
	setVbyID("gamma_frac", "");
}

function cleanCreateCrystal() {
	setVbyID("a_frac", "");
	makeDisable("a_frac");
	setVbyID("b_frac", "");
	makeDisable("b_frac");
	setVbyID("c_frac", "");
	makeDisable("c_frac");
	setVbyID("alpha_frac", "");
	makeDisable("alpha_frac");
	setVbyID("beta_frac", "");
	makeDisable("beta_frac");
	setVbyID("gamma_frac", "");
	makeDisable("gamma_frac");
	document.builGroup.reset();
}
///////////////////END BUILD FUNCTIONS

/////////
////////////////////FUNCTIONS TO DEAL WITH SELECTION
/////////
var atomColor = "";
var deleteMode = "";
var hideMode = "";
var displayMode = "";
function elementSelected(element) {
	// updateListElement();
	setV("select all; halo off; label off");
	setV("select " + element + "; halo on; label on; ");
	atomColor = "color atom ";
	return atomColor;
}

function elementSelectedDelete(element) {
	setV("select all; halo off; label off");
	setV("select " + element + "; halo on; label on");
	deleteMode = "delete " + element;
	return deleteMode;
}

function elementSelectedHide(element) {
	setV("select all; halo off; label off");
	setV("select " + element + "; halo on; label on");
	hideMode = "hide " + element;
	return hideMode;
}

function elementSelectedDisplay(element) {
	// updateListAtomApp();
	setV("select all; halo off; label off");
	setV("select " + element + "; halo on; label on");
	displayMode = "display " + element;
	return displayMode;
}

function atomSelected(atom) {
	// updateListAtomApp();
	setV("select all; halo off; label off");
	setV("select {atomno=" + atom + "}; halo on; label on");
	atomColor = "color atom ";
	return atomColor;
}

function atomSelectedDelete(atom) {
	setV("select all; halo off; label off");
	setV("select {atomno=" + atom + "}; halo on; label on");
	deleteMode = "delete {atomno=" + atom + "}";
	return deleteMode;
}

function atomSelectedHide(atom) {
	setV("select all; halo off; label off");
	setV("select {atomno=" + atom + "}; halo on; label on");
	hideMode = "hide {atomno=" + atom + "}";
	return hideMode;
}

function atomSelectedDisplay(atom) {
	setV("select all; halo off; label off");
	setV("select {atomno=" + atom + "}; halo on; label on");
	displayMode = "display {atomno=" + atom + "}";
	return displayMode;
}

function setPicking(form) {
	if (form.checked == true) {
		setV('showSelections TRUE; select none; set picking on; set picking LABEL; set picking SELECT atom;halos on; ');
		atomColor = "color atom";
	}
	if (form.checked == false)
		setV('select none;');
	return atomColor;
}

function setPickingDelete(form) {
	setV('select none; halos off;');
	setV("draw off; showSelections TRUE; select none; set picking off;");
	setV('set PickCallback OFF');
	var plane = checkBoxX('byplane');
	var sphere = checkBoxX('bydistance');
	if (form.checked) {
		if (plane == 'on' || sphere == 'on') {
			setV('set picking on; set picking LABEL; set picking SELECT atom; halos on; ');
		} else {
			setV('showSelections TRUE; select none; set picking on; set picking LABEL; set picking SELECT atom; halos on;');
			deleteMode = "delete selected";
		}
	}
	if (!form.checked)
		setV('select none; halos off; label off;');
	return deleteMode;
}

function setPickingHide(form) {
	setV('select none; halos off;');
	setV("draw off; showSelections TRUE; select none; set picking off;");
	setV('set PickCallback OFF');

	var plane = checkBoxX('byplane');
	var sphere = checkBoxX('bydistance');
	if (form.checked) {
		if (plane == 'on' || sphere == 'on') {
			setV('showSelections TRUE; set picking on; set picking LABEL; set picking SELECT atom; halos on; ');
		} else {
			setV('showSelections TRUE; select none; set picking on; set picking LABEL; set picking SELECT atom; halos on; ');
		}
		hideMode = " hide selected";
	} else {
		setV('select none; halos off; label off;');
	}
	return hideMode;
}

/*
 * display within(0,plane,@{plane({atomno=3}, {0 0 0}, {0 1/2 1/2})})
 * 
 * The parametric equation ax + by + cz + d = 0 is expressed as {a b c d}.
 * 
 * Planes based on draw and isosurface objects are first defined with an ID
 * indicated, for example:
 * 
 * draw plane1 (atomno=1) (atomno=2) (atomno=3)
 * 
 * After that, the reference $plane1 can be used anywhere a plane expression is
 * required. For instance,
 * 
 * select within(0,plane, $plane1)
 */

var counterClick = false;
var counterHide = 0;
var selectedatomPlane = new Array(3);
var sortquestion = null
function setPlanehide(form) {
	if (form == null)
		sortquestion = true;

	if (form.checked) {
		messageMsg('Now select in sequence 3 atoms to define the plane.');
		selectedatomPlane = [];
		counterHide = 0;
		counterClick = true;
		for ( var i = 0; i < 3; i++) {
			setV("draw off; showSelections TRUE; select none; set picking on; set picking LABEL; set picking SELECT atom; halos on; set PickCallback 'pickPlanecallback'");
		}

		if (form != null)
			uncheckBox(form);

	} else {
		setV('select none; halos off;');
		setV("draw off; showSelections TRUE; select none; set picking off;");
		setV("set picking OFF");
	}
}

function setPlanedued(form) {
	if (form == null)
		sortquestion = true;

	messageMsg('Now select in sequence 3 atoms to define the plane.');
	selectedatomPlane = [];
	counterHide = 0;
	counterClick = true;
	for ( var i = 0; i < 3; i++)
		setV("draw off; showSelections TRUE; select none; set picking on; set picking LABEL; set picking SELECT atom; halos on; set PickCallback 'pickPlane2dcallback'");

}

function pickPlane2dcallback(a, b, c, d, e) {
	if (counterClick == true) {
		selectedatomPlane[counterHide] = parseInt(b.substring(
				b.indexOf('#') + 1, b.indexOf('.') - 2));
		messageMsg('Atom selected: ' + selectedatomPlane[counterHide] + '.');

		if (counterHide == '2') {
			counterClick = false;
			setV('draw on; draw plane1 (atomno=' + selectedatomPlane[0]
			+ ') (atomno=' + selectedatomPlane[1] + ') (atomno='
			+ selectedatomPlane[2] + ');');
			// setV('select none; halos off;');
			// setV("draw off; showSelections TRUE; select none; set picking
			// off;");
			setV("set picking OFF");
			var spin = confirm("Now would you only like to slice the density? OK for yes, Cancel if you wish to map SPIN or potential on top.")
			if (spin) {
				dueD_con = true;
				dueD_planeMiller = false;
				setV('isosurface ID "isosurface1" select ({0:47}) PLANE $plane1 MAP color range 0.0 2.0 ?.CUBE');
			} else {
				messageMsg("Now load the *.CUBE potential / spin file.");
				setV("isosurface PLANE $plane1 MAP ?.CUBE;");
			}
			setV("draw off;");
			return true;
		}

		messageMsg('Select next atom.');
		counterHide++;
	}
}

function pickPlanecallback(a, b, c, d, e) {
	if (counterClick == true) {
		selectedatomPlane[counterHide] = parseInt(b.substring(
				b.indexOf('#') + 1, b.indexOf('.') - 2));
		messageMsg('Atom selected: ' + selectedatomPlane[counterHide] + '.');

		if (counterHide == '2') {
			counterClick = false;
			setV('draw on; draw plane1 (atomno=' + selectedatomPlane[0]
			+ ') (atomno=' + selectedatomPlane[1] + ') (atomno='
			+ selectedatomPlane[2] + ');');
			if (!sortquestion) {
				var distance = prompt('Now enter the distance (in \305) within you want to select atoms. \n Positive values mean from the upper face on, negative ones the opposite.');
				if (distance != null && distance != "") {
					setV('select within(' + distance + ',plane, $plane1)');
					hideMode = " hide selected";
					deleteMode = " delete selected";
					atomColor = "color atoms";
					setV('set PickCallback OFF');
					counterClick = false;
					return true;
				}
			}
			setV('select none; halos off;');
			setV("draw off; showSelections TRUE; select none; set picking off;");
			setV("set picking OFF");
		}

		messageMsg('Select next atom.');
		counterHide++;
	}
}

var selectHideForm = null;
function setDistancehidehide(form) {
	selectHideForm = form;
	if (form.checked) {
		messageMsg('Now select the central atom around which you want to select atoms.');
		counterClick = true;
		setV("showSelections TRUE; select none; set picking on; set picking LABEL; set picking SELECT atom; halos on; set PickCallback 'pickDistancecallback'");
		// messageMsg('If you don\'t want to remove/hide atoms in the plane,
		// unselect them by using the option: select by picking.')
	} else {
		setV('select none; halos off;');
	}
}

function pickDistancecallback(a, b, c, d, e) {
	if (counterClick == true) {
		var coordinate = b
		.substring(b.indexOf('#') + 2, b.lastIndexOf('.') + 9);
		messageMsg('Atom selected: ' + coordinate + '.');
		var distance = prompt('Now enter the distance (in \305) within you want to select atoms.');
		if (distance != null && distance != "") {
			setV('select within(' + distance + ',{' + coordinate
					+ ' }); draw sphere1 width ' + distance + '  { '
					+ coordinate + '} translucent');
			// messageMsg('If you don\'t want to remove/hide the atom used for
			// the
			// selection, unselect it by using the option: select by picking.')
			hideMode = " hide selected";
			deleteMode = " delete selected";
			atomColor = "color atoms";
			setV("set PickCallback 'pickDistancecallback' OFF");
			counterClick = false;
			uncheckBox(selectHideForm);
			return true;
		}
	}

}

function selectAll() {
	setV("select *; halos on; label on;");
	atomColor = "draw off ;select *; color atom ";
	return atomColor;
}

function selectAllDelete() {
	setV("select *; halos on; label on;");
	deleteMode = "select *; delete; select none ; halos off; draw off;";
	return deleteMode;
}

function selectAllHide() {
	setV("select *; halos on; label on;");
	hideMode = "select *; hide selected; select none; halos off; draw off;";
	return hideMode;
}

function setTextSize(value) {
	setV("select *; font label " + value + " ;");
}

function setMeasureSize(value) {
	setV("select *; font label " + value + " ; font measure " + value + " ; select none;");
}


function unselAtom() {
	setV("select none; halos off; draw off;");
}
/////////////////////// END SELECTION FUNCTIONS

/////////////////
//////////////////////COLOR FUNCTION

function setAtomColor(rgbCodeStr, Colorscript) {
	var finalColor = " " + atomColor + " " + rgbCodeStr + " ";
	setV(finalColor);
	setV("draw off");
}

function setPolyColor(rgbCodeStr, Colorscript) {
	var stringa = "color polyhedra";
	var finalColor = " " + stringa + " " + rgbCodeStr + " ";
	setV(finalColor);
}

function setIsoColor(rgbCodeStr, Colorscript) {
	var stringa = "color isosurface";
	var finalColor = " " + stringa + " " + rgbCodeStr + " ";
	setV(finalColor);
}

//////////////////////END COLOR FUNCTION

/////////////////
////////////////////EXTERNAL WINDOWS

var windowoptions = "menubar=yes,resizable=1,scrollbars,alwaysRaised,width=600,height=600,left=50";
function newAppletWindow() {
	var sm = "" + Math.random();
	sm = sm.substring(2, 10);
	var newwin = open("OutputResized.html", "jmol_" + sm, windowoptions);
}

var windowfreq = "menubar=no,resizable=no,scrollbars=yes,resizable=yes;alwaysRaised,width=1024,height=768";
function newAppletWindowFreq() {
	var sm = "" + Math.random();
	sm = sm.substring(2, 10);
	var newwin = open("exportfreq.html", sm, windowfreq);
}

function onClickAcknow() {
	var woption = "menubar=no, toolbar=no scrollbar=no, status=no, resizable=no, alwaysRaised,width=360, height=200, top=10, left=10,";
	var sm = "" + Math.random();
	sm = sm.substring(2, 10);
	var newwin = open("acn.html", sm, woption);
}

var windowfeed = "menubar=no,resizable=no,scrollbars=yes,resizable=yes;alwaysRaised,width=1024,height=768";
function newAppletWindowFeed() {
	var sm = "" + Math.random();
	sm = sm.substring(2, 10);
	var newwin = open("http://j-ice.sourceforge.net/?page_id=9", sm, windowfeed);
}
//////////////////////////////////////END EXTERNAL WINOWS

///////////////// RESET FUNCTIONS
/////////////////

function resetAll() {

	setTextboxValue("filename", "Filename:");
	setUnitCell();
	document.fileGroup.reset();
	document.apparenceGroup.reset();
	document.orientGroup.reset();
	document.measureGroup.reset();
	document.cellGroup.reset();
	document.polyGroup.reset();
	document.isoGroup.reset();
	document.modelsGeom.reset();
	document.modelsVib.reset();
	document.elecGroup.reset();
	document.otherpropGroup.reset();
	document.editGroup.reset();
	// document.HistoryGroup.reset();
	// this disables antialias option BH: NOT - or at least not generally. We need a switch for this
	setV('antialiasDisplay = true;set hermiteLevel 0');
	resetFreq();
}

function exitIsosurface() {
	setV('isosurface delete all');
}

function exitFreqGroup() {
	setV('vibration off; vectors FALSE');
}

function exitMenu() {
	setV('label off; select off');
}

function exitElecpropGrp() {
	setV('script scripts/reload.spt');
	reloadOrientation();
}

//These remove all values from a list
function removeAll() {
	cleanList("geom");
	cleanList("vib");
	cleanList("colourbyElementList");
	// cleanList("colourbyAtomList");
	cleanList("polybyElementList");
	cleanList("poly2byElementList");
	setVbyID("fineOrientMagn", "5");
}

function unLoadall() {

	setV('select visible; wireframe 0.15; spacefill 20% ;cartoon off; backbone off;');
	radiiSlider.setValue(20);
	bondSlider.setValue(15);
	// radiiConnect.setValue(20);
	getbyID('radiiMsg').innerHTML = 20 + "%";
	getbyID('bondMsg').innerHTML = 0.15 + " &#197";

	/*
	 * getbyID('globalAtomicRadii').innerHTML = 20 ;
	 * getbyID('sliderGlobalAtomicRadii').style.left=20+'px';
	 * getbyID('globalBondWidths').innerHTML = 0.20;
	 * getbyID('sliderGlobalBondWidths').style.left=20+'px';
	 * getbyID('sepcLight').innerHTML = 22 + " % ";
	 * getbyID('sliderSepcLight').style.left=20+'px';
	 * getbyID('Ambient').innerHTML = 45 + " % ";
	 * getbyID('sliderAmbient').style.left=45+'px'; getbyID('Diffuse').innerHTML =
	 * 45 + " % "; getbyID('sliderDiffuse').style.left=45+'px';
	 * getbyID('sliderPerspective').style.left= 66+'px';
	 * getbyID('sliderGlobalBond').style.left= 20 + 'px';
	 * getbyID('globalBondCon').innerHTML = 2 + " ";
	 */

	// getbyID("packrange").innerHTML = 0 + " &#197"
	// getbyID('Perspective').innerHTML = 3;
}

//////////////////////////////////////END RESET FUNCTIONS

function preselectMyItem(itemToSelect) {
	// Get a reference to the drop-down
	var myDropdownList = document.modelsGeom.models;

	// Loop through all the items
	for (iLoop = 0; iLoop < myDropdownList.options.length; iLoop++) {
		if (myDropdownList.options[iLoop].value == itemToSelect) {
			// Item is found. Set its selected property, and exit the loop
			myDropdownList.options[iLoop].selected = true;
			break;
		}
	}

}

//////////////////////These functions set the values on the two scrollbars

function onClickCPK() {
	getbyID('radiiMsg').innerHTML = "100%";
	getbyID('bondMsg').innerHTML = 0.3 + " &#197";
	radiiSlider.setValue(100);
	bondSlider.setValue(30);
	runJmolScript("wireframe 0.30; spacefill 100% ;cartoon off;backbone off; draw off");
}

function onClickWire() {

	getbyID('radiiMsg').innerHTML = parseFloat(0).toPrecision(2) + " %";
	getbyID('bondMsg').innerHTML = 0.01 + " &#197";
	radiiSlider.setValue(0);
	bondSlider.setValue(1);
	runJmolScript('wireframe 0.01; spacefill 1%;ellipsoids off;cartoon off;backbone off;');
}

function onClickionic() {

	getbyID('radiiMsg').innerHTML = parseFloat(0).toPrecision(2) + " %";
	// getbyID('sliderGlobalAtomicRadii').style.left=0+'px';
	getbyID('bondMsg').innerHTML = 0.30 + " &#197";
	// getbyID('sliderGlobalBondWidths').style.left= 30+'px';
	radiiSlider.setValue(0);
	bondSlider.setValue(30);
	runJmolScript("spacefill IONIC; wireframe 0.15; draw off");
}

function onStickClick() {

	getbyID('radiiMsg').innerHTML = "1%";
	// getbyID('sliderGlobalAtomicRadii').style.left=0+'px';
	getbyID('bondMsg').innerHTML = 0.30 + " &#197";
	// /getbyID('sliderGlobalBondWidths').style.left=30+'px';
	radiiSlider.setValue(0);
	bondSlider.setValue(30);
	runJmolScript("wireframe 0.15;spacefill 1%;cartoon off;backbone off; draw off");
}

function onClickBS() {

	getbyID('radiiMsg').innerHTML = "20%";
	// getbyID('sliderGlobalAtomicRadii').style.left=20+'px';
	getbyID('bondMsg').innerHTML = 0.20 + " &#197";
	// getbyID('sliderGlobalBondWidths').style.left=20+'px';
	radiiSlider.setValue(20);
	bondSlider.setValue(20);
	runJmolScript("wireframe 0.15; spacefill 20%;cartoon off;backbone off; draw off");

}

function onClickBall() {

	getbyID('radiiMsg').innerHTML = "20%";
	// getbyID('sliderGlobalAtomicRadii').style.left=20+'px';
	getbyID('bondMsg').innerHTML = 0.00 + " &#197";
	// getbyID('sliderGlobalBondWidths').style.left=0+'px';
	radiiSlider.setValue(20);
	bondSlider.setValue(0);
	runJmolScript("select *; spacefill 20%; wireframe off ; draw off");
}

function initPerspective() {
	persSlider.setValue(35);
	getbyID('perspMsg').innerHTML = "1.4";
	getbyID('perspMsg').innerHTML = "1.4";
}

function printFileContent() {
	runJmolScript("console; getProperty fileContents;");
}
      		
///js// Js/constant.js /////
/*  J-ICE library 

    based on:
 *
 * Copyright (C) 2010-2014 Pieremanuele Canepa http://j-ice.sourceforge.net/
 *
 * Contact: pierocanepa@sourceforge.net
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA
 *  02111-1307  USA.
 */


var version = "2.8";
var eleChk = new Array(1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
		0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
		0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
		0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
		0, 0, 0, 0, 0, 0, 0, 0, 0);

var eleSymb = new Array();
eleSymb[0] = "select";
eleSymb[1] = "H";
eleSymb[2] = "He";
eleSymb[3] = "Li";
eleSymb[4] = "Be";
eleSymb[5] = "B";
eleSymb[6] = "C";
eleSymb[7] = "N";
eleSymb[8] = "O";
eleSymb[9] = "F";
eleSymb[10] = "Ne";
eleSymb[11] = "Na";
eleSymb[12] = "Mg";
eleSymb[13] = "Al";
eleSymb[14] = "Si";
eleSymb[15] = "P";
eleSymb[16] = "S";
eleSymb[17] = "Cl";
eleSymb[18] = "Ar";
eleSymb[19] = "K";
eleSymb[20] = "Ca";
eleSymb[21] = "Sc";
eleSymb[22] = "Ti";
eleSymb[23] = "V";
eleSymb[24] = "Cr";
eleSymb[25] = "Mn";
eleSymb[26] = "Fe";
eleSymb[27] = "Co";
eleSymb[28] = "Ni";
eleSymb[29] = "Cu";
eleSymb[30] = "Zn";
eleSymb[31] = "Ga";
eleSymb[32] = "Ge";
eleSymb[33] = "As";
eleSymb[34] = "Se";
eleSymb[35] = "Br";
eleSymb[36] = "No";
eleSymb[37] = "Rb";
eleSymb[38] = "Sr";
eleSymb[39] = "Y";
eleSymb[40] = "Zr";
eleSymb[41] = "Nb";
eleSymb[42] = "Mo";
eleSymb[43] = "Tc";
eleSymb[44] = "Ru";
eleSymb[45] = "Rh";
eleSymb[46] = "Pd";
eleSymb[47] = "Ag";
eleSymb[48] = "Cd";
eleSymb[49] = "In";
eleSymb[50] = "Sn";
eleSymb[51] = "Sb";
eleSymb[52] = "Te";
eleSymb[53] = "I";
eleSymb[54] = "Xe";
eleSymb[55] = "Cs";
eleSymb[56] = "Ba";
eleSymb[57] = "La";
eleSymb[58] = "Ce";
eleSymb[59] = "Lr";
eleSymb[60] = "Md";
eleSymb[61] = "Pr";
eleSymb[62] = "Sm";
eleSymb[63] = "Eu";
eleSymb[64] = "Gd";
eleSymb[65] = "Tb";
eleSymb[66] = "Dy";
eleSymb[67] = "Ho";
eleSymb[68] = "Er";
eleSymb[69] = "Tm";
eleSymb[70] = "Yb";
eleSymb[71] = "Lu";
eleSymb[72] = "Hf";
eleSymb[73] = "Ta";
eleSymb[74] = "W";
eleSymb[75] = "Re";
eleSymb[76] = "Os";
eleSymb[77] = "Ir";
eleSymb[78] = "Pt";
eleSymb[79] = "Au";
eleSymb[80] = "Hg";
eleSymb[81] = "Tl";
eleSymb[82] = "Pb";
eleSymb[83] = "Bi";
eleSymb[84] = "Po";
eleSymb[85] = "At";
eleSymb[86] = "Rd";
eleSymb[87] = "Fr";
eleSymb[88] = "Rn";
eleSymb[89] = "Ac";
eleSymb[90] = "Th";
eleSymb[91] = "Pa";
eleSymb[92] = "Sg";
eleSymb[93] = "Np";
eleSymb[94] = "Pu";
eleSymb[95] = "Am";
eleSymb[96] = "Cm";
eleSymb[97] = "Bk";
eleSymb[98] = "Cf";
eleSymb[99] = "Es";

////Arrays elements : 594
var spaceGroupName = new Array("select", "1, P1", "2, P-1", "3:b, P121",
		"3:b, P2", "3:c, P112", "3:a, P211", "4:b, P1211", "4:b, P21",
		"4:b*, P1211*", "4:c, P1121", "4:c*, P1121*", "4:a, P2111",
		"4:a*, P2111*", "5:b1, C121", "5:b1, C2", "5:b2, A121", "5:b3, I121",
		"5:c1, A112", "5:c2, B112", "5:c3, I112", "5:a1, B211", "5:a2, C211",
		"5:a3, I211", "6:b, P1m1", "6:b, Pm", "6:c, P11m", "6:a, Pm11",
		"7:b1, P1c1", "7:b1, Pc", "7:b2, P1n1", "7:b2, Pn", "7:b3, P1a1",
		"7:b3, Pa", "7:c1, P11a", "7:c2, P11n", "7:c3, P11b", "7:a1, Pb11",
		"7:a2, Pn11", "7:a3, Pc11", "8:b1, C1m1", "8:b1, Cm", "8:b2, A1m1",
		"8:b3, I1m1", "8:b3, Im", "8:c1, A11m", "8:c2, B11m", "8:c3, I11m",
		"8:a1, Bm11", "8:a2, Cm11", "8:a3, Im11", "9:b1, C1c1", "9:b1, Cc",
		"9:b2, A1n1", "9:b3, I1a1", "9:-b1, A1a1", "9:-b2, C1n1",
		"9:-b3, I1c1", "9:c1, A11a", "9:c2, B11n", "9:c3, I11b", "9:-c1, B11b",
		"9:-c2, A11n", "9:-c3, I11a", "9:a1, Bb11", "9:a2, Cn11", "9:a3, Ic11",
		"9:-a1, Cc11", "9:-a2, Bn11", "9:-a3, Ib11", "10:b, P12/m1",
		"10:b, P2/m", "10:c, P112/m", "10:a, P2/m11", "11:b, P121/m1",
		"11:b, P21/m", "11:b*, P121/m1*", "11:c, P1121/m", "11:c*, P1121/m*",
		"11:a, P21/m11", "11:a*, P21/m11*", "12:b1, C12/m1", "12:b1, C2/m",
		"12:b2, A12/m1", "12:b3, I12/m1", "12:b3, I2/m", "12:c1, A112/m",
		"12:c2, B112/m", "12:c3, I112/m", "12:a1, B2/m11", "12:a2, C2/m11",
		"12:a3, I2/m11", "13:b1, P12/c1", "13:b1, P2/c", "13:b2, P12/n1",
		"13:b2, P2/n", "13:b3, P12/a1", "13:b3, P2/a", "13:c1, P112/a",
		"13:c2, P112/n", "13:c3, P112/b", "13:a1, P2/b11", "13:a2, P2/n11",
		"13:a3, P2/c11", "14:b1, P121/c1", "14:b1, P21/c", "14:b2, P121/n1",
		"14:b2, P21/n", "14:b3, P121/a1", "14:b3, P21/a", "14:c1, P1121/a",
		"14:c2, P1121/n", "14:c3, P1121/b", "14:a1, P21/b11", "14:a2, P21/n11",
		"14:a3, P21/c11", "15:b1, C12/c1", "15:b1, C2/c", "15:b2, A12/n1",
		"15:b3, I12/a1", "15:b3, I2/a", "15:-b1, A12/a1", "15:-b2, C12/n1",
		"15:-b2, C2/n", "15:-b3, I12/c1", "15:-b3, I2/c", "15:c1, A112/a",
		"15:c2, B112/n", "15:c3, I112/b", "15:-c1, B112/b", "15:-c2, A112/n",
		"15:-c3, I112/a", "15:a1, B2/b11", "15:a2, C2/n11", "15:a3, I2/c11",
		"15:-a1, C2/c11", "15:-a2, B2/n11", "15:-a3, I2/b11", "16, P222",
		"17, P2221", "17*, P2221*", "17:cab, P2122", "17:bca, P2212",
		"18, P21212", "18:cab, P22121", "18:bca, P21221", "19, P212121",
		"20, C2221", "20*, C2221*", "20:cab, A2122", "20:cab*, A2122*",
		"20:bca, B2212", "21, C222", "21:cab, A222", "21:bca, B222",
		"22, F222", "23, I222", "24, I212121", "25, Pmm2", "25:cab, P2mm",
		"25:bca, Pm2m", "26, Pmc21", "26*, Pmc21*", "26:ba-c, Pcm21",
		"26:ba-c*, Pcm21*", "26:cab, P21ma", "26:-cba, P21am", "26:bca, Pb21m",
		"26:a-cb, Pm21b", "27, Pcc2", "27:cab, P2aa", "27:bca, Pb2b",
		"28, Pma2", "28*, Pma2*", "28:ba-c, Pbm2", "28:cab, P2mb",
		"28:-cba, P2cm", "28:-cba*, P2cm*", "28:bca, Pc2m", "28:a-cb, Pm2a",
		"29, Pca21", "29:ba-c, Pbc21", "29:cab, P21ab", "29:-cba, P21ca",
		"29:bca, Pc21b", "29:a-cb, Pb21a", "30, Pnc2", "30:ba-c, Pcn2",
		"30:cab, P2na", "30:-cba, P2an", "30:bca, Pb2n", "30:a-cb, Pn2b",
		"31, Pmn21", "31:ba-c, Pnm21", "31:cab, P21mn", "31:-cba, P21nm",
		"31:bca, Pn21m", "31:a-cb, Pm21n", "32, Pba2", "32:cab, P2cb",
		"32:bca, Pc2a", "33, Pna21", "33*, Pna21*", "33:ba-c, Pbn21",
		"33:ba-c*, Pbn21*", "33:cab, P21nb", "33:cab*, P21nb*",
		"33:-cba, P21cn", "33:-cba*, P21cn*", "33:bca, Pc21n",
		"33:a-cb, Pn21a", "34, Pnn2", "34:cab, P2nn", "34:bca, Pn2n",
		"35, Cmm2", "35:cab, A2mm", "35:bca, Bm2m", "36, Cmc21", "36*, Cmc21*",
		"36:ba-c, Ccm21", "36:ba-c*, Ccm21*", "36:cab, A21ma",
		"36:cab*, A21ma*", "36:-cba, A21am", "36:-cba*, A21am*",
		"36:bca, Bb21m", "36:a-cb, Bm21b", "37, Ccc2", "37:cab, A2aa",
		"37:bca, Bb2b", "38, Amm2", "38:ba-c, Bmm2", "38:cab, B2mm",
		"38:-cba, C2mm", "38:bca, Cm2m", "38:a-cb, Am2m", "39, Abm2",
		"39:ba-c, Bma2", "39:cab, B2cm", "39:-cba, C2mb", "39:bca, Cm2a",
		"39:a-cb, Ac2m", "40, Ama2", "40:ba-c, Bbm2", "40:cab, B2mb",
		"40:-cba, C2cm", "40:bca, Cc2m", "40:a-cb, Am2a", "41, Aba2",
		"41:ba-c, Bba2", "41:cab, B2cb", "41:-cba, C2cb", "41:bca, Cc2a",
		"41:a-cb, Ac2a", "42, Fmm2", "42:cab, F2mm", "42:bca, Fm2m",
		"43, Fdd2", "43:cab, F2dd", "43:bca, Fd2d", "44, Imm2", "44:cab, I2mm",
		"44:bca, Im2m", "45, Iba2", "45:cab, I2cb", "45:bca, Ic2a", "46, Ima2",
		"46:ba-c, Ibm2", "46:cab, I2mb", "46:-cba, I2cm", "46:bca, Ic2m",
		"46:a-cb, Im2a", "47, Pmmm", "48:01:00, Pnnn", "48:02:00, Pnnn",
		"49, Pccm", "49:cab, Pmaa", "49:bca, Pbmb", "50:01:00, Pban",
		"50:02:00, Pban", "50:1cab, Pncb", "50:2cab, Pncb", "50:1bca, Pcna",
		"50:2bca, Pcna", "51, Pmma", "51:ba-c, Pmmb", "51:cab, Pbmm",
		"51:-cba, Pcmm", "51:bca, Pmcm", "51:a-cb, Pmam", "52, Pnna",
		"52:ba-c, Pnnb", "52:cab, Pbnn", "52:-cba, Pcnn", "52:bca, Pncn",
		"52:a-cb, Pnan", "53, Pmna", "53:ba-c, Pnmb", "53:cab, Pbmn",
		"53:-cba, Pcnm", "53:bca, Pncm", "53:a-cb, Pman", "54, Pcca",
		"54:ba-c, Pccb", "54:cab, Pbaa", "54:-cba, Pcaa", "54:bca, Pbcb",
		"54:a-cb, Pbab", "55, Pbam", "55:cab, Pmcb", "55:bca, Pcma",
		"56, Pccn", "56:cab, Pnaa", "56:bca, Pbnb", "57, Pbcm",
		"57:ba-c, Pcam", "57:cab, Pmca", "57:-cba, Pmab", "57:bca, Pbma",
		"57:a-cb, Pcmb", "58, Pnnm", "58:cab, Pmnn", "58:bca, Pnmn",
		"59:01:00, Pmmn", "59:02:00, Pmmn", "59:1cab, Pnmm", "59:2cab, Pnmm",
		"59:1bca, Pmnm", "59:2bca, Pmnm", "60, Pbcn", "60:ba-c, Pcan",
		"60:cab, Pnca", "60:-cba, Pnab", "60:bca, Pbna", "60:a-cb, Pcnb",
		"61, Pbca", "61:ba-c, Pcab", "62, Pnma", "62:ba-c, Pmnb",
		"62:cab, Pbnm", "62:-cba, Pcmn", "62:bca, Pmcn", "62:a-cb, Pnam",
		"63, Cmcm", "63:ba-c, Ccmm", "63:cab, Amma", "63:-cba, Amam",
		"63:bca, Bbmm", "63:a-cb, Bmmb", "64, Cmca", "64:ba-c, Ccmb",
		"64:cab, Abma", "64:-cba, Acam", "64:bca, Bbcm", "64:a-cb, Bmab",
		"65, Cmmm", "65:cab, Ammm", "65:bca, Bmmm", "66, Cccm", "66:cab, Amaa",
		"66:bca, Bbmb", "67, Cmma", "67:ba-c, Cmmb", "67:cab, Abmm",
		"67:-cba, Acmm", "67:bca, Bmcm", "67:a-cb, Bmam", "68:01:00, Ccca",
		"68:02:00, Ccca", "68:1ba-c, Cccb", "68:2ba-c, Cccb", "68:1cab, Abaa",
		"68:2cab, Abaa", "68:1-cba, Acaa", "68:2-cba, Acaa", "68:1bca, Bbcb",
		"68:2bca, Bbcb", "68:1a-cb, Bbab", "68:2a-cb, Bbab", "69, Fmmm",
		"70:01:00, Fddd", "70:02:00, Fddd", "71, Immm", "72, Ibam",
		"72:cab, Imcb", "72:bca, Icma", "73, Ibca", "73:ba-c, Icab",
		"74, Imma", "74:ba-c, Immb", "74:cab, Ibmm", "74:-cba, Icmm",
		"74:bca, Imcm", "74:a-cb, Imam", "75, P4", "76, P41", "76*, P41*",
		"77, P42", "77*, P42*", "78, P43", "78*, P43*", "79, I4", "80, I41",
		"81, P-4", "82, I-4", "83, P4/m", "84, P42/m", "84*, P42/m*",
		"85:01:00, P4/n", "85:02:00, P4/n", "86:01:00, P42/n",
		"86:02:00, P42/n", "87, I4/m", "88:01:00, I41/a", "88:02:00, I41/a",
		"89, P422", "90, P4212", "91, P4122", "91*, P4122*", "92, P41212",
		"93, P4222", "93*, P4222*", "94, P42212", "95, P4322", "95*, P4322*",
		"96, P43212", "97, I422", "98, I4122", "99, P4mm", "100, P4bm",
		"101, P42cm", "101*, P42cm*", "102, P42nm", "103, P4cc", "104, P4nc",
		"105, P42mc", "105*, P42mc*", "106, P42bc", "106*, P42bc*",
		"107, I4mm", "108, I4cm", "109, I41md", "110, I41cd", "111, P-42m",
		"112, P-42c", "113, P-421m", "114, P-421c", "115, P-4m2", "116, P-4c2",
		"117, P-4b2", "118, P-4n2", "119, I-4m2", "120, I-4c2", "121, I-42m",
		"122, I-42d", "123, P4/mmm", "124, P4/mcc", "125:01:00, P4/nbm",
		"125:02:00, P4/nbm", "126:01:00, P4/nnc", "126:02:00, P4/nnc",
		"127, P4/mbm", "128, P4/mnc", "129:01:00, P4/nmm", "129:02:00, P4/nmm",
		"130:01:00, P4/ncc", "130:02:00, P4/ncc", "131, P42/mmc",
		"132, P42/mcm", "133:01:00, P42/nbc", "133:02:00, P42/nbc",
		"134:01:00, P42/nnm", "134:02:00, P42/nnm", "135, P42/mbc",
		"135*, P42/mbc*", "136, P42/mnm", "137:01:00, P42/nmc",
		"137:02:00, P42/nmc", "138:01:00, P42/ncm", "138:02:00, P42/ncm",
		"139, I4/mmm", "140, I4/mcm", "141:01:00, I41/amd",
		"141:02:00, I41/amd", "142:01:00, I41/acd", "142:02:00, I41/acd",
		"143, P3", "144, P31", "145, P32", "146:h, R3", "146:r, R3",
		"147, P-3", "148:h, R-3", "148:r, R-3", "149, P312", "150, P321",
		"151, P3112", "152, P3121", "153, P3212", "154, P3221", "155:h, R32",
		"155:r, R32", "156, P3m1", "157, P31m", "158, P3c1", "159, P31c",
		"160:h, R3m", "160:r, R3m", "161:h, R3c", "161:r, R3c", "162, P-31m",
		"163, P-31c", "164, P-3m1", "165, P-3c1", "166:h, R-3m", "166:r, R-3m",
		"167:h, R-3c", "167:r, R-3c", "168, P6", "169, P61", "170, P65",
		"171, P62", "172, P64", "173, P63", "173*, P63*", "174, P-6",
		"175, P6/m", "176, P63/m", "176*, P63/m*", "177, P622", "178, P6122",
		"179, P6522", "180, P6222", "181, P6422", "182, P6322", "182*, P6322*",
		"183, P6mm", "184, P6cc", "185, P63cm", "185*, P63cm*", "186, P63mc",
		"186*, P63mc*", "187, P-6m2", "188, P-6c2", "189, P-62m", "190, P-62c",
		"191, P6/mmm", "192, P6/mcc", "193, P63/mcm", "193*, P63/mcm*",
		"194, P63/mmc", "194*, P63/mmc*", "195, P23", "196, F23", "197, I23",
		"198, P213", "199, I213", "200, Pm-3", "201:01:00, Pn-3",
		"201:02:00, Pn-3", "202, Fm-3", "203:01:00, Fd-3", "203:02:00, Fd-3",
		"204, Im-3", "205, Pa-3", "206, Ia-3", "207, P432", "208, P4232",
		"209, F432", "210, F4132", "211, I432", "212, P4332", "213, P4132",
		"214, I4132", "215, P-43m", "216, F-43m", "217, I-43m", "218, P-43n",
		"219, F-43c", "220, I-43d", "221, Pm-3m", "222:01:00, Pn-3n",
		"222:02:00, Pn-3n", "223, Pm-3n", "224:01:00, Pn-3m",
		"224:02:00, Pn-3m", "225, Fm-3m", "226, Fm-3c", "227:01:00, Fd-3m",
		"227:02:00, Fd-3m", "228:01:00, Fd-3c", "228:02:00, Fd-3c",
		"229, Im-3m", "230, Ia-3d");

var spaceGroupValue = new Array("select", "1", "2", "3:b", "3:b", "3:c", "3:a",
		"4:b", "4:b", "4:b*", "4:c", "4:c*", "4:a", "4:a*", "5:b1", "5:b1",
		"5:b2", "5:b3", "5:c1", "5:c2", "5:c3", "5:a1", "5:a2", "5:a3", "6:b",
		"6:b", "6:c", "6:a", "7:b1", "7:b1", "7:b2", "7:b2", "7:b3", "7:b3",
		"7:c1", "7:c2", "7:c3", "7:a1", "7:a2", "7:a3", "8:b1", "8:b1", "8:b2",
		"8:b3", "8:b3", "8:c1", "8:c2", "8:c3", "8:a1", "8:a2", "8:a3", "9:b1",
		"9:b1", "9:b2", "9:b3", "9:-b1", "9:-b2", "9:-b3", "9:c1", "9:c2",
		"9:c3", "9:-c1", "9:-c2", "9:-c3", "9:a1", "9:a2", "9:a3", "9:-a1",
		"9:-a2", "9:-a3", "10:b", "10:b", "10:c", "10:a", "11:b", "11:b",
		"11:b*", "11:c", "11:c*", "11:a", "11:a*", "12:b1", "12:b1", "12:b2",
		"12:b3", "12:b3", "12:c1", "12:c2", "12:c3", "12:a1", "12:a2", "12:a3",
		"13:b1", "13:b1", "13:b2", "13:b2", "13:b3", "13:b3", "13:c1", "13:c2",
		"13:c3", "13:a1", "13:a2", "13:a3", "14:b1", "14:b1", "14:b2", "14:b2",
		"14:b3", "14:b3", "14:c1", "14:c2", "14:c3", "14:a1", "14:a2", "14:a3",
		"15:b1", "15:b1", "15:b2", "15:b3", "15:b3", "15:-b1", "15:-b2",
		"15:-b2", "15:-b3", "15:-b3", "15:c1", "15:c2", "15:c3", "15:-c1",
		"15:-c2", "15:-c3", "15:a1", "15:a2", "15:a3", "15:-a1", "15:-a2",
		"15:-a3", "16", "17", "17*", "17:cab", "17:bca", "18", "18:cab",
		"18:bca", "19", "20", "20*", "20:cab", "20:cab*", "20:bca", "21",
		"21:cab", "21:bca", "22", "23", "24", "25", "25:cab", "25:bca", "26",
		"26*", "26:ba-c", "26:ba-c*", "26:cab", "26:-cba", "26:bca", "26:a-cb",
		"27", "27:cab", "27:bca", "28", "28*", "28:ba-c", "28:cab", "28:-cba",
		"28:-cba*", "28:bca", "28:a-cb", "29", "29:ba-c", "29:cab", "29:-cba",
		"29:bca", "29:a-cb", "30", "30:ba-c", "30:cab", "30:-cba", "30:bca",
		"30:a-cb", "31", "31:ba-c", "31:cab", "31:-cba", "31:bca", "31:a-cb",
		"32", "32:cab", "32:bca", "33", "33*", "33:ba-c", "33:ba-c*", "33:cab",
		"33:cab*", "33:-cba", "33:-cba*", "33:bca", "33:a-cb", "34", "34:cab",
		"34:bca", "35", "35:cab", "35:bca", "36", "36*", "36:ba-c", "36:ba-c*",
		"36:cab", "36:cab*", "36:-cba", "36:-cba*", "36:bca", "36:a-cb", "37",
		"37:cab", "37:bca", "38", "38:ba-c", "38:cab", "38:-cba", "38:bca",
		"38:a-cb", "39", "39:ba-c", "39:cab", "39:-cba", "39:bca", "39:a-cb",
		"40", "40:ba-c", "40:cab", "40:-cba", "40:bca", "40:a-cb", "41",
		"41:ba-c", "41:cab", "41:-cba", "41:bca", "41:a-cb", "42", "42:cab",
		"42:bca", "43", "43:cab", "43:bca", "44", "44:cab", "44:bca", "45",
		"45:cab", "45:bca", "46", "46:ba-c", "46:cab", "46:-cba", "46:bca",
		"46:a-cb", "47", "48:01:00", "48:02:00", "49", "49:cab", "49:bca",
		"50:01:00", "50:02:00", "50:1cab", "50:2cab", "50:1bca", "50:2bca",
		"51", "51:ba-c", "51:cab", "51:-cba", "51:bca", "51:a-cb", "52",
		"52:ba-c", "52:cab", "52:-cba", "52:bca", "52:a-cb", "53", "53:ba-c",
		"53:cab", "53:-cba", "53:bca", "53:a-cb", "54", "54:ba-c", "54:cab",
		"54:-cba", "54:bca", "54:a-cb", "55", "55:cab", "55:bca", "56",
		"56:cab", "56:bca", "57", "57:ba-c", "57:cab", "57:-cba", "57:bca",
		"57:a-cb", "58", "58:cab", "58:bca", "59:01:00", "59:02:00", "59:1cab",
		"59:2cab", "59:1bca", "59:2bca", "60", "60:ba-c", "60:cab", "60:-cba",
		"60:bca", "60:a-cb", "61", "61:ba-c", "62", "62:ba-c", "62:cab",
		"62:-cba", "62:bca", "62:a-cb", "63", "63:ba-c", "63:cab", "63:-cba",
		"63:bca", "63:a-cb", "64", "64:ba-c", "64:cab", "64:-cba", "64:bca",
		"64:a-cb", "65", "65:cab", "65:bca", "66", "66:cab", "66:bca", "67",
		"67:ba-c", "67:cab", "67:-cba", "67:bca", "67:a-cb", "68:01:00",
		"68:02:00", "68:1ba-c", "68:2ba-c", "68:1cab", "68:2cab", "68:1-cba",
		"68:2-cba", "68:1bca", "68:2bca", "68:1a-cb", "68:2a-cb", "69",
		"70:01:00", "70:02:00", "71", "72", "72:cab", "72:bca", "73",
		"73:ba-c", "74", "74:ba-c", "74:cab", "74:-cba", "74:bca", "74:a-cb",
		"75", "76", "76*", "77", "77*", "78", "78*", "79", "80", "81", "82",
		"83", "84", "84*", "85:01:00", "85:02:00", "86:01:00", "86:02:00",
		"87", "88:01:00", "88:02:00", "89", "90", "91", "91*", "92", "93",
		"93*", "94", "95", "95*", "96", "97", "98", "99", "100", "101", "101*",
		"102", "103", "104", "105", "105*", "106", "106*", "107", "108", "109",
		"110", "111", "112", "113", "114", "115", "116", "117", "118", "119",
		"120", "121", "122", "123", "124", "125:01:0", "125:02:0", "126:01:0",
		"126:02:0", "127", "128", "129:01:0", "129:02:0", "130:01:0",
		"130:02:0", "131", "132", "133:01:0", "133:02:0", "134:01:0",
		"134:02:0", "135", "135*", "136", "137:01:0", "137:02:0", "138:01:0",
		"138:02:0", "139", "140", "141:01:0", "141:02:0", "142:01:0",
		"142:02:0", "143", "144", "145", "146:h", "146:r", "147", "148:h",
		"148:r", "149", "150", "151", "152", "153", "154", "155:h", "155:r",
		"156", "157", "158", "159", "160:h", "160:r", "161:h", "161:r", "162",
		"163", "164", "165", "166:h", "166:r", "167:h", "167:r", "168", "169",
		"170", "171", "172", "173", "173*", "174", "175", "176", "176*", "177",
		"178", "179", "180", "181", "182", "182*", "183", "184", "185", "185*",
		"186", "186*", "187", "188", "189", "190", "191", "192", "193", "193*",
		"194", "194*", "195", "196", "197", "198", "199", "200", "201:01:0",
		"201:02:0", "202", "203:01:0", "203:02:0", "204", "205", "206", "207",
		"208", "209", "210", "211", "212", "213", "214", "215", "216", "217",
		"218", "219", "220", "221", "222:01:0", "222:02:0", "223", "224:01:0",
		"224:02:0", "225", "226", "227:01:0", "227:02:0", "228:01:0",
		"228:02:0", "229", "230");

var spaceGroupChk = new Array("1", "0", "0", "0", "0", "0", "0", "0", "0", "0",
		"0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0",
		"0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0",
		"0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0",
		"0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0",
		"0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0",
		"0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0",
		"0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0",
		"0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0",
		"0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0",
		"0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0",
		"0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0",
		"0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0",
		"0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0",
		"0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0",
		"0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0",
		"0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0",
		"0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0",
		"0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0",
		"0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0",
		"0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0",
		"0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0",
		"0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0",
		"0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0",
		"0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0",
		"0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0",
		"0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0",
		"0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0",
		"0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0",
		"0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0",
		"0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0",
		"0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0",
		"0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0",
		"0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0",
		"0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0",
		"0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0",
		"0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0",
		"0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0",
		"0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0",
		"0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0",
		"0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0",
		"0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0",
		"0", "0", "0", "0", "0", "0", "0", "0", "0", "0");

var eleSymbMass = new Array();
eleSymbMass[0] = "select";
eleSymbMass[1] = 1.00;
eleSymbMass[2] = 4.00;
eleSymbMass[3] = 6.94;
eleSymbMass[4] = 9.01;
eleSymbMass[5] = 10.81;
eleSymbMass[6] = 12.01;
eleSymbMass[7] = 14.01;
eleSymbMass[8] = 16.00;
eleSymbMass[9] = 19.00;
eleSymbMass[10] = 20.18;
eleSymbMass[11] = 22.99;
eleSymbMass[12] = 24.31;
eleSymbMass[13] = 26.98;
eleSymbMass[14] = 28.09;
eleSymbMass[15] = 30.97;
eleSymbMass[16] = 32.06;
eleSymbMass[17] = 35.45;
eleSymbMass[18] = 39.95;
eleSymbMass[19] = 39.10;
eleSymbMass[20] = 40.08;
eleSymbMass[21] = 44.96;
eleSymbMass[22] = 47.88;
eleSymbMass[23] = 50.94;
eleSymbMass[24] = 52.00;
eleSymbMass[25] = 54.94;
eleSymbMass[26] = 55.85;
eleSymbMass[27] = 58.93;
eleSymbMass[28] = 58.69;
eleSymbMass[29] = 63.55;
eleSymbMass[30] = 65.38;
eleSymbMass[31] = 69.72;
eleSymbMass[32] = 72.59;
eleSymbMass[33] = 74.92;
eleSymbMass[34] = 78.96;
eleSymbMass[35] = 79.90;
eleSymbMass[36] = 83.80;
eleSymbMass[37] = 85.47;
eleSymbMass[38] = 87.62;
eleSymbMass[39] = 88.91;
eleSymbMass[40] = 91.22;
eleSymbMass[41] = 92.91;
eleSymbMass[42] = 95.94;
eleSymbMass[43] = 98.00;
eleSymbMass[44] = 101.07;
eleSymbMass[45] = 102.91;
eleSymbMass[46] = 106.42;
eleSymbMass[47] = 107.87;
eleSymbMass[48] = 112.41;
eleSymbMass[49] = 114.82;
eleSymbMass[50] = 118.69;
eleSymbMass[51] = 121.75;
eleSymbMass[52] = 127.60;
eleSymbMass[53] = 126.90;
eleSymbMass[54] = 131.29;
eleSymbMass[55] = 132.91;
eleSymbMass[56] = 137.34;
eleSymbMass[57] = 138.91;
eleSymbMass[58] = 140.12;
eleSymbMass[59] = 140.91;
eleSymbMass[60] = 144.24;
eleSymbMass[61] = 145.00;
eleSymbMass[62] = 150.36;
eleSymbMass[63] = 151.96;
eleSymbMass[64] = 157.25;
eleSymbMass[65] = 158.93;
eleSymbMass[66] = 162.50;
eleSymbMass[67] = 164.93;
eleSymbMass[68] = 167.26;
eleSymbMass[69] = 168.93;
eleSymbMass[70] = 173.04;
eleSymbMass[71] = 174.97;
eleSymbMass[72] = 178.49;
eleSymbMass[73] = 180.95;
eleSymbMass[74] = 183.85;
eleSymbMass[75] = 186.21;
eleSymbMass[76] = 190.20;
eleSymbMass[77] = 192.22;
eleSymbMass[78] = 195.09;
eleSymbMass[79] = 196.97;
eleSymbMass[80] = 200.59;
eleSymbMass[81] = 204.38;
eleSymbMass[82] = 207.19;
eleSymbMass[83] = 208.98;
eleSymbMass[84] = 209.00;
eleSymbMass[85] = 210.00;
eleSymbMass[86] = 222.00;
eleSymbMass[87] = 223.00;
eleSymbMass[88] = 226.00;
eleSymbMass[89] = 227.00;
eleSymbMass[90] = 232.04;
eleSymbMass[91] = 231.04;
eleSymbMass[92] = 238.04;
eleSymbMass[93] = 237.05;
eleSymbMass[94] = 244.00;
eleSymbMass[95] = 243.00;
eleSymbMass[96] = 247.00;
eleSymbMass[97] = 247.00;
eleSymbMass[98] = 251.00;
eleSymbMass[99] = 252.00;
      		
///js// Js/castepfunction.js /////
/*  J-ICE library 

    based on:
 *
 * Copyright (C) 2010-2014 Pieremanuele Canepa http://j-ice.sourceforge.net/
 *
 * Contact: pierocanepa@sourceforge.net
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA
 *  02111-1307  USA.
 */

//CASTEP Js.
/*! Al metal in non-primitive FCC Unit cell

 %block LATTICE_CART ! In Angstroms
 4.0495 0.0    0.00
 0.00   4.0495 0.00
 0.00   0.00   4.0495
 %endblock LATTICE_CART
 %block POSITIONS_FRAC
 Al  0.0000000000    0.0000000000    0.0000000000
 Al  0.0000000000    0.5000000000    0.5000000000
 Al  0.5000000000    0.5000000000    0.0000000000
 Al  0.5000000000    0.0000000000    0.5000000000
 %endblock POSITIONS_FRAC
 kpoints_mp_grid 4 4 4
 fix_all_ions true
 fix_all_cell true
 %BLOCK SPECIES_POT
 %ENDBLOCK SPECIES_POT
 */

var cellCastep = null;
var positionCastep = null;

function exportCASTEP() {
	warningMsg("Make sure you had selected the model you would like to export.");

	setUnitCell();
	fromfractionaltoCartesian();
	saveStatejust();
	setVacuum();

	switch (typeSystem) {
	case "slab":
		setV(selectedFrame + '.z = for(i;' + selectedFrame + '; i.z/'
				+ roundNumber(cCell) + ')');
		break;
	case "polymer":
		setV(selectedFrame + '.z = for(i;' + selectedFrame + '; i.z/'
				+ roundNumber(cCell) + ')');
		setV(selectedFrame + '.y = for(i;' + selectedFrame + '; i.y/'
				+ roundNumber(bCell) + ')');
		break;
	case "molecule":
		setV(selectedFrame + '.z = for(i;' + selectedFrame + '; i.z/'
				+ roundNumber(cCell) + ')');
		setV(selectedFrame + '.y = for(i;' + selectedFrame + '; i.y/'
				+ roundNumber(bCell) + ')');
		setV(selectedFrame + '.x = for(i;' + selectedFrame + '; i.x/'
				+ roundNumber(aCell) + ')');
		break;
	}

	prepareLatticeblockcastep();
	prepareCoordinateblockCastep();

	var finalInputCastep = "var final = [latticeCastep, positionCastep];"
			+ 'final = final.replace("\n\n","\n");'
			+ 'WRITE VAR final "?.cell"';
	setV(finalInputCastep);
	loadStatejust();
}

function prepareLatticeblockcastep() {
	cellCastep = "var latticeHeader = '\%block LATTICE_CART';"
			+ "var latticeOne = ["
			+ xx
			+ ", "
			+ xy
			+ ", "
			+ xz
			+ "];"
			+ "var latticeOne = latticeOne.join(' ');"
			+ "var latticeTwo = ["
			+ yx
			+ ", "
			+ yy
			+ ", "
			+ yz
			+ "];"
			+ "var latticeTwo = latticeTwo.join(' ');"
			+ "var latticeThree = ["
			+ zx
			+ ", "
			+ zy
			+ ", "
			+ zz
			+ "];"
			+ "var latticeThree = latticeThree.join(' ');"
			+ "var latticeClose = '\%endblock LATTICE_CART';"
			+ "latticeCastep = [latticeHeader, latticeOne, latticeTwo,latticeThree, latticeClose];"
	setV(cellCastep);
}

// /Frac coordinates
function prepareCoordinateblockCastep() {
	positionCastep = "var positionHeader = '\%block POSITIONS_FRAC';"
			+ 'var xyzCoord = ' + selectedFrame + '.label("%e %16.9[fxyz]");'
			+ 'xyzCoord = xyzCoord.replace("\n\n","\n");'
			+ "var positionClose = '\%endblock POSITIONS_FRAC';"
			+ "positionCastep = [positionHeader, xyzCoord, positionClose];"
			+ 'positionCastep = positionCastep.replace("\n\n","\n");'
	setV(positionCastep);
}

// /// FUNCTION LOAD

function onClickLoadCastep() {
	setV("load ?; set defaultDirectory; set messageCallback 'myLoadCastep'; message CASTEPDONE; set echo top left; echo loading... HOLD ON; refresh; echo;");
	// alert("Castep Output");
}

function myLoadCastep(a, m) {
	m = "" + m;
	// important to do this to change from Java string to JavaScript string
	if (m.indexOf("CASTEPDONE") == 0) {
		setV("echo");
		loadModelsCastep();
		setName();
		setTitleEcho();
	}
}

function loadModelsCastep() {
	var counterFreq = 0;
	var counterMD = 0;
	extractAuxiliaryJmol();
	cleanandReloadfrom();
	getUnitcell("1");
	selectDesireModel("1");

	for (i = 0; i < Info.length; i++) {
		if (Info[i].name != null) {
			var line = Info[i].name;
			// alert(line)
			if (line.search(/Energy =/i) != -1) {
				addOption(getbyID("geom"), i + " " + line, i + 1);
				geomData[i] = line;
				counterFreq++;
			} else if (line.search(/cm-1/i) != -1) {
				alert("here")
				freqData[i - counterFreq] = line;
				counterMD++;
			}
		}
	}

	if (freqData != null) {
		for (i = 1; i < freqData.length; i++) {
			if (freqData[i] != null)
				var data = parseFloat(freqData[i].substring(0, freqData[i]
						.indexOf("c") - 1));
			addOption(getbyID("vib"), i + " A " + data + " cm^-1", i
					+ counterFreq + 1);
		}
	}
	disableFreqOpts();
	symmetryModeAdd();
	setMaxMinPlot();
	getSymInfo();
	setName();
}

// ///////LOAD FUNCTIONS

function disableFreqOpts() {
	for ( var i = 0; i < document.modelsVib.modAct.length; i++)
		document.modelsVib.modAct[i].disabled = true;
	for ( var i = 0; i < document.modelsVib.kindspectra.length; i++)
		document.modelsVib.kindspectra[i].disabled = true;

	// getbyID("modAct").enable = false;
	// makeDisable("modAct");
	// makeDisable("vibSym");
	// makeDisable("reload");
}

function enableFreqOpts() {
	for ( var i = 0; i < document.modelsVib.modAct.length; i++)
		document.modelsVib.modAct[i].disabled = false;
	for ( var i = 0; i < document.modelsVib.kindspectra.length; i++)
		document.modelsVib.kindspectra[i].disabled = false;

}

// /// COVERT FUNCTION

function substringEnergyCastepToFloat(value) {
	if (value != null) {
		var grab = parseFloat(
				value.substring(value.indexOf('=') + 1, value.indexOf('e') - 1))
				.toPrecision(8); // Enthaply = -26.45132096 eV
		grab = grab * 96.485; // constant from
		// http://web.utk.edu/~rcompton/constants
		grab = Math.round(grab * 100000000) / 100000000;
		//alert(grab)
	}
	return grab;
}

/////END FUNCTIONS
      		
///js// Js/crystalfunction.js /////
/*  J-ICE library 

    based on:
 *
 * Copyright (C) 2010-2014 Pieremanuele Canepa http://j-ice.sourceforge.net/
 *
 * Contact: pierocanepa@sourceforge.net
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA
 *  02111-1307  USA.
 */

////The following functions are to control import/ export, geometry optimization, frequency properties.
/////////
////////////////SAVE INPUT
/////////
var titleCRYS = null;
function titleCRYSTAL() {
	titleCRYS = prompt("Type here the job title:", "");
	(titleCRYS == "" || titleCRYS == null) ? (titleCRYS = ' .d12 prepared with J-ICE ')
			: (titleCRYS = titleCRYS + ' .d12 prepared with J-ICE')
}

var numAtomCRYSTAL = null;
var fractionalCRYSTAL = null;
function atomCRYSTAL() {
	if (typeSystem == "molecule")
		fractionalCRYSTAL = selectedFrame + '.label("%l %16.9[xyz]")';
	setV("print " + fractionalCRYSTAL)
	// alert(typeSystem);

	numAtomCRYSTAL = selectedFrame + ".length";
	fractionalCRYSTAL = selectedFrame + '.label("%l %16.9[fxyz]")';
	// alert(typeSystem);
}

var systemCRYSTAL = null;
var keywordCRYSTAL = null;
var symmetryCRYSTAL = null;
function exportCRYSTAL() {
	// alert("CRYSTAL")
	var endCRYSTAL = "TEST', 'END";
	var script = "";

	warningMsg("Make sure you had selected the model you would like to export.")
	titleCRYSTAL();
	setUnitCell();
	atomCRYSTAL();

	switch (typeSystem) {
	case "crystal":
		systemCRYSTAL = "'CRYSTAL'";
		keywordCRYSTAL = "'0 0 0'";
		symmetryCRYSTAL = "'1'";

		if (!flagSiesta && !flagOutcar && !flagCryVasp)
			var flagsymmetry = confirm("Do you want to introduce symmetry ?")
		if (!flagsymmetry) {
			script = "var cellp = ["
					+ roundNumber(aCell)
					+ ", "
					+ roundNumber(bCell)
					+ ", "
					+ roundNumber(cCell)
					+ ", "
					+ roundNumber(alpha)
					+ ", "
					+ roundNumber(beta)
					+ ", "
					+ roundNumber(gamma)
					+ "];"
					+ 'var cellparam = cellp.join(" ");'
					+ 'cellparam = cellparam.replace("\n\n","\n");'
					+ "var crystalArr = ['"
					+ titleCRYS
					+ "', "
					+ systemCRYSTAL
					+ ", "
					+ keywordCRYSTAL
					+ ", "
					+ symmetryCRYSTAL
					+ "];"
					+ "var crystalRestArr = ["
					+ numAtomCRYSTAL
					+ ", "
					+ fractionalCRYSTAL
					+ ", '"
					+ endCRYSTAL
					+ "'];"
					+ 'var finalArr = [crystalArr, cellparam , crystalRestArr];'
					+ 'finalArr = finalArr.replace("\n\n","\n");'
					+ 'WRITE VAR finalArr "?.d12"';
		} else {
			warningMsg("This procedure is not fully tested.");
			figureOutSpaceGroup();
		}
		break;
	case "slab":
		systemCRYSTAL = "'SLAB'";
		keywordCRYSTAL = "";
		symmetryCRYSTAL = "'1'";

		warningMsg("Symmetry not exploited!");

		script = "var cellp = [" + roundNumber(aCell) + ", "
				+ roundNumber(bCell) + ", " + roundNumber(gamma) + "];"
				+ 'var cellparam = cellp.join(" ");' + "var crystalArr = ['"
				+ titleCRYS + "', " + systemCRYSTAL + ", " + symmetryCRYSTAL
				+ "];" + 'crystalArr = crystalArr.replace("\n\n","\n");'
				+ "var crystalRestArr = [" + numAtomCRYSTAL + ", "
				+ fractionalCRYSTAL + ", '" + endCRYSTAL + "'];"
				+ 'crystalRestArr = crystalRestArr.replace("\n\n","\n");'
				+ 'var finalArr = [crystalArr, cellparam , crystalRestArr];'
				+ 'finalArr = finalArr.replace("\n\n","\n");'
				+ 'WRITE VAR finalArr "?.d12"';
		break;
	case "polymer":
		systemCRYSTAL = "'POLYMER'";
		keywordCRYSTAL = "";
		symmetryCRYSTAL = "'1'";

		warningMsg("Symmetry not exploited!");

		script = "var cellp = " + roundNumber(aCell) + ";"
				+ "var crystalArr = ['" + titleCRYS + "', " + systemCRYSTAL
				+ ", " + symmetryCRYSTAL + "];"
				+ 'crystalArr = crystalArr.replace("\n\n","\n");'
				+ "var crystalRestArr = [" + numAtomCRYSTAL + ", "
				+ fractionalCRYSTAL + ", '" + endCRYSTAL + "'];"
				+ 'crystalRestArr = crystalRestArr.replace("\n\n","\n");'
				+ 'var finalArr = [crystalArr, cellp , crystalRestArr];'
				+ 'finalArr = finalArr.replace("\n\n","\n");'
				+ 'WRITE VAR finalArr "?.d12"';
		break;
	case "molecule":
		// alert("prov")
		systemCRYSTAL = "'MOLECULE'";
		symmetryCRYSTAL = "'1'"; // see how jmol exploits the punctual TODO:
		// show POINTGROUP
		// symmetry
		fractionalCRYSTAL
		warningMsg("Symmetry not exploited!");
		script = "var crystalArr = ['" + titleCRYS + "', " + systemCRYSTAL
				+ ", " + symmetryCRYSTAL + "];"
				+ 'crystalArr = crystalArr.replace("\n\n","\n");'
				+ "var crystalRestArr = [" + numAtomCRYSTAL + ", "
				+ fractionalCRYSTAL + ", '" + endCRYSTAL + "'];"
				+ 'crystalRestArr = crystalRestArr.replace("\n\n","\n");'
				+ 'var finalArr = [crystalArr, crystalRestArr];'
				+ 'finalArr = finalArr.replace("\n\n","\n");'
				+ 'WRITE VAR finalArr "?.d12"';
		break;
	}// end switch
	script = script.replace("\n\n", "\n");
	setV(script);
}

//prevSelectedframe needs because of the conventional
var prevSelectedframe = null;
var prevFrame = null;
function figureOutSpaceGroup() {
	saveStatejust();
	prevSelectedframe = selectedFrame;
	if (frameValue == null || frameValue == "" || flagCif)
		framValue = 1;
	prevFrame = frameValue;
	setV('set errorCallback "errCallback";')
	magnetic = confirm('It\'s the primitive cell ?')
	// crystalPrev = confirm('Does the structure come from a previous CRYSTAL
	// calcultion?')
	if (magnetic) { // This option is for quantum espresso
		if (flagCryVasp) {
			setV("load '' FILTER 'conv'; delete not cell=555; set messageCallback 'saveSpacegroup'; message SAVESPACE;");
		} else {
			setV("load ''; delete not cell=555; set messageCallback 'saveSpacegroup'; message SAVESPACE;");
		}
	} else {
		if (flagCryVasp) {
			setV("load '' FILTER 'conv'; set messageCallback 'saveSpacegroup'; message SAVESPACE;");
		} else {
			setV("load ''; set messageCallback 'saveSpacegroup'; message SAVESPACE;");
		}
	}
}

var interNumber = "";
function saveSpacegroup(a, m) {

	m = "" + m
	// important to do this to change from Java string to JavaScript string
	if (m.indexOf("SAVESPACE") == 0) {
		var s = ""
		var info = jmolEvaluate('script("show spacegroup")')
		if (info.indexOf("x,") < 0) {
			s = "no space group"
		} else {
			var S = info.split("\n")
			for ( var i = 0; i < S.length; i++) {
				var line = S[i].split(":")
				if (line[0].indexOf("international table number") == 0)
					s = parseInt(S[i]
							.replace(/international table number:/, ""));
			}
		}
		interNumber = parseInt(s);
		getUnitcell(prevFrame);

		findCellParameters()

	}

}

var stringCellParam;
//cellDimString and ibravQ is for quantum espresso
var cellDimString = null;
var ibravQ = "";
function findCellParameters() {
	// /from crystal manual http://www.crystal.unito.it/Manuals/crystal09.pdf
	switch (true) {

	case ((interNumber <= 2)): // Triclinic lattices

		stringCellParam = roundNumber(aCell) + ", " + roundNumber(bCell) + ", "
				+ roundNumber(cCell) + ", " + roundNumber(alpha) + ", "
				+ roundNumber(beta) + ", " + roundNumber(gamma);
		cellDimString = " celdm(1) =  " + fromAngstromtoBohr(aCell)
				+ " \n celdm(2) =  " + roundNumber(bCell / aCell)
				+ " \n celdm(3) =  " + roundNumber(cCell / aCell)
				+ " \n celdm(4) =  " + cosRadiant(alpha) + " \n celdm(5) =  "
				+ roundNumber(cosRadiant(beta)) + " \n celdm(6) =  "
				+ roundNumber(cosRadiant(gamma)) + " \n\n";
		ibravQ = "14";
		break;

	case ((interNumber > 2) && (interNumber <= 15)): // Monoclinic lattices
		stringCellParam = roundNumber(aCell) + ", " + roundNumber(bCell) + ", "
				+ roundNumber(cCell) + ", " + roundNumber(alpha);
		if (!flagCryVasp && quantumEspresso) {
			cellDimString = " celdm(1) =  " + fromAngstromtoBohr(aCell)
					+ " \n celdm(2) =  " + roundNumber(bCell / aCell)
					+ " \n celdm(3) =  " + roundNumber(cCell / aCell)
					+ " \n celdm(4) =  " + roundNumber(cosRadiant(alpha))
					+ " \n\n";
			ibravQ = "12"; // Monoclinic base centered

			var question = confirm("Is this a Monoclinic base centered lattice?")
			if (question)
				ibravQ = "13";
		}
		break;

	case ((interNumber > 15) && (interNumber <= 74)): // Orthorhombic lattices
		stringCellParam = roundNumber(aCell) + ", " + roundNumber(bCell) + ", "
				+ roundNumber(cCell);
		if (!flagCryVasp && quantumEspresso) {
			cellDimString = " celdm(1) = " + fromAngstromtoBohr(aCell)
					+ " \n celdm(2) =  " + roundNumber(bCell / aCell)
					+ " \n celdm(3) =  " + roundNumber(cCell / aCell) + " \n\n";
			ibravQ = "8";

			var question = confirm("Is this a Orthorhombic base-centered lattice?")
			if (question) {
				ibravQ = "9";
			} else {
				var questionfcc = confirm("Is this a Orthorhombic face-centered (fcc) lattice?");
				if (questionfcc) {
					ibravQ = "10";
				} else {
					ibravQ = "11";// Orthorhombic body-centered
				}
			}

		}
		break;

	case ((interNumber > 74) && (interNumber <= 142)): // Tetragonal lattices

		stringCellParam = roundNumber(aCell) + ", " + roundNumber(cCell);
		if (!flagCryVasp && quantumEspresso) {
			cellDimString = " celdm(1) = " + fromAngstromtoBohr(aCell)
					+ " \n celdm(3) =  " + roundNumber(cCell / aCell) + " \n\n";
			ibravQ = "6";
			var question = confirm("Is this a Tetragonal I body centered (bct) lattice?");
			if (question)
				ibravQ = "7";
		}
		break;

	case ((interNumber > 142) && (interNumber <= 167)): // Trigonal lattices
		stringCellParam = roundNumber(aCell) + ", " + roundNumber(alpha) + ", "
				+ roundNumber(beta) + ", " + roundNumber(gamma);
		cellDimString = " celdm(1) = " + fromAngstromtoBohr(aCell)
				+ " \n celdm(4) =  " + roundNumber(cosRadiant(alpha))
				+ " \n celdm(5) = " + roundNumber(cosRadiant(beta))
				+ " \n celdm(6) =  " + roundNumber(cosRadiant(gamma));
		ibravQ = "5";
		var question = confirm("Is a romboheadral lattice?")
		if (question) {
			stringCellParam = roundNumber(aCell) + ", " + roundNumber(cCell);
			cellDimString = " celdm(1) = " + fromAngstromtoBohr(aCell)
					+ " \n celdm(4) =  " + roundNumber(cosRadiant(alpha))
					+ " \n celdm(5) = " + roundNumber(cosRadiant(beta))
					+ " \n celdm(6) =  " + roundNumber(cosRadiant(gamma))
					+ " \n\n";
			ibravQ = "4";
		}
		break;

	case ((interNumber > 167) && (interNumber <= 194)): // Hexagonal lattices
		stringCellParam = roundNumber(aCell) + ", " + roundNumber(cCell);
		if (!flagCryVasp && quantumEspresso) {
			cellDimString = " celdm(1) = " + fromAngstromtoBohr(aCell)
					+ " \n celdm(3) = " + roundNumber(cCell / aCell) + " \n\n";
			ibravQ = "4";
		}
		break;
	titleCRYS == ""
case ((interNumber > 194) && (interNumber <= 230)): // Cubic lattices
	stringCellParam = roundNumber(aCell);
	if (!flagCryVasp && quantumEspresso) {
		cellDimString = " celdm(1) = " + fromAngstromtoBohr(aCell);
		// alert("I am here");
		ibravQ = "1";
		var question = confirm("Is a face centered cubic lattice?")
		if (question) {
			var questionBase = confirm("Is a body centered cubic lattice?")
			if (questionBase) {
				ibravQ = "3";
			} else {
				ibravQ = "2";
			}
		}

	}
	break;

default:
	errorMsg("SpaceGroup not found in range.");
	return false;
	break;

}// end switch

stringCellparamgulp = roundNumber(aCell) + ' ' + roundNumber(bCell) + ' '
		+ roundNumber(cCell) + ' ' + roundNumber(alpha) + ' '
		+ roundNumber(beta) + ' ' + roundNumber(gamma);
//	alert(stringCellparamgulp)
if (flagCryVasp)
	savCRYSTALSpace();

if (!flagGulp) {
	setV('set errorCallback "errCallback"');
	setV("load '' filter 'primitive'");
	loadStatejust();
}
}

function savCRYSTALSpace() {
var endCRYSTAL = "TEST', 'END";
//	alert(aCell + " " + bCell);
script = "var cellp = [" + stringCellParam + "];"
		+ 'var cellparam = cellp.join(" ");' + "var crystalArr = ['"
		+ titleCRYS + "', " + systemCRYSTAL + ", " + keywordCRYSTAL + ", "
		+ interNumber + "];" + 'crystalArr = crystalArr.replace("\n\n"," ");'
		+ "var crystalRestArr = [" + numAtomCRYSTAL + ", " + fractionalCRYSTAL
		+ ", '" + endCRYSTAL + "'];"
		+ 'crystalRestArr = crystalRestArr.replace("\n\n"," ");'
		+ 'var finalArr = [crystalArr, cellparam , crystalRestArr];'
		+ 'finalArr = finalArr.replace("\n\n","\n");'
		+ 'WRITE VAR finalArr "?.d12"';
setV(script);

}

////////////////////////END SAVE INPUT

/////////////////////////
///////////////////////// LOAD & ON LOAD functions

function onClickLoadStruc() {
setV("load ? PACKED; set messageCallback 'myMessageCryCallback'; message CRYDONE; set echo top left; echo loading... HOLD ON;refresh; echo;");
//	alert("Geometry/ies and frequencies loaded!");
setName();
setTitleEcho();
//	alert("I am here")
}

function onClickReloadSymm() {
setV('set errorCallback "errCallback";');
runJmolScriptAndWait("load ''; set echo top left; echo reloading... HOLD ON;refresh; set messageCallback 'myMessageCryCallback'; message CRYDONE; echo;");
if (!flagGauss) {
	setName();
} else {
	reLoadGaussFreq();
}
}

function myMessageCryCallback(a, m) {
m = "" + m
//	important to do this to change from Java string to JavaScript string
if (m.indexOf("CRYDONE") == 0) {
	// refresh();
	// refreshFreq();
	setV("echo");
	loadModels();
	setName();
	// alert("I am here")
	// setTitleEcho();
}
}

var freqData = new Array;
var geomData = new Array;
//This is called each time a new file is loaded
function loadModels() {

extractAuxiliaryJmol();

//	setName();
//	cleanandReloadfrom();
//	getUnitcell("1");
//	selectDesireModel("1");
//	alert(geomData);
//	counterModel = 0;
if (getbyID("sym") != null)
	cleanList("sym");
if (getbyID("geom") != null)
	cleanList("geom");
getUnitcell("1");
setV("echo");
//	last changed Thu Jul 3 2014
counterFreq = 0;

for (i = 0; i < Info.length; i++) {
	if (Info[i].name != null) {
		var line = Info[i].name;
		// alert(line)

		if (line.search(/Energy/i) != -1) { // Energy
			if (i > 0 && i < Info.length)
				var previous = substringEnergyToFloat(Info[i - 1].name);
			if (Info[i].name != null) {
				addOption(getbyID("geom"), i + " " + Info[i].name, i + 1);
				geomData[i] = Info[i].name;
				counterFreq++;
			}
		} else if (line.search(/cm/i) != -1) {
			// onLoadparam();
			// last changed Thu Jul 3 2014
			 addOption(getbyID("vib"), (i + counterFreq +1) + " " + Info[i].name, i + 1);
			if (line.search(/LO/) == -1)
				freqData[i - counterFreq] = Info[i].name;
		}

	}
	// enableFreqOpts();

	// symmetryModeAdd();
	setMaxMinPlot();
	// getSymInfo();
	setTitleEcho();
}
}

//var counterFreq = 0;
//last changed Thu Jul 3 2014
var counterFreq = 0;
function reloadFastModels() {
extractAuxiliaryJmol();

setName();
unLoadall();
if (flagCryVasp) {
	if (getbyID("sym") != null)
		cleanList("sym");
	if (getbyID("geom") != null)
		cleanList("geom");
	if (getbyID("vib") != null)
		cleanList("vib");
	getUnitcell("1");
	setV("echo");
	counterFreq = 0;
	setTitleEcho();

	for (i = 0; i < Info.length; i++) {
		if (Info[i].name != null) {
			var line = Info[i].name;

			if (line.search(/Energy/i) != -1) { // Energy
				if (i > 0 && i < Info.length)
					var previous = substringEnergyToFloat(Info[i - 1].name);
				if (Info[i].name != null) {
					addOption(getbyID("geom"), i + " " + Info[i].name, i + 1);
					geomData[i] = Info[i].name;
					counterFreq++;
				}
			} else if (line.search(/cm/i) != -1) {
				// onLoadparam();
				// last changed Thu Jul 3 2014
				 addOption(getbyID("vib"), (i - counterFreq) +1 + " "
				 + Info[i].name, i + 1);
				if (line.search(/LO/) == -1)
					freqData[i - counterFreq] = Info[i].name;
			}
		}
	}

	enableFreqOpts();
	symmetryModeAdd();
	setMaxMinPlot();
	//getSymInfo();
	setName();
}
}
function cleanandReloadfrom() {
unLoadall();
resetAll();
removeAll();
fillElementlist();

if (getbyID("sym") != null)
	cleanList("sym");
if (getbyID("geom") != null)
	cleanList("geom");
if (getbyID("vib") != null)
	cleanList("vib");
getUnitcell("1");
selectDesireModel("1");
setTitleEcho();
}

function countNullModel(arrayX) {
var valueNullelement = 0;
for ( var i = 0; i < arrayX.length; i++) {
	if (arrayX[i].name == null || arrayX[i].name == "")
		valueNullelement = valueNullelement + 1;
}
return valueNullelement;

}

function refresh() {
saveState();
setV('set errorCallback "errCallback";');
setV("set echo top left; echo loading plots... HOLD ON;refresh;");
setV("set loadStructCallback 'plotEnergies'; load; set loadStructCallback 'plotGradient';");
reloadState();
}

function enterTab() {
updateListElement();
//	updateListAtomApp();
}

function refreshFreq() {
saveState();
setV('set errorCallback "errCallback";');
setV('set echo top left; echo loading plot... HOLD ON;refresh;');
setV("set loadStructCallback 'plotFrequencies';");
}

/////////////////////////////////// END LOAD

/////////////////////////
/////////////////////////////// FREQUENCY

//This works out the symmetry classification on the frequency modes
function symmetryModeAdd() {

if (Info[3].modelProperties) {
	var symm = new Array();
	for ( var i = 1; i < Info.length; i++)
		if (Info[i].name != null)
			symm[i] = Info[i].modelProperties.vibrationalSymmetry;

	var sortedSymm = unique(symm);
}

for ( var i = 0; i < Info.length; i++) {
	if (Info[i].modelProperties) {
		if (sortedSymm[i] != null)
			addOption(getbyID("sym"), sortedSymm[i], sortedSymm[i])
	}
}
}

function loadAllFreq() {
removeAll();

var Info = extractAuxiliaryJmol("Frequencies")
//alert('length '+ Info.length)
for ( var i = 0; i < Info.length; i++)
	addOption(getbyID("vib"), i + " " + Info[i].name, i + 1);

}

function onClickVibrate(select) {
for ( var i = 0; i < document.modelsVib.vibration.length; i++) {
	if (document.modelsVib.vibration[i].checked)
		var radioval = document.modelsVib.vibration[i].value;
}

switch (radioval) {
case "on":
	runJmolScript("vibration on; vectors SCALE 15; vector 5; vibration SCALE 7;");
	break;
case "off":
	runJmolScript("vibration off;");
	break;
}
}

//This is to load either IR or Raman modes
function onClickModSelLoad(selectbox) {
var Info = extractAuxiliaryJmol("Frequencies")
for ( var i = 0; i < document.modelsVib.modAct.length; i++) {
	// if(Info[i].name != null){
	if (document.modelsVib.modAct[i].checked)
		var rad_val = document.modelsVib.modAct[i].value;
	// }
}

if (!Info[2].modelProperties.Frequency) {
	errorMsg("No vibrations available")
	return;
}

removeAll();
resetFreq();

switch (rad_val) {
case "all":
	for ( var i = 0; i < Info.length; i++) {
		if (Info[i].name != null)
			addOption(getbyID("vib"), i + " " + Info[i].name, i + 1);
	}
	cleanList("sym");
	symmetryModeAdd();
	break;

case "ir":
	for ( var i = 1; i < Info.length; i++) {
		if (Info[i].modelProperties.Frequency != null) {
			if (Info[i].modelProperties.IRactivity == "A") {
				addOption(getbyID("vib"), i + " " + Info[i].name, i + 1);
			}
		}
	}
	cleanList("sym");
	symmetryModeAdd();
	break;

case "raman":
	for ( var i = 1; i < Info.length; i++) {
		if (Info[i].modelProperties.Frequency != null) {
			if (Info[i].modelProperties.Ramanactivity == "A") {
				addOption(getbyID("vib"), i + " " + Info[i].name, i + 1);
			}
		}
	}
	cleanList("sym");
	symmetryModeAdd();
	break;
}
}

//This listens the action change the irep
function onChangeListDesSymm(irep) {
resetFreq();
removeAll()
var sym = Info;
if (!flagGauss) {
	for ( var i = 1; i < sym.length; i++) {
		if (Info[i].modelProperties.vibrationalSymmetry != null) {
			var value = sym[i].modelProperties.vibrationalSymmetry;
			if (irep == value)
				addOption(Jmol.outgetbyID("vib"), i + " " + sym[i].name, i + 1);
		}
	}
} else {
	changeIrepGauss(irep);
}
}

//This resets the frequency state
function resetFreq() {
	setV("vibration off; vectors on");
}
var maxR = 0;
function setMaxMinPlot() {
var localInfo = extractAuxiliaryJmol("Frequencies")
var loacalFreqCount = localInfo.length
var irFrequency = new Array();

try { 
	for ( var i = 0; i < loacalFreqCount; i++) { // populate IR array
		if (localInfo[i].modelProperties && localInfo[i].modelProperties.Frequency) {
			irFrequency[i] = roundoff(substringFreqToFloat(localInfo[i].modelProperties.Frequency), 0);
		}
	}
	//alert(irFrequency)
	maxR = maxValue(irFrequency);
} catch (err){
		maxR = 3700
}

var max = maxR + 300;
min = 0;
setVbyID("nMax", max)
setVbyID("nMin", min)
}

/////////////////////////////// END FREQUENCY

function toogleFormObject(status, elements) {

if (status == "on") {
	for ( var i = 0; i < elements.length; i++)
		makeEnable(elements[i]);
}
if (status == "off") {
	for ( var i = 0; i < elements.length; i++)
		makeDisable(elements[i]);
}

}
      		
///js// Js/dmol.js /////
/*  J-ICE library 

    based on:
 *
 * Copyright (C) 2010-2014 Pieremanuele Canepa http://j-ice.sourceforge.net/
 *
 * Contact: pierocanepa@sourceforge.net
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA
 *  02111-1307  USA.
 */

//3rd-Sept-2010 CANEPA

function onClickLoadDmolStruc() {
	setV('set errorCallback "errCallback";');
	setV("load ?;  set defaultDirectory; set messageCallback 'myLoadDmol'; message dmolDONE; set echo top left; echo loading... HOLD ON;refresh;");
}

function myLoadDmol(a, m) {
	m = "" + m;
	// important to do this to change from Java string to JavaScript string
	if (m.indexOf("dmolDONE") == 0) {
		// refresh();
		// refreshFreq();
		setV("echo");
		loadModelsDmol();
		setName();
		setTitleEcho();
	}
}

var counterFreq = 0;
function loadModelsDmol() {
	extractAuxiliaryJmol();
	cleanandReloadfrom();
	getUnitcell("1");
	selectDesireModel("1");
	var counterMD = 0;
	counterFreq = 0;
	for (i = 0; i < Info.length; i++) {
		if (Info[i].name != null) {
			var line = Info[i].name;
			// alert(line)
			if (line.search(/E =/i) != -1) {
				// alert("geometry")
				addOption(getbyID("geom"), i + " " + line, i + 1);
				geomData[i] = line;
				counterFreq++;
			} else if (line.search(/cm/i) != -1) {
				freqData[i - counterFreq] = line;
				counterMD++;
			}
		}
	}

	if (freqData != null) {
		for (i = 1; i < freqData.length; i++) {
			if (freqData[i] != null)
				var data = parseFloat(freqData[i].substring(0, freqData[i]
						.indexOf("c") - 1));
			addOption(getbyID("vib"), i + " A " + data + " cm^-1", i
					+ counterFreq + 1);
		}
	}
	// These are in the vaspfunctions.js
	disableFreqOpts();
	symmetryModeAdd();
	setMaxMinPlot();
	getSymInfo();
	setName();
}
      		
///js// Js/gaussian.js /////
/*  J-ICE library 

    based on:
 *
 *  Copyright (C) 2010-2014 Pieremanuele Canepa http://j-ice.sourceforge.net/
 *
 *  Contact: pierocanepa@sourceforge.net
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA
 *  02111-1307  USA.
 */

//12-Nov-2010 CANEPA
function loadGaussian() {
	setV('set errorCallback "errCallback";');
	setV("load ?;  set defaultDirectory; set messageCallback 'gaussianCallBack'; message GAUSSIAN; set echo top left; echo loading... HOLD ON;refresh;");
}

function gaussianCallBack(a, m) {
	m = "" + m;
	// important to do this to change from Java string to JavaScript string
	if (m.indexOf("GAUSSIAN") == 0) {
		setTitleEcho();
		readGaussian();
		warningMsg("This is a molecular reader. Therefore not all properties will be available.")
	}
}

var geomGauss = new Array;
var freqSymmGauss = new Array;
var freqIntensGauss = new Array;
var freqGauss = new Array;
var energyGauss = new Array;
var counterGauss = 0;
function readGaussian() {
	// Reset program and set filename if available
	// This also extract the auxiliary info
	intizializeJiceGauss();

	for (i = 0; i < Info.length; i++) {
		if (Info[i].name != null) {
			var line = Info[i].name;
			// alert(line)
			if (line.search(/E/i) != -1) {
				// alert("geometry")
				addOption(getbyID("geom"), i + " " + Info[i].name, i + 1);
				geomGauss[i] = Info[i].name;
				if (Info[i].modelProperties.Energy != null
						|| Info[i].modelProperties.Energy != "")
					energyGauss[i] = Info[i].modelProperties.Energy;
				//alert(energyGauss[i])
				counterGauss++;
			} else if (line.search(/cm/i) != -1) {
				// alert("vibration")
				addOption(getbyID("vib"), i + " " + Info[i].name + " ("
						+ Info[i].modelProperties.IRIntensity + ")", i);
				freqGauss[i - counterGauss] = Info[i].modelProperties.Frequency;
				freqSymmGauss[i - counterGauss] = Info[i].modelProperties.FrequencyLabel;
				freqIntensGauss[i - counterGauss] = Info[i].modelProperties.IRIntensity;
			}
		}
	}

	setMaxMinPlot();
	symmetryModeAddGauss();

}

function intizializeJiceGauss() {
	info = [];
	extractAuxiliaryJmol();
	var name = jmolGetPropertyAsJSON("filename");
	// cleanandReloadfrom();
	setTitleEcho();
	selectDesireModel("1");

	cleanArrayGauss();
	if (getbyID("sym") != null)
		cleanList("sym");
	if (getbyID("geom") != null)
		cleanList("geom");
	if (getbyID("vib") != null)
		cleanList("vib");
	disableFreqOpts();
}

function cleanArrayGauss() {
	geomGauss = [];
	freqSymmGauss = [];
	freqIntensGauss = [];
	counterGauss = 0;
}

function symmetryModeAddGauss() {
	sortedSymm = new Array;
	sortedSymm = [];
	sortedSymm = unique(freqSymmGauss);
	//alert(sortedSymm)
	for ( var i = 0; i < freqSymmGauss.length; i++) {
		if (sortedSymm[i] != null)
			addOption(getbyID("sym"), freqSymmGauss[i], freqSymmGauss[i])
	}
}

function changeIrepGauss(irep) {
	//alert(counterGauss)
	for ( var i = 0; i < freqGauss.length; i++) {
		var value = freqSymmGauss[i];
		if (irep == value)
			addOption(getbyID("vib"), i + " " + freqSymmGauss[i] + " "
					+ freqGauss[i] + " (" + freqIntensGauss[i] + ")", i
					+ counterGauss + 1);
	}
}

function reLoadGaussFreq() {
	if (getbyID("vib") != null)
		cleanList("vib");
	for ( var i = 0; i < freqGauss.length; i++)
		addOption(getbyID("vib"), i + " " + freqSymmGauss[i] + " "
				+ freqGauss[i] + " (" + freqIntensGauss[i] + ")", i
				+ counterGauss + 1);

}
      		
///js// Js/gromacs.js /////
/*  J-ICE library 

    based on:
 *
 *  Copyright (C) 2010-2014 Pieremanuele Canepa http://j-ice.sourceforge.net/
 *
 *  Contact: pierocanepa@sourceforge.net
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA
 *  02111-1307  USA.
 */

var coordinateGromacs = null;

function exportGromacs() {
	warningMsg("Make sure you had selected the model you would like to export.");
	settitleGroomacs();
	setUnitCell();
	// setVacuum();
	// if(!flagGromos)
	trasnfromcartTocartnm();

	setcoordinateGromacs();

	var finalInputGromacs = "var final = [titleg,coordinate];"
			+ 'final = final.replace("\n\n","");' + 'WRITE VAR final "?.gro" ';
	setV(finalInputGromacs);
	// if(!flagGromos)
	trasnscartfromnmToCart();
}

function settitleGroomacs() {
	var titleGromacs = prompt("Type here the job title:", "");
	(titleGromacs == "") ? (titleGromacs = 'Input prepared with J-ICE ')
			: (titleGromacs = 'Input prepared with J-ICE ' + titleGromacs);
	titleGromacs = 'titleg = \"' + titleGromacs + '\"; ';
	setV(titleGromacs);
}

function setcoordinateGromacs() {
	var numatomsGrom = " " + selectedFrame + ".length";
	var coordinateGrom = selectedFrame
			+ '.label("  %i%e %i %e %8.3[xyz] %8.4fy %8.4fz")';
	var cellbox = +roundNumber(aCell) * roundNumber(cosRadiant(alpha)) + ' '
			+ roundNumber(bCell) * roundNumber(cosRadiant(beta)) + ' '
			+ roundNumber(cCell) * roundNumber(cosRadiant(gamma));
	coordinateGromacs = 'var numatomGrom = ' + ' ' + numatomsGrom + ';'
			+ 'var coordGrom = ' + coordinateGrom + ';'
			+ 'var cellGrom = \" \n\t' + cellbox + '\"; '
			+ 'coordinate = [numatomGrom,coordGrom,cellGrom];';
	setV(coordinateGromacs);
}
      		
///js// Js/gulp.js /////
/*  J-ICE library 

    based on:
 *
 *  Copyright (C) 2010-2014 Pieremanuele Canepa http://j-ice.sourceforge.net/
 *
 *  Contact: pierocanepa@sourceforge.net
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA
 *  02111-1307  USA.
 */

///THIS ROUTINE IS TO EXPORT INPUT FOR GULP
var titleGulp = null;
var cellGulp = null;
var coordinateGulp = null;
var spacegroupGulp = null;
var restGulp = null;
var flagShelgulp = null;
var stringCellparamgulp;

function exportGULP() {
	warningMsg("Make sure you had selected the model you would like to export.");
	if (typeSystem != "crystal")
		setUnitCell();
	setTitlegulp();
	setSystem();
	setCellgulp();
	setCoordinategulp();
	if (typeSystem == "crystal")
		setSpacegroupgulp();

	setPotentialgulp();
	if (typeSystem == "crystal") {
		var finalInputGulp = "var final = [titlegulp,cellgulp,coordgulp,spacegulp,restgulp];"
				+ 'final = final.replace("\n\n","\n");'
				+ 'WRITE VAR final "?.gin" ';
	} else {
		var finalInputGulp = "var final = [titlegulp,cellgulp,coordgulp,restgulp];"
				+ 'final = final.replace("\n\n","\n");'
				+ 'WRITE VAR final "?.gin" ';
	}
	setV(finalInputGulp);

	// This is to terminate the space group research
	setV('set errorCallback "errCallback"');
	setV("load '' filter 'primitive'");
	loadStatejust();

}

function setTitlegulp() {
	titleGulpinput = prompt("Type here the job title:", "");
	(titleGulpinput == "") ? (titleGulpinput = 'Input prepared with J-ICE ')
			: (titleGulpinput = '#Input prepared with J-ICE \n'
					+ titleGulpinput);
	titleGulp = 'var optiongulp = \"opti conp propr #GULP options\";'
			+ 'var titleheader = \"title \"; ' + 'var title = \"'
			+ titleGulpinput + '\"; ' + 'var titleend = \"end \";'
			+ 'titlegulp = [optiongulp, titleheader, title, titleend];';
	setV(titleGulp);

}

var flagsymmetryGulp = false;
function setSystem() {
	switch (typeSystem) {
	case "crystal":
		setUnitCell();
		coordinateAddgulp = ""
		cellHeadergulp = "cell"
		var flagsymmetryGulp = confirm("Do you want to introduce symmetry ?");

		if (flagsymmetryGulp) {
			warningMsg("This procedure is not fully tested.");
			figureOutSpaceGroup();
		} else {
			stringCellparamgulp = roundNumber(aCell) + ' ' + roundNumber(bCell)
					+ ' ' + roundNumber(cCell) + ' ' + roundNumber(alpha) + ' '
					+ roundNumber(beta) + ' ' + roundNumber(gamma);
		}
		break;

	case "surface":
		cellHeadergulp = "scell"
		coordinateAddgulp = "s"
		stringCellparamgulp = roundNumber(aCell) + ", " + roundNumber(bCell)
				+ ", " + roundNumber(gamma);
		break;

	case "polymer":
		cellHeadergulp = "pcell"
		coordinateAddgulp = ""
		stringCellparamgulp = roundNumber(aCell);
		break;

	case "molecule":
		// To be terminated

		break;
	}

}
var cellHeadergulp
function setCellgulp() {

	cellGulp = 'var cellheader = \"' + cellHeadergulp + '\";'
			+ 'var cellparameter = \"' + stringCellparamgulp + '\";'
			+ 'cellgulp = [cellheader, cellparameter];';
	setV(cellGulp);
}

function setCoordinategulp() {

	var coordinateString;
	var coordinateShel
	setCoorgulp();
	flagShelgulp = confirm("Is the inter-atomic potential a core/shel one? \n Cancel stands for NO core/shel potential.");
	if (sortofCoordinateGulp && typeSystem == 'crystal') {
		coordinateString = selectedFrame + '.label("%e core %16.9[fxyz]")';
		coordinateShel = selectedFrame + '.label("%e shel %16.9[fxyz]")';
	} else {
		coordinateString = selectedFrame + '.label("%e core %16.9[xyz]")';
		coordinateShel = selectedFrame + '.label("%e shel %16.9[xyz]")';
	}
	if (flagShelgulp) {
		coordinateGulp = 'var coordtype = \"' + sortofCoordinateGulp + '\";'
				+ 'var coordcore = ' + coordinateString + ';'
				+ 'var coordshel = ' + coordinateShel + ';'
				+ 'coordgulp = [coordtype, coordcore, coordshel];';
	} else {
		coordinateGulp = 'var coordtype = \"' + sortofCoordinateGulp + '\";'
				+ 'var coordcore = ' + coordinateString + ';'
				+ 'coordgulp = [coordtype, coordcore];';
	}
	setV(coordinateGulp);
}

var sortofCoordinateGulp = null;
var coordinateAddgulp = null;
function setCoorgulp() {
	if (typeSystem == 'crystal') {
		var sortofCoordinate = confirm("Do you want the coordinates in Cartesian or fractional? \n OK for Cartesian, Cancel for fractional.")
		sortofCoordinateGulp = (sortofCoordinate == true) ? (coordinateAddgulp + "cartesian")
				: (coordinateAddgulp + "fractional");
	} else {
		messageMsg("Coordinate will be exported in Cartesian");
	}
}

// interNumber from crystalfunction
function setSpacegroupgulp() {
	if (!flagsymmetryGulp)
		interNumber = "P 1"
	spacegroupGulp = 'var spaceheader = \"spacegroup\";'
			+ 'var spacegroup = \"' + interNumber + '\";'// TBC
			+ 'spacegulp = [spaceheader, spacegroup];';
	setV(spacegroupGulp);
}

function setPotentialgulp() {
	if (flagShelgulp) {
		restGulp = 'var species= \"species \" \n\n;'
				+ 'var restpot = \"#here the user should enter the inter-atomic potential setting\";'
				+ 'var spring = \"spring \"  \n\n;'
				+ 'restgulp = [species, restpot, spring];';
	} else {
		restGulp = 'var species= \"species \" \n\n;'
				+ 'var restpot = \"#here the user should enter the inter-atomic potential setting\";'
				+ 'restgulp = [species, restpot];';
	}
	setV(restGulp);

}

// ////////////GULP READER

function onClickLoadGulpStruct() {
	setV("load ? ; set defaultDirectory; script scripts/name.spt; set messageCallback 'myLoadGulp'; message GULP; set echo top left; echo loading... HOLD ON; refresh; echo;");
	// alert("Geometry/ies and frequencies loaded! Quantum ");
	setName();

}

function myLoadGulp(a, m) {
	m = "" + m
	// important to do this to change from Java string to JavaScript string
	if (m.indexOf("GULP") == 0) {
		// refresh();
		// refreshFreq();
		setV("echo");
		loadModelsGulp();
		setName();
		// setTitleEcho();
	}
}

function loadModelsGulp() {

	var counterFreq = 0;
	extractAuxiliaryJmol();
	cleanandReloadfrom();
	getUnitcell("1");
	selectDesireModel("1");
	var counterMD = 0;
	counterFreq = 0;
	for (i = 0; i < Info.length; i++) {
		var line = Info[i].name;
		if (i == 0) {
			line = "Intial";
		}

		addOption(getbyID("geom"), i + " " + line, i + 1);
		geomData[i] = line;
		counterFreq++;

	}
	// disableFreqOpts();
	// symmetryModeAdd();
	// setMaxMinPlot();
	getSymInfo();
	setName();

}

function substringEnergyGulpToFloat(value) {
	if (value != null) {
		var grab = parseFloat(
				value.substring(value.indexOf('=') + 1, value.indexOf('e') - 1))
				.toPrecision(8); // E = 100000.0000 eV
		grab = grab * 96.48;
		// http://web.utk.edu/~rcompton/constants
		grab = Math.round(grab * 100000000) / 100000000;
	}
	return grab;
}
      		
///js// Js/moldenfreq.js /////
/*  J-ICE library 

    based on:
 *
 *  Copyright (C) 2010-2014 Pieremanuele Canepa http://j-ice.sourceforge.net/
 *
 *  Contact: pierocanepa@sourceforge.net
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA
 *  02111-1307  USA.
 */

function onClickLoadMoldenStruct() {
	setV('set errorCallback "errCallback";');
	setV("load ?;  set defaultDirectory; set messageCallback 'myLoadMolden'; message MOLDENDONE; set echo top left; echo loading... HOLD ON;refresh;");
}

function myLoadMolden(a, m) {
	m = "" + m;
	// important to do this to change from Java string to JavaScript string
	if (m.indexOf("MOLDENDONE") == 0) {
		// refresh();
		// refreshFreq();
		setV("echo");
		loadModelsMolden();
		setName();
		setTitleEcho();
	}
}

var counterFreq = 0;
function loadModelsMolden() {
	extractAuxiliaryJmol();
	cleanandReloadfrom();
	var counterMD = 0;
	counterFreq = 0;
	for (i = 0; i < Info.length; i++) {
		if (Info[i].name != null) {
			var line = Info[i].name;
			if (line.search(/cm/i) != -1) {
				freqData[i] = line;
				counterMD++;
			}
		}
	}

	if (freqData != null) {
		for (i = 1; i < freqData.length; i++) {
			var data = parseFloat(freqData[i].substring(0, freqData[i]
					.indexOf("c") - 1));
			addOption(getbyID("vib"), i + " A " + data + " cm^-1", i
					+ counterFreq + 1);
		}
	}
	disableFreqOpts();
	// symmetryModeAdd();
	setMaxMinPlot();
	getSymInfo();
	setName();
}
      		
///js// Js/IsoSurface.js /////
/*  J-ICE library 

    based on:
 *
 * Copyright (C) 2010-2014 Pieremanuele Canepa http://j-ice.sourceforge.net/
 *
 * Contact: pierocanepa@sourceforge.net
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA
 *  02111-1307  USA.
 */

//////////////////////ISOSURFACE FUNCTIONS(LOAD AND PERIODICITY)
function cubeLoad() {
	setV("isosurface delete all");
	var answer = confirm("Is your CUBE periodic?");
	if (answer) {
		var dued = confirm("Do you want to extract a 2D map out of this CUBE? \n Press Ok for 2D, Cancel for 3D");
		if (dued) {
			duedMaps();
		} else {
			var question = confirm("Is/are this/these CUBE file/s going to be superimposed on the current structure?");
			if (question) {
				setV('frame LAST; set errorCallback "errCallback";');
				var flag = true;
				potentialProfile(true);
			} else {
				messageMsg("Then, load your structure file first.");
				setV('set errorCallback "errCallback";');
				setV('load ?; frame LAST; set defaultDirectory; set echo top left; echo loading... HOLD ON ;refresh;');
				var flag = true;
				potentialProfile(true);
			}
		}
	} else {
		messageMsg("Just load the *.CUBE file");
		setV('set errorCallback "errCallback";');
		setV("load ?; set messageCallback 'saveIsoCallback'; message ISOSAVED;  set echo top left; echo loading... HOLD ON;refresh;");
	}

}

function potentialProfile(flag) {
	var potential = confirm("Do you want to overalap your potential / spin *.CUBE on it ?");
	if (potential) {
		if (flag) {
			messageMsg("Now load in sequence 1) the *.CUBE density file, 2) the *.CUBE potential / spin file.");
			setV('set errorCallback "errCallback";');
			setV('isosurface ?.CUBE  map ?.CUBE');
			setV("set messageCallback 'isoValue'; message ISO;set echo top left; echo loading CUBE... HOLD ON;refresh;");
		} else {
			messageMsg("Now load the *.CUBE potential file.");
			setV('set errorCallback "errCallback";');
			setV('isosurface "" map');
			setV("set messageCallback 'isoValue'; message ISO;set echo top left; echo loading CUBE... HOLD ON;refresh;");
		}
		setV("set messageCallback 'savePotCallback'; message POTSAVED; set echo top left; echo loading CUBE... HOLD ON;refresh;");
		setV("set messageCallback 'isoValue'; message ISO; set echo top left; echo loading CUBE... HOLD ON;refresh;"); // This
		// callback
		// is to work
		// out the color
		// range of the
		// surface
	} else {
		setV('isosurface ?.CUBE');
		setV("set messageCallback 'isoValue'; message ISO; set echo top left; echo loading... HOLD ON;refresh;");
		sendSurfaceMessage();
		saveIsoJVXL();
	}
}

var dueD_con = false;
var dueD_planeMiller = false;

function duedMaps() {

	var plane = confirm("In order to extract a 2D map from a 3D file you need to  select a plane. \n If you want to select a miller plane press Ok. \n Otherwise you create you own plane selecting three atom press Cancel.");

	if (plane) {
		var miller = prompt(
				"Enter the three Miller's indexes with the follow notation x x x. \n If you have fractional numbers enter for instance: 1/2 1/2 1/2.",
				"1 1 1");
		messageMsg("Miller's plane entered: " + miller);

		var spin = confirm("Now would you only like to slice the density? OK for yes, Cancel if you wish to map SPIN or potential on top.")
		if (spin) {
			dueD_con = true;
			dueD_planeMiller = true;
			setV('isosurface ID "isosurface1" select ({0:47})  hkl {' + miller
					+ '} map color range 0.0 2.0 ?.CUBE');
		} else {
			messageMsg("Now load the *.CUBE potential / spin file.");
			setV("isosurface HKL {" + miller + "} MAP ?.CUBE;");
		}
	} else {

		setPlanedued("");

	}

}

// function change

function sendSurfaceMessage() {
	warningMsg("If the surface doesn't look like what you were exceted, go to the menu' voice Isosur. for more options.");
}

function saveIsoJVXL() {
	messageMsg("Now, save your surface in a compact format *.JVXL");
	setV('set errorCallback "errCallback";');
	setV("write crystal_map.jvxl;");
	// setV('set defaultDirectory; isosurface crystal_map.jvxl')
}

function saveIsoCallback(a, m) {
	m = "" + m;
	// important to do this to change from Java string to JavaScript string
	if (m.indexOf("ISOSAVED") == 0) {
		var flag = false;
		setV("echo");
		potentialProfile(flag);
	}
}

function savePotCallback(a, m) {
	m = "" + m;
	// important to do this to change from Java string to JavaScript string
	if (m.indexOf("POTSAVED") == 0) {
		setV("echo");
		sendSurfaceMessage();
		saveIsoJVXL();
	}
}

function setIsoClassic(value) {
	setV("isosurface delete ALL");
	setV('set errorCallback "errCallback";');
	if (value == 'load ""; isosurface VDW 2.0') {
		var periodicSurf = confirm("Would you like to periodicize this surface ?");
		if (periodicSurf == true) {
			setV('set errorCallback "errCallback";');
			setV('load ""; frame LAST; isosurface slab unitcell VDW');
			setV("set messageCallback 'isoValue'; message ISO; set echo top left;echo creating ISOSURFACE... HOLD ON;");
			msSetPeriodicity();
		} else {
			setV(value
					+ "; set messageCallback 'isoValue'; message ISO; ; set echo top left;echo creating ISOSURFACE... HOLD ON;");
		}
	} else if (value == 'load ""; isosurface resolution 7 SOLVENT map MEP;') {
		var periodicSurf = confirm("Would you like to periodicize this surface ?");
		if (periodicSurf == true) {
			setV('load ""; frame LAST; isosurface slab unitcell resolution 7 SOLVENT map MEP;');
			setV("set messageCallback 'isoValue'; message ISO; set echo top left;echo creating ISOSURFACE... HOLD ON;");
			msSetPeriodicity();
		} else {
			setV(value
					+ "; set messageCallback 'isoValue'; message ISO; set echo top left; echo creating ISOSURFACE... HOLD ON; refresh;");
		}
	} else {
		setV(value
				+ "; set messageCallback 'isoValue'; message ISO; set echo top left; echo creating ISOSURFACE... HOLD ON; refresh;");
	}
}

function msSetPeriodicity() {
	messageMsg("Now set the periodicity with the menu below.");
}

function isoValue(a, m) {
	m = "" + m;
	// important to do this to change from Java string to JavaScript string
	if (m.indexOf("ISO") == 0) {
		setV("echo");
		getIsoInfo();
	}
}

// This extracts the maximum and minimum of the color range
function getIsoInfo() {
	var isoInfo = jmolGetPropertyAsString("shapeinfo.isosurface[1].jvxlinfo");
	// if (!isoInfo) {
	// alert ("No value available")
	// return;
	// }
	titleCRYS;
	var dataMinimum = parseFloat(isoInfo.substring(
			isoInfo.indexOf("data") + 14, isoInfo.indexOf("data") + 26)); // dataMinimum
	var dataMaximum = parseFloat(isoInfo.substring(
			isoInfo.indexOf("dataMax") + 14, isoInfo.indexOf("dataMax") + 26)); // dataMaximum

	setVbyID("dataMin", dataMinimum);
	setVbyID("dataMax", dataMaximum);

}

function setIsoColorscheme() {
	var colorScheme = getValue("isoColorScheme");
	setV('color $isosurface1 "' + colorScheme + '"');
}

function setIsoColorRange() {
	if (getbyID("dataMin") == "" || getbyID("dataMax") == "") {
		errorMsg("Please, check values entered in the textboxes");
		return false;
	}

	var min = getValue("dataMin");
	var max = getValue("dataMax");
	var colorScheme = getValue("isoColorScheme");

	if (colorScheme != "bw") {
		setV('color $isosurface1 "' + colorScheme + '" range ' + min + ' '
				+ max);
	} else {
		warningMsg("Colour-scheme not available for CUBE files!");
		// setV('color $isosurface1 "' + colorScheme + "'")
	}
}

function setColorMulliken(value) {
	setV('set propertyColorScheme "' + value + '"');
	// setV('set propertyColorScheme \"' + value + '\"');
	setV('load "" PACKED; select *;font label 18; frame last; color {*} property partialCharge; label %5.3P');
}

function setIsoColorReverse() {
	if (getbyID("dataMin") == "" || getbyID("dataMax") == "") {
		errorMsg("Please, check values entered in the textboxes");
		return false;
	}

	var min = getValue("dataMin");
	var max = getValue("dataMax");
	var colorScheme = getValue("isoColorScheme");

	setV('color $isosurface1 reversecolor "' + colorScheme + '" range ' + min
			+ ' ' + max);
}

function pickIsoValue() {
	var check = checkID("measureIso");
	if (check) {
		messageMsg("Value are shown by hovering on the surface. Values are in e- *bohr^-3. Make sure your isosurface is completely opaque.");
		setV("set drawHover TRUE");
	} else {
		setV("set drawHover OFF");
	}
}

function removeStructure() {
	var check = checkID("removeStr");
	if (!check) {
		setV("select *; hide selected");
	} else {
		setV("display *");
	}
}

function removeCellIso() {
	var check = checkID("removeCellI");
	if (!check) {
		setV("unitcell OFF");
	} else {
		setV("unitcell ON");
	}
}

function setIsoPack() {
	if (getValue("iso_a") == "" || getValue("iso_b") == ""
			|| getValue("iso_c") == "") {
		errorMsg("Please, check values entered in the textboxes");
		return false;
	}

	// var question = confirm("Do you want to replicate the structure too?");
	// if(question){
	// saveCurrentState();
	// setV("load '' {" + getValue("iso_a") + " " + getValue("iso_b") +
	// " " + getValue("iso_c") + " }; frame LAST");
	// }
	// reloadCurrentState();
	setV('isosurface LATTICE {' + getValue("iso_a") + ' ' + getValue("iso_b")
			+ ' ' + getValue("iso_c") + '}');
}

function loadMapJvxl() {
	var question = confirm("Do you want to superimpose this map on a structure?");

	if (question) {
		messageMsg("Then, load the input file first.");
		setV('zap; set errorCallback "errCallback"; load ?; set defaultDirectory;');
		setV("frame LAST");
		messageMsg("Now load the isosurface *.jvxl file.");
		setV('set errorCallback "errCallback"; isosurface ?.jvxl');
	} else {
		messageMsg("Then, load the isosurface *.jvxl file.");
		setV('zap; set errorCallback "errCallback"; zap; isosurface ?.jvxl');
	}
}

////////////////END ISOSURFACE FUNCTIONS
      		
///js// Js/quantumespresso.js /////
/*  J-ICE library 

    based on:
 *
 *  Copyright (C) 2010-2014 Pieremanuele Canepa http://j-ice.sourceforge.net/
 *
 *  Contact: pierocanepa@sourceforge.net
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA
 *  02111-1307  USA.
 */

/*&CONTROL
 title = 'alpha_PbO_PBE' ,
 calculation = 'vc-relax' ,
 restart_mode = 'from_scratch' ,
 outdir = '/home/pc229/backup/Counts/PWscf/alpha_PbO/' ,
 wfcdir = '/home/pc229/backup/Counts/PWscf/alpha_PbO/' ,
 pseudo_dir = '/home/pc229/backup/Counts/PWscf/alpha_PbO/pseudo/' ,
 prefix  =' alpha_PbO_PBE' ,
 /
 &SYSTEM
 ibrav = 6,
 celldm(1) = 7.511660805,
 celldm(3) = 1.263647799,
 nat = 4,
 ntyp = 2,
 ecutwfc = 50 ,
 nbnd = 60,
 nelec = 40,
 tot_charge = 0.000000,
 occupations = 'fixed' ,
 /
 &ELECTRONS
 mixing_beta = 0.3D0 ,
 /
 &IONS
 ion_dynamics = 'bfgs' ,
 /
 &CELL
 cell_dynamics = 'bfgs' ,
 /
 ATOMIC_SPECIES
 Pb  207.20000  Pb.pbe-d-van.UPF
 O   15.99400  O.pbe-van_ak.UPF
 ATOMIC_POSITIONS crystal
 Pb      0.000000000    0.500000000    0.238500000
 O      0.000000000    0.000000000    0.000000000
 Pb      0.500000000    0.000000000   -0.238500000
 O      0.500000000    0.500000000    0.000000000
 K_POINTS automatic
 4 4 4   0 0 0
 */

//Following functions are to export file for QuantumEspresso
var controlQ = null;
var systemQ = null;
var electronQ = null;
var ionsQ = null;
var cellQ = null;
var atomspQ = null;
var atompositionQ = null;
var kpointQ = null;

//Main block
function exportQuantum() {
	warningMsg("Make sure you had selected the model you would like to export.");
	prepareControlblock();
	prepareSystemblock();
	prepareElectronblock();
	prepareIonsblock();
	prepareCellblock();
	prepareSpecieblock();
	preparePostionblock();
	prepareKpoint();

	var finalInputQ = "var final = [control, system, electron, ions, cell, atomsp, posQ, kpo];"
		+ 'final = final.replace("\n\n"," ");' + 'WRITE VAR final "?.inp" ';
	setV(finalInputQ);
}

function prepareControlblock() {

	var stringTitle = prompt("Type here the job title:", "");
	(stringTitle == "") ? (stringTitleNew = 'Input prepared with J-ICE ')
			: (stringTitleNew = 'Input prepared with J-ICE ' + stringTitle);

	// stringa = 'title= \'prova\','
	controlQ = "var controlHeader = '\&CONTROL';"
		+ 'var controlTitle = "           title = \''
		+ stringTitleNew
		+ '\'";'
		+ 'var controlJob = "           calculation = \'  \'";'
		+ 'var controlRestart ="           restart = \'from_scratch\'";'
		+ 'var controlOutdir  ="           outdir = \' \'";'
		+ 'var controlWcfdir  ="           wcfdir = \' \'";'
		+ 'var controlPsddir  ="           pseudo_dir = \' \'";'
		+ 'var controlPrefix  ="           prefix = \''
		+ stringTitle
		+ '\'";'
		+ "var controlClose = '\/';"
		+ ' control = [controlHeader,controlTitle,controlJob,controlRestart,controlOutdir,controlWcfdir,controlPsddir,controlPrefix,controlClose];';
	setV(controlQ);
	// IMPORTANT THE LAST VARIABLE MUST NOT BE CALL SUCH AS var xxxx
}

function prepareSystemblock() {
	// /here goes the symmetry part

	setUnitCell();
	// celldim(1) = \' \'\,

	// this returns the number of atom

	atomCRYSTAL();
	var numberAtom = jmolEvaluate(numAtomCRYSTAL);
	var stringCutoff = null;
	var stringCutoffrho = null;
	var stringElec = null;
	var stringBand = null;

	/*
	 * var stringCutoff = prompt("Do you know how much is the cutoff on the wave
	 * function? If YES please enter it in eV.") var stringCutoffrho = null;
	 * 
	 * if(stringCutoff != ""){ stringCutoff = fromevTorydberg(stringCutoff);
	 * stringCutoffrho = stringCutoff * 4; }
	 * 
	 * var stringElec = prompt("How many electron does your system have?");
	 * if(stringElec != ""){ stringElec = parseInt(stringElec); stringBand =
	 * parseInt((stringElec / 2) + (stringElec / 2 * 0.20)); }
	 */
	symmetryQuantum();
	var eleMents = howManytype();
	var eleMentlength = eleMents.length

	systemQ = "var systemHeader = '\&SYSTEM';"
		+ 'var systemIbrav = "           ibrav = '
		+ ibravQ
		+ '";' // This variable is defined in the crystal function
		+ 'var systemCelld = "'
		+ cellDimString
		+ '";'
		// + 'var systemNat = " nat = \' \'\,";'
		+ 'var systemNat = "           nat = '
		+ numberAtom
		+ '";'
		+ 'var systemNty = "           ntyp = '
		+ eleMents.length
		+ '";'
		+ 'var systemCut = "           ecutwfc = 40";'
		+ 'var systemToc = "           tot_charge = 0.000000";'
		+ 'var systemOcc = "           occupation = \' \'";' // #this
		// must be
		// fixed if
		// the
		// structure
		// is an
		// insulator
		+ "var systemClose= '\/';"
		+ ' system = [systemHeader, systemIbrav, systemCelld, systemNat,systemNty,systemCut,systemToc,systemOcc , systemClose];';
	setV(systemQ);

}

//to be completed
function prepareElectronblock() {
	electronQ = "var electronHeader = '\&ELECTRONS';"
		+ 'var electronBeta = "           mixing_beta = \'  \'";'
		+ "var electronClose= '\/';"
		+ ' electron = [electronHeader, electronBeta, electronClose];';
	setV(electronQ);
}

//ask what algorithm to use window?
//set Tolerance as well!
function prepareIonsblock() {
	ionsQ = "var ionHeader = '\&IONS';"
		+ 'var ionDyn = "           ion_dynamics= \'  \'";'
		+ "var ionClose= '\/';" + 'ions = [ionHeader, ionDyn, ionClose];';
	setV(ionsQ);

}

function prepareCellblock() {
	cellQ = "var cellHeader = '\&CELL';"
		+ 'var cellDyn = "           cell_dynamics= \'  \'";'
		+ "var cellClose= '\/';"
		+ 'cell = [cellHeader, cellDyn, cellClose];'
		+ 'cell = cell.replace("\n\n"," ");';
	setV(cellQ);
}

function howManytype() {
	var ele = jmolGetPropertyAsArray("atomInfo");
	var newElement = new Array();

	for ( var i = 0; i < ele.length; i++)
		newElement[i] = ele[i].sym; // Return symbol

	var sortedElement = unique(newElement);
	// alert(sortedElement);
	return sortedElement
}
/*
 * ATOMIC_SPECIES Pb 207.20000 Pb.pbe-d-van.UPF O 15.99400 O.pbe-van_ak.UPF
 */

//To BE COMPLETED
function prepareSpecieblock() {
	var element = new Array();
	var newElement = new Array();
	var scriptEl = "";
	var stringList = "";

	setUnitCell();
	element = jmolGetPropertyAsArray("atomInfo");
	for ( var i = 0; i < element.length; i++)
		newElement[i] = element[i].sym; // Return symbol

	var sortedElement = unique(newElement);
	// alert(sortedElement);

	for ( var i = 0; i < sortedElement.length; i++) {
		var elemento = sortedElement[i];
		elemento = elemento.replace("\n\n", " ");
		var numeroAtom = jmolEvaluate('{' + frameNum + ' and _' + elemento
				+ '}[0].label("%l")'); //tobe changed in atomic mass
		scriptEl = "'" + elemento + " " + eleSymbMass[parseInt(numeroAtom)]
		+ " #Here goes the psudopotential filename e.g.: " + elemento
		+ ".pbe-van_ak.UPF '";
		scriptEl = scriptEl.replace("\n", " ");
		if (i == 0) {
			stringList = scriptEl;
		} else {
			stringList = stringList + "," + scriptEl;
		}

		stringList = stringList.replace("\n", " ")

	}

	atomspQ = "var atomsHeader = 'ATOMIC_SPECIES';" + 'var atomsList = ['
	+ stringList + '];' + 'atomsList = atomsList.replace("\n", " ");'
	// + 'atomList = atomList.join(" ");'
	+ 'atomsp =  [atomsHeader,atomsList];';
	setV(atomspQ);
}

function preparePostionblock() {

	setUnitCell();
	atompositionQ = "var posHeader = 'ATOMIC_POSITIONS crystal';"
		+ 'var posCoord = ' + selectedFrame + '.label(\"%e %14.9[fxyz]\");' // '.label(\"%e
		// %16.9[fxyz]\");'
		+ 'posQ = [posHeader,posCoord];';
	setV(atompositionQ);

}

function prepareKpoint() {
	kpointQ = "var kpointWh = '\n\n'  ;"
		+ "var kpointHeader = 'K_POINTS automatic';"
		+ "var kpointgr = ' X X X 0 0 0';"
		+ 'kpo = [kpointWh, kpointHeader, kpointgr];';
	setV(kpointQ);
}

function symmetryQuantum() {
	setUnitCell();
	switch (typeSystem) {
	case "crystal":
		var flagsymmetry = confirm("Do you want to introduce symmetry ?")
		if (!flagsymmetry) {
			cellDimString = "           celldm(1) = "
				+ roundNumber(fromAngstromtoBohr(aCell))
				+ "  \n           celldm(2) =  "
				+ roundNumber(bCell / aCell)
				+ "  \n           celldm(3) =  "
				+ roundNumber(cCell / aCell)
				+ "  \n           celldm(4) =  "
				+ roundNumber(cosRadiant(alpha))
				+ "  \n           celldm(5) =  "
				+ roundNumber(cosRadiant(beta))
				+ "  \n           celldm(6) =  "
				+ roundNumber(cosRadiant(gamma));
			ibravQ = "14";
		} else {
			warningMsg("This procedure is not fully tested.");
			// magnetic = confirm("Does this structure have magnetic properties?
			// \n Cancel for NO.")
			flagCryVasp = false;
			quantumEspresso = true;
			figureOutSpaceGroup();
		}
		break;
	case "slab":
		setVacuum();
		setV(selectedFrame + '.z = for(i;' + selectedFrame + '; i.z/' + cCell
				+ ')');
		cellDimString = "            celldm(1) = "
			+ roundNumber(fromAngstromtoBohr(aCell))
			+ "  \n            celldm(2) =  " + roundNumber(bCell / aCell)
			+ "  \n            celldm(3) =  " + roundNumber(cCell / aCell)
			+ "  \n            celldm(4) =  "
			+ roundNumber(cosRadiant(alpha))
			+ "  \n            celldm(5) =  " + roundNumber(cosRadiant(90))
			+ "  \n            celldm(6) =  " + roundNumber(cosRadiant(90));
		ibravQ = "14";
		break;
	case "polymer":
		setVacuum();
		setV(selectedFrame + '.z = for(i;' + selectedFrame + '; i.z/' + cCell
				+ ')');
		setV(selectedFrame + '.y = for(i;' + selectedFrame + '; i.y/' + bCell
				+ ')');
		cellDimString = "            celldm(1) = "
			+ roundNumber(fromAngstromtoBohr(aCell))
			+ "  \n            celldm(2) =  " + roundNumber(bCell / aCell)
			+ "  \n            celldm(3) =  " + roundNumber(bCell / aCell)
			+ "  \n            celldm(4) =  " + roundNumber(cosRadiant(90))
			+ "  \n            celldm(5) =  " + roundNumber(cosRadiant(90))
			+ "  \n            celldm(6) =  " + roundNumber(cosRadiant(90));
		ibravQ = "14";
		break;
	case "molecule":
		setVacuum();
		setV(selectedFrame + '.z = for(i;' + selectedFrame + '; i.z/' + cCell
				+ ')');
		setV(selectedFrame + '.y = for(i;' + selectedFrame + '; i.y/' + bCell
				+ ')');
		setV(selectedFrame + '.x = for(i;' + selectedFrame + '; i.x/' + aCell
				+ ')');
		cellDimString = "            celldm(1) = "
			+ roundNumber(fromAngstromtoBohr(aCell))
			+ "  \n            celldm(2) =  " + roundNumber(1.00000)
			+ "  \n            celldm(3) =  " + roundNumber(1.00000)
			+ "  \n            celldm(4) =  "
			+ roundNumber(cosRadiant(alpha))
			+ "  \n            celldm(5) =  " + roundNumber(cosRadiant(90))
			+ "  \n            celldm(6) =  " + roundNumber(cosRadiant(90));
		ibravQ = "14";
		break;
	}
}

///// QUANTUM ESPRESSO READER

function onClickQuantum() {
	setV("load ? PACKED; set defaultDirectory; set messageCallback 'myEspresso'; message ESPR; set echo top left; echo loading... HOLD ON; refresh; echo;");
	// alert("Geometry/ies and frequencies loaded! Quantum ");
	setName();
}

function myEspresso(a, m) {
	m = "" + m
	// important to do this to change from Java string to JavaScript string
	if (m.indexOf("ESPR") == 0) {
		setV("echo");
		loadQEspresso();
		setName();
		setTitleEcho();
	}
}

function loadQEspresso() {

	var counterFreq = 0;
	extractAuxiliaryJmol();
	cleanandReloadfrom();
	getUnitcell("1");
	selectDesireModel("1");
	var counterMD = 0;

	flagQuantum = true;
	flagOutcar = false;

	for (i = 0; i < Info.length; i++) {
		var line = Info[i].name;

		if (i == 0) {
			line = "Initial";
			addOption(getbyID("geom"), i + " " + line, i + 1);
			geomData[0] = Info[0].name;
		}

		// alert(line)
		if (line != null) {

			// alert(line)
			if (line.search(/E =/i) != -1) {
				// alert("geometry")
				addOption(getbyID("geom"), i + 1 + " " + line, i + 1);
				geomData[i + 1] = Info[i].name;

				counterFreq++;
			} /*
			 * else if (line.search(/cm/i) != -1) { // alert("vibration")
			 * freqData[i - counterFreq] = Info[i].name; counterMD++; } else
			 * if (line.search(/Temp/i) != -1) { addOption(getbyID("geom"),
			 * (i - counterMD) + " " + Info[i].name, i + 1); }
			 */
		}
	}
	/*
	 * if (freqData != null) { for (i = 1; i < freqData.length; i++) { if
	 * (freqData[i] != null) var data =
	 * parseFloat(freqData[i].substring(0,freqData[i].indexOf("c") - 1));
	 * addOption(getbyID("vib"), i + " A " + data + " cm^-1", i + counterFreq +
	 * 1 ); } }
	 */
	// disableFreqOpts();
	// symmetryModeAdd();
	// setMaxMinPlot();
	getSymInfo();
	// setName();

}

function substringEnergyQuantumToFloat(value) {
	if (value != null) {
		var grab = parseFloat(
				value.substring(value.indexOf('=') + 1, value.indexOf('R') - 1))
				.toPrecision(8); // E = 100000.0000 Ry
		grab = grab * 96.485 * 0.5; // constant from
		// http://web.utk.edu/~rcompton/constants
		grab = Math.round(grab * 100000000) / 100000000;
	}
	return grab;
}
      		
///js// Js/vaspfunction.js /////
/*  J-ICE library 

    based on:
 *
 *  Copyright (C) 2010-2014 Pieremanuele Canepa http://j-ice.sourceforge.net/
 *
 *  Contact: pierocanepa@sourceforge.net
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA
 *  02111-1307  USA.
 */

function onClickLoadVaspStruct() {
	setV('set errorCallback "errCallback";');
	setV("load ?.xml;  set defaultDirectory; set messageCallback 'myVaspXml'; message vaspDONE; set echo top left; echo loading... HOLD ON;refresh;");
}

function myVaspXml(a, m) {
	m = "" + m;
	// important to do this to change from Java string to JavaScript string
	if (m.indexOf("vaspDONE") == 0) {
		loadVASPModels();
		setTitleEcho();
		setName();
		warningMsg("This reader is limited in its own functionalities\n  It does not recognize between \n geometry optimization and frequency calculations.")
	}
}

function loadVASPModels() {
	// alert("vasp")
	extractAuxiliaryJmol();
	getUnitcell("1");
	var name = jmolGetPropertyAsJSON("filename");
	cleanandReloadfrom();
	setTitleEcho();

	for ( var i = 0; i < Info.length; i++) {
		if (Info[i].name != null) {
			var valueEnth = Info[i].name.substring(11, 24);
			var gibbs = Info[i].name.substring(41, 54);
			var stringa = "Enth. = " + valueEnth + " eV, Gibbs E.= " + gibbs
			+ " eV";
			
			addOption(getbyID("geom"), i + " " + stringa, i + 1);
		}
	}

}

function substringEnergyVaspToFloat(value) {
	if (value != null) {
		var grab = parseFloat(
				value.substring(value.indexOf('=') + 1, value.indexOf('e') - 1))
				.toPrecision(8); // Enthaply = -26.45132096 eV
		grab = grab * 96.485; // constant from
		// http://web.utk.edu/~rcompton/constants
		grab = Math.round(grab * 100000000) / 100000000;
	}
	return grab;
}

////EXPORT FUNCTIONS
var fractionalCoord = false;
function exportVASP() {
	var element = new Array();
	var newElement = new Array();
	var scriptEl = "";
	var stringTitle = "";
	var stringList = "";
	var stringElement = "";
	element = null;
	element = jmolGetPropertyAsArray("atomInfo");

	numAtomelement = null;
	getUnitcell(frameValue);

	setUnitCell();

	for ( var i = 0; i < element.length; i++)
		newElement[i] = element[i].sym; // Return symbol

	var sortedElement = unique(newElement);
	// alert(sortedElement)
	for ( var i = 0; i < sortedElement.length; i++) {
		// scriptEl = "";
		scriptEl = "{" + frameNum + " and _" + sortedElement[i] + "}.length";

		if (i != (sortedElement.length - 1)) {
			stringList = stringList + " " + scriptEl + ", ";
			stringTitle = stringTitle + " " + scriptEl + ", ";
			stringElement = stringElement + " " + sortedElement[i] + ", ";
		} else {
			stringList = stringList + " " + scriptEl;
			stringTitle = stringTitle + " " + scriptEl;
			stringElement = stringElement + " " + sortedElement[i];
		}
	}

	// alert(stringTitle)
	// alert(stringElement)

	fromfractionaltoCartesian();

	warningMsg("Make sure you had selected the model you would like to export.");
	vaspFile = prompt("Type here the job title:", "");
	(vaspFile == "") ? (vaspFile = 'POSCAR prepared with J-ICE whose atoms are: ')
			: (vaspFile = 'POSCAR prepared with J-ICE ' + vaspFile
					+ ' whose atoms are:');
	saveStatejust();
	// This if the file come from crystal output

	var kindCoord = null;
	var fractString = null;
	var exportType = confirm("Would you like to export the structure in fractional coordinates? \n If you press Cancel those will be exported as normal Cartesian.");

	if (exportType) {
		kindCoord = "Direct"
			fractString = "[fxyz]";
		fractionalCoord = true;
	} else {
		kindCoord = "Cartesian"
			fractString = "[xyz]";
		fractionalCoord = false;
	}

	setVacuum();

	var stringVasp = "var titleVasp = ["
		+ stringTitle
		+ "];"
		+ 'var title  = titleVasp.join("  ");'
		+ "var head  ='"
		+ vaspFile
		+ "';"
		+ "var atomLab ='"
		+ stringElement
		+ "';"
		+ 'var titleArr =[head, title, atomLab];'
		+ 'var titleLin = titleArr.join(" ");'
		+ 'var scaleFact = 1.000000;' // imp
		+ "var vaspCellOne = ["
		+ xx
		+ ", "
		+ xy
		+ ", "
		+ xz
		+ "];"
		+ "var vaspCellTwo = ["
		+ yx
		+ ", "
		+ yy
		+ ", "
		+ yz
		+ "];"
		+ "var vaspCellThree = ["
		+ zx
		+ ", "
		+ zy
		+ ", "
		+ zz
		+ "];"
		+ 'var vaspCellX = vaspCellOne.join(" ");' // imp
		+ 'var vaspCellY = vaspCellTwo.join(" ");' // imp
		+ 'var vaspCellZ = vaspCellThree.join(" ");' // imp
		+ 'var listEle  = [atomLab.replace(",","")];'
		+ 'var listLabel  = listEle.join("  ");'
		+ "var listInpcar = ["
		+ stringList
		+ "];"// imp
		+ 'var listAtom  = listInpcar.join("  ");'
		+ 'var cartString = "'
		+ kindCoord
		+ '";' // imp
		+ 'var xyzCoord = '
		+ selectedFrame
		+ '.label(" %16.9'
		+ fractString
		+ '");' // imp
		+ 'var lista = [titleLin, scaleFact, vaspCellX, vaspCellY, vaspCellZ, listLabel, listAtom, cartString, xyzCoord];' // misses
		// listInpcar
		+ 'WRITE VAR lista "POSCAR" ';
	setV(stringVasp);
	loadStatejust();
}

/////// END EXPORT VASP

/////////// IMPORT OUTCAR

function onClickLoadOutcar() {
	setV("load ?; set defaultDirectory; set messageCallback 'myLoadOutcar'; message CARDONE; set echo top left; echo loading... HOLD ON; refresh; echo;");
	// alert("Geometry/ies and frequencies loaded!");
}

function myLoadOutcar(a, m) {
	m = "" + m;
	// important to do this to change from Java string to JavaScript string
	if (m.indexOf("CARDONE") == 0) {
		// refresh();
		// refreshFreq();
		setV("echo");
		loadModelsOutcar();
		setName();
		setTitleEcho();
	}
}

var counterFreq = 0;
function loadModelsOutcar() {
	extractAuxiliaryJmol();
	cleanandReloadfrom();
	getUnitcell("1");
	selectDesireModel("1");
	var counterMD = 0;
	// counterFreq = 0;
	// Last changed Fri Jul 4 11:15:04 AST 2014
	counterFreq = 1;
	for (i = 0; i < Info.length; i++) {
		if (Info[i].name != null) {
			var line = Info[i].name;
			// alert(line)
			if (line.search(/G =/i) != -1) {
				// alert("geometry")
				addOption(getbyID("geom"), i + " " + line, i + 1);
				geomData[i] = line;
				counterFreq++;
			} else if (line.search(/cm/i) != -1) {
				freqData[i - counterFreq] = line;
				counterMD++;
			} else if (line.search(/Temp/i) != -1) {
				addOption(getbyID("geom"), (i - counterMD) + " " + line, i + 1);
			}
		}
	}

	if (freqData != null) {
		for (i = 1; i < freqData.length; i++) {
			if (freqData[i] != null)
				var data = parseFloat(freqData[i].substring(0, freqData[i]
				.indexOf("c") - 1));
			// Last changed Fri Jul 4 11:15:04 AST 2014
			 addOption(getbyID("vib"), i + counterFreq  + " A " + data + " cm^-1", i +
			 counterFreq + 1 );
		}
	}
	disableFreqOpts();
	//symmetryModeAdd();
	setMaxMinPlot();
	getSymInfo();
	setName();
}

/////////LOAD FUNCTIONS

function disableFreqOpts() {
	for ( var i = 0; i < document.modelsVib.modAct.length; i++)
		document.modelsVib.modAct[i].disabled = true;
	for ( var i = 0; i < document.modelsVib.kindspectra.length; i++)
		document.modelsVib.kindspectra[i].disabled = true;

	// getbyID("modAct").enable = false;
	// makeDisable("modAct");
	// makeDisable("vibSym");
	// makeDisable("reload");
}

function enableFreqOpts() {
	for ( var i = 0; i < document.modelsVib.modAct.length; i++)
		document.modelsVib.modAct[i].disabled = false;
	for ( var i = 0; i < document.modelsVib.kindspectra.length; i++)
		document.modelsVib.kindspectra[i].disabled = false;

}

/////END FUNCTIONS
      		
///js// Js/convertion.js /////
/*  J-ICE library 

    based on:
 *
 * Copyright (C) 2010-2014 Pieremanuele Canepa http://j-ice.sourceforge.net/
 *
 * Contact: pierocanepa@sourceforge.net
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA
 *  02111-1307  USA.
 */

//////////////////////////////////////VALUE CONVERTION AND ROUNDOFF
function substringEnergyToFloat(value) {
	if (value != null) {
		var grab = parseFloat(
				value.substring(value.indexOf('=') + 1, value.indexOf('H') - 1))
				.toPrecision(12); // Energy = -5499.5123027313 Hartree
		grab = grab * 2625.50;
		grab = Math.round(grab * 1000000000000) / 1000000000000;
	}
	return grab;
}

function substringFreqToFloat(value) {
	if (value != null) {
		var grab = parseFloat(value.substring(0, value.indexOf('c') - 1));
		// BH 2018 looking out for "F 300.2" in frequencies
		if (isNaN(grab))
			grab= parseFloat(value.substring(1, value.indexOf('c') - 1));
		if (isNaN(grab))
			return NaN;
		else
		grab = Math.round(grab.toPrecision(8) * 100000000) / 100000000;
	}
	return grab;
}

function substringIntGaussToFloat(value) {
	if (value != null) {
		var grab = parseFloat(value.substring(0, value.indexOf('K') - 1))
		.toPrecision(8);
		grab = Math.round(grab * 100000000) / 100000000;
	}
	return grab;
}

function substringIntFreqToFloat(value) {
	if (value != null) {
		var grab = parseFloat(value.substring(0, value.indexOf('k') - 1))
		.toPrecision(5);
		grab = Math.round(grab * 10000) / 10000;
	}
	return grab;
}

/////////////////////////////// LATTICE PARAMETERS AND COORDIANTE CONVERTION
//From fractional to Cartesian
var xx, xy, xz, yx, yy, yz, zx, zy, zz;
function fromfractionaltoCartesian(aparam, bparam, cparam, alphaparam,
		betaparam, gammaparam) {
	if (aparam != null)
		aCell = aparam;
	if (bparam != null)
		bCell = bparam;
	if (cparam != null)
		cCell = cparam;
	if (alphaparam != null)
		alpha = alphaparam;
	if (betaparam != null)
		beta = betaparam;
	if (gammaparam != null)
		gamma = gammaparam;
	var radiant = Math.PI / 180;
	// formula repeated from
	// http://en.wikipedia.org/wiki/Fractional_coordinates
	v = Math.sqrt(1
			- (Math.cos(alpha * radiant) * Math.cos(alpha * radiant))
			- (Math.cos(beta * radiant) * Math.cos(beta * radiant))
			- (Math.cos(gamma * radiant) * Math.cos(gamma * radiant))
			+ 2
			* (Math.cos(alpha * radiant) * Math.cos(beta * radiant) * Math
					.cos(gamma * radiant)));
	xx = aCell * Math.sin(beta * radiant);
	xy = parseFloat(0.000);
	xz = aCell * Math.cos(beta * radiant);
	yx = bCell
	* (((Math.cos(gamma * radiant)) - ((Math.cos(beta * radiant)) * (Math
			.cos(alpha * radiant)))) / Math.sin(beta * radiant));
	yy = bCell * (v / Math.sin(beta * radiant));
	yz = bCell * Math.cos(alpha * radiant);
	zx = parseFloat(0.000);
	zy = parseFloat(0.000);
	zz = cCell;
}

function cosRadiant(value) {
	var radiant = Math.PI / 180;
	if (value != null) {
		var angle = parseFloat(value).toPrecision(7);
		angle = Math.cos(value * radiant);
		angle = Math.round(angle * 10000000) / 10000000;
	}
	return angle;
}

function roundNumber(value) {
	var newval = Math.round(value * 10000000) / 10000000;
	return newval;
}

function roundoff(value, precision) {
	value = "" + value
	precision = parseInt(precision)

	var whole = "" + Math.round(value * Math.pow(10, precision))
	var decPoint = whole.length - precision;

	if (decPoint != 0) {
		result = whole.substring(0, decPoint);
		result += "."
			result += whole.substring(decPoint, whole.length);
	} else {
		result = whole;
	}

	return result;
}

function setVacuum() {
	// This if the file come from crystal output

	switch (typeSystem) {
	case "slab":
		vaccum = prompt("Please enter the vacuum thickness (\305).", "");
		(vaccum == "") ? (errorMsg("Vacuum not entered!"))
				: (messageMsg("Vacuum set to: " + vaccum + " \305."));

		var zMaxCoord = parseFloat(jmolEvaluate(selectedFrame + '.fz.max'));
		vaccum = parseFloat(vaccum);
		newcCell = (zMaxCoord * 2) + vaccum;
		var factor = roundNumber(zMaxCoord + vaccum);
		if (fractionalCoord == true) {
			setV(selectedFrame + '.z = for(i;' + selectedFrame + '; ( i.z +'
					+ factor + ') /' + newcell + ')');
			alert("here i'm")
		} else {
			setV(selectedFrame + '.z = for(i;' + selectedFrame + '; i.z +'
					+ factor + ')');
		}
		fromfractionaltoCartesian(null, null, newcCell, null, 90, 90);
		break;
	case "polymer":
		vaccum = prompt("Please enter the vacuum thickness (\305).", "");
		(vaccum == "") ? (errorMsg("Vacuum not entered!"))
				: (messageMsg("Vacuum set to: " + vaccum + "  \305."));

		var zMaxCoord = parseFloat(jmolEvaluate(selectedFrame + '.fz.max'));
		vaccum = parseFloat(vaccum);
		newcCell = (zMaxCoord * 2) + vaccum;
		var factor = roundNumber(zMaxCoord + vaccum);
		setV(selectedFrame + '.z = for(i;' + selectedFrame + '; i.z +' + factor
				+ ')');
		setV(selectedFrame + '.y = for(i;' + selectedFrame + '; i.y +' + factor
				+ ')');
		fromfractionaltoCartesian(null, newcCell, newcCell, 90, 90, 90);
		break;
	case "molecule":
		vaccum = prompt("Please enter the vacuum thickness (\305).", "");
		(vaccum == "") ? (errorMsg("Vacuum not entered!"))
				: (messageMsg("Vacuum set to: " + vaccum + " \305."));

		var zMaxCoord = parseFloat(jmolEvaluate(selectedFrame + '.fz.max'));
		vaccum = parseFloat(vaccum);
		newcCell = (zMaxCoord * 2) + vaccum;
		var factor = roundNumber(zMaxCoord + vaccum);
		setV(selectedFrame + '.z = for(i;' + selectedFrame + '; i.z +' + factor
				+ ')');
		setV(selectedFrame + '.y = for(i;' + selectedFrame + '; i.y +' + factor
				+ ')');
		setV(selectedFrame + '.x = for(i;' + selectedFrame + '; i.x +' + factor
				+ ')');
		fromfractionaltoCartesian(newcCell, newcCell, newcCell, 90, 90, 90);
		break;

	}

}

function trasnfromcartTocartnm() {
	setV(selectedFrame + '.z = for(i;' + selectedFrame + '; i.z/10)');
	setV(selectedFrame + '.y = for(i;' + selectedFrame + '; i.y/10)');
	setV(selectedFrame + '.x = for(i;' + selectedFrame + '; i.x/10)');
}

function trasnscartfromnmToCart() {
	setV(selectedFrame + '.z = for(i;' + selectedFrame + '; i.z*10)');
	setV(selectedFrame + '.y = for(i;' + selectedFrame + '; i.y*10)');
	setV(selectedFrame + '.x = for(i;' + selectedFrame + '; i.x*10)');

}

/////////////////////////////////END LATTICE PARAMETERS AND COORDIANTE
//CONVERTION

////////////////////////////////ENERGY CONV
var finalGeomUnit = ""
	function convertPlot(value) {
	var unitEnergy = value;

	// ////var vecUnitEnergyVal = new Array ("h", "e", "r", "kj", "kc");
	setConvertionParam();
	switch (unitEnergy) {

	case "h": // Hartree
		finalGeomUnit = " Hartree";
		if (flagQuantum) {
			convertGeomData(fromRydbergtohartree);
		} else if (!flagCryVasp || flagOutcar || flagGulp) {
			convertGeomData(fromevToHartree);
		} else if (flagCryVasp || flagDmol) {
			convertGeomData(fromHartreetoHartree);
		}
		break;
	case "e": // eV
		finalGeomUnit = " eV";
		if (flagCryVasp || flagDmol) {
			convertGeomData(fromHartreetoEv);
		} else if (flagQuantum) {
			convertGeomData(fromRydbergtoEv);
		} else if (!flagCryVasp || flagOutcar || flagGulp) {
			convertGeomData(fromevtoev);
		}

		break;

	case "r": // Rydberg
		finalGeomUnit = " Ry";
		if (flagCryVasp || flagDmol) {
			convertGeomData(fromHartreetoRydberg);
		} else if (!flagCryVasp || flagOutcar || flagGulp) {
			convertGeomData(fromevTorydberg);
		} else if (flagQuantum) {
			convertGeomData(fromRydbergTorydberg);
		}
		break;

	case "kj": // Kj/mol
		finalGeomUnit = " kJ/mol"

			if (flagCryVasp || flagDmol) {
				convertGeomData(fromHartreetokJ);
			} else if (!flagCryVasp || flagOutcar || flagGulp) {
				convertGeomData(fromevTokJ);
			} else if (flagQuantum) {
				convertGeomData(fromRydbergToKj);
			}
		break;

	case "kc": // Kcal*mol
		finalGeomUnit = " kcal/mol"
			
			if (flagCryVasp || flagDmol) {
				convertGeomData(fromHartreetokcalmol);
			} else if (!flagCryVasp || flagOutcar || flagGulp) {
				convertGeomData(fromevtokcalmol);
			} else if (flagQuantum) {
				convertGeomData(fromRytokcalmol);
			}
		break;
	}
}

/*
 * var flagCryVasp = true; // if flagCryVasp = true crystal output var
 * flagGromos = false; var flagGulp = false; var flagOutcar = false; var
 * flagGauss= false; var flagQuantum = false; var flagCif = false;
 */

var unitGeomEnergy = "";
function setConvertionParam() {
	if (flagCryVasp || flagDmol) {
		unitGeomEnergy = "H"; // Hartree
	} else if ((!flagCryVasp && !flagQuantum) || (flagOutcar && !flagQuantum)) {
		unitGeomEnergy = "e"; // VASP
	} else if (flagGulp) {
		unitGeomEnergy = "k";
	} else if (flagQuantum || !flagOutcar) {
		unitGeomEnergy = "R";
	}

}

function convertGeomData(functionName) {
	// The required value is the end of the string Energy = -123.456 Hartree.
	// Hartree
	if (getbyID("geom") != null)
		cleanList("geom");

	var arraynewUnit = new Array();

	var n = 0;
	if (flagQuantum)
		n = 1;
	for ( var i = n; i < geomData.length; i++) {

		arraynewUnit[i] = functionName(geomData[i].substring(geomData[i]
		.indexOf('=') + 1, geomData[i].indexOf(unitGeomEnergy) - 1));
		// /alert(arraynewUnit[i])
		addOption(getbyID("geom"), i + " E = " + arraynewUnit[i]
		+ finalGeomUnit, i + 1);

	}

}

///Hartree
function fromHartreetoEv(value) { // 1 Hartree = 27.211396132eV
	if (value != null) {
		var grab = parseFloat(value).toPrecision(12);
		grab = grab * 27.211396132;
		grab = Math.round(grab * 1000000000000) / 1000000000000;
	}
	return grab;
}

function fromHartreetoHartree(value) {
	if (value != null) {
		var grab = parseFloat(value).toPrecision(12);
		grab = Math.round(grab * 1000000000000) / 1000000000000;
	}
	return grab;
}

function fromHartreetokJ(value) { // From hartree to kJmol-1
	if (value != null) {
		var grab = parseFloat(value).toPrecision(12);
		grab = grab * 2625.50;
		grab = Math.round(grab * 1000) / 1000;
	}
	return grab;
}

function fromHartreetoRydberg(value) {
	if (value != null) {
		var grab = parseFloat(value).toPrecision(12);
		grab = grab * 2;
		grab = Math.round(grab * 1000000000000) / 1000000000000;
	}
	return grab;
}

function fromHartreetokcalmol(value) { // 1Hartree == 627.509 kcal*mol-1
	if (value != null) {
		var grab = parseFloat(value).toPrecision(12);
		grab = grab * 627.509;
		grab = Math.round(grab * 1000) / 1000;
	}
	return grab;
}

/// end Hartree

////ev

function fromevTokJ(value) {
	if (value != null) {
		var grab = parseFloat(value).toPrecision(12);
		grab = fromevToHartree(grab);
		grab = fromHartreetokJ(grab)
		grab = Math.round(grab * 1000) / 1000;
	}
	return grab;
}

function fromevToHartree(value) {
	if (value != null) {
		var grab = parseFloat(value).toPrecision(12);
		grab = fromHartreetoEv(1 / grab);
		grab = Math.round(grab * 1000000000000) / 1000000000000;
	}
	return grab;
}

function fromevTorydberg(value) {
	if (value != null) {
		var grab = parseFloat(value).toPrecision(12);
		grab = grab * 0.073498618;
		grab = Math.round(grab * 1000000000000) / 1000000000000;
	}
	return grab;
}

function fromevtoev(value) {
	if (value != null) {
		var grab = parseFloat(value).toPrecision(12);
		grab = Math.round(grab * 1000000000000) / 1000000000000;
	}
	return grab;
}

function fromevtokcalmol(value) {
	if (value != null) {
		var grab = parseFloat(value).toPrecision(12);
		grab = fromevToHartree(grab);
		grab = fromHartreetokcalmol(grab);
		grab = Math.round(grab * 1000) / 1000;
	}
	return grab;
}

////end ev

//rydberg

function fromRydbergtohartree(value) {
	if (value != null) {
		var grab = parseFloat(value).toPrecision(12);
		grab = fromHartreetoRydberg(1 / grab);
		grab = Math.round(grab * 1000000000000) / 1000000000000;
	}
	return grab;
}

function fromRydbergtoEv(value) {
	if (value != null) {
		var grab = parseFloat(value).toPrecision(12);
		grab = fromevTorydberg(1 / grab);
		grab = Math.round(grab * 1000000000000) / 1000000000000;
	}
	return grab;

}

function fromRydbergToKj(value) {
	if (value != null) {
		var grab = parseFloat(value).toPrecision(12);
		grab = fromHartreetokJ(grab / 2);
		grab = Math.round(grab * 1000) / 1000;
	}
	return grab;
}

function fromRytokcalmol(value) {
	if (value != null) {
		var grab = parseFloat(value).toPrecision(12);
		grab = fromRydbergtohartree(grab);
		grab = fromHartreetokcalmol(grab);
		grab = Math.round(grab * 1000) / 1000;
	}
	return grab;
}

function fromRydbergTorydberg(value) {
	if (value != null) {
		var grab = parseFloat(value).toPrecision(12);
		grab = Math.round(grab * 1000000000000) / 1000000000000;
	}
	return grab;
}

//1 Angstrom = 1.889725989 Bohr
function fromAngstromtoBohr(value) {
	if (value != null) {
		var grab = parseFloat(value).toPrecision(7);
		grab = grab * 1.889725989;
		grab = Math.round(grab * 10000000) / 10000000;
	}
	return grab;
}

/////////////////////////////////END ENERGY CONVERTION
      		
///js// Js/siesta.js /////
/*  J-ICE library 

    based on:
 *
 *  Copyright (C) 2010-2014 Pieremanuele Canepa http://j-ice.sourceforge.net/
 *
 *  Contact: pierocanepa@sourceforge.net
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA
 *  02111-1307  USA.
 */

//24th May 2011 P. Canepa
function loadSiesta() {
	setV('set errorCallback "errCallback";');
	setV("load ?.fdf; unitcell ON; set defaultDirectory; set messageCallback 'siestaCallBack'; message SIESTA; set echo top left; echo loading... HOLD ON;refresh;");
}

function siestaCallBack(a, m) {
	m = "" + m;
	// important to do this to change from Java string to JavaScript string
	if (m.indexOf("SIESTA") == 0) {
		setTitleEcho();
		readSiesta();
		warningMsg("This is a molecular reader. Therefore not all properties will be available.")
	}
}

var geomSiesta = new Array;
var freqSymmSiesta = new Array;
var freqIntensSiesta = new Array;
var freqSiesta = new Array;
var energySiesta = new Array;
var counterSiesta = 0;
function readSiesta() {
	// Reset program and set filename if available
	// This also extract the auxiliary info
	intizializeJiceSiesta();

	for (i = 0; i < Info.length; i++) {
		if (Info[i].name != null) {
			var line = Info[i].name;
			// alert(line)
			if (line.search(/E/i) != -1) {
				// alert("geometry")
				addOption(getbyID("geom"), i + " " + Info[i].name, i + 1);
				geomSiesta[i] = Info[i].name;
				if (Info[i].modelProperties.Energy != null
						|| Info[i].modelProperties.Energy != "")
					energySiesta[i] = Info[i].modelProperties.Energy;
				// alert(energyGauss[i])
				counterSiesta++;
			} else if (line.search(/cm/i) != -1) {
				// alert("vibration")
				addOption(getbyID("vib"), i + " " + Info[i].name + " ("
						+ Info[i].modelProperties.IRIntensity + ")", i);
				freqSiesta[i - counterSiesta] = Info[i].modelProperties.Frequency;
				freqSymmSiesta[i - counterSiesta] = Info[i].modelProperties.FrequencyLabel;
				freqIntensSiesta[i - counterSiesta] = Info[i].modelProperties.IRIntensity;
			}
		}
	}

	setMaxMinPlot();
	symmetryModeAddSiesta();

}

function intizializeJiceSiesta() {
	info = [];
	extractAuxiliaryJmol();
	var name = jmolGetPropertyAsJSON("filename");
	// cleanandReloadfrom();
	setTitleEcho();
	selectDesireModel("1");

	cleanArraySiesta();
	if (getbyID("sym") != null)
		cleanList("sym");
	if (getbyID("geom") != null)
		cleanList("geom");
	if (getbyID("vib") != null)
		cleanList("vib");
	disableFreqOpts();
}

function cleanArraySiesta() {
	geomSiesta = [];
	freqSymmSiesta = [];
	freqIntensSiesta = [];
	counterSiesta = 0;
}

function symmetryModeAddSiesta() {
	sortedSymm = new Array;
	sortedSymm = [];
	sortedSymm = unique(freqSymmSiesta);
	// alert(sortedSymm)
	for ( var i = 0; i < freqSymmSiesta.length; i++) {
		if (sortedSymm[i] != null)
			addOption(getbyID("sym"), freqSymmSiesta[i], freqSymmSiesta[i])
	}
}

function changeIrepSiesta(irep) {
	// alert(counterSiesta)
	for ( var i = 0; i < freqSiesta.length; i++) {
		var value = freqSymmSiesta[i];
		if (irep == value)
			addOption(getbyID("vib"), i + " " + freqSymmSiesta[i] + " "
					+ freqSiesta[i] + " (" + freqIntensSiesta[i] + ")", i
					+ counterSiesta + 1);
	}
}

function reLoadSiestaFreq() {
	if (getbyID("vib") != null)
		cleanList("vib");
	for ( var i = 0; i < freqSiesta.length; i++)
		addOption(getbyID("vib"), i + " " + freqSymmSiesta[i] + " "
				+ freqSiesta[i] + " (" + freqIntensSiesta[i] + ")", i
				+ counterSiesta + 1);

}
      		
///js// Js/spectra.js /////
/*  J-ICE library 

    based on:
 *
 *  Copyright (C) 2010-2014 Pieremanuele Canepa http://j-ice.sourceforge.net/
 *
 *  Contact: pierocanepa@sourceforge.net
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA
 *  02111-1307  USA.
 */

//This simulates the IR - Raman spectrum given an input 
var intTot = new Array();
var irFreq = new Array();
var RamanFreq = new Array();
var intTotNewboth = new Array();
var newRamanInt = new Array();
var newInt = new Array();
var summedInt = new Array();
var sortInt = new Array();
//var indexFreq = new Array();
var PI = Math.PI;

function simSpectrum() {
	var win = "menubar=yes,resizable=1,scrollbars,alwaysRaised,width=800,height=600,left=50";

	var freqCount = Info.length
	if (!flagCryVasp && flagOutcar && !flagGauss) { // VASP outcar
		freqCount = freqData.length - 1;
		// alert(freqCount);
	} else if (!flagCryVasp && !flagOutcar && flagGauss) {
		freqCount = freqGauss.length - 1;
	}

	var irInt = new Array();
	var RamanInt = new Array();
	var freqTot = new Array();
	var convoluzione;
	var flagGaussian = true;
	var sigma = getValue("sigma");
	intTot = [];
	var rescale = null;

	for ( var i = 0; i < document.modelsVib.kindspectra.length; i++) {
		if (document.modelsVib.kindspectra[i].checked)
			radvalue = document.modelsVib.kindspectra[i].value;
	}

	for ( var i = 0; i < document.modelsVib.convol.length; i++) {
		if (document.modelsVib.convol[i].checked)
			convoluzione = document.modelsVib.convol[i].value;
	}

	if (checkID("rescaleSpectra") == true) {
		rescale = true;

	} else {
		rescale = false;
	}

	switch (convoluzione) {

	case "stick":

		switch (radvalue) {
		case "ir": // IR + Raman

			irInt = [];
			RamanInt = [];

			irInt = extractFreqData(freqCount);
			var maxInt = maxValue(sortInt);
			// alert(maxInt)
			for ( var i = 0; i < 4000; i++) {
				if (intTot[i] == null)
					intTot[i] = 0.000;
				if (rescale) {
					if (intTot[i] != 0.00)
						intTot[i] = (intTot[i] / maxInt) * 100.00;
				}
			}
			// alert(intTot)

			break;

		case "raman":// Raman
			irInt = [];
			RamanInt = [];
			RamanInt = extractRamanData(freqCount);

			for ( var i = 0; i < 4000; i++) {
				for ( var k = 0; k < freqCount - 1; k++) {
					if (RamanFreq[k] == i)
						intTot[i] = 100;
				}
				if (intTot[i] == null)
					intTot[i] = 0;
			}
			break;
		case "both":

			irInt = [];
			RamanInt = [];
			irInt = extractFreqData(freqCount);
			if (flagCryVasp && !flagOutcar && !flagGauss && !flagDmol) {
				RamanInt = extractRamanData(freqCount);
				var maxInt = maxValue(sortInt);
				for ( var i = 0; i < 4000; i++) {

					if (newRamanInt[i] == null)
						newRamanInt[i] = 0;

					if (intTot[i] == null)
						intTot[i] = 0.000;
					if (rescale) {
						if (intTot[i] != 0.00)
							intTot[i] = (intTot[i] / maxInt) * 100.00;
					}

					intTot[i] = newRamanInt[i] + intTot[i];
				}

			} else if ((!flagCryVasp && flagOutcar && !flagGauss && !flagDmol)) {
				var maxInt = 100.00;
				for ( var i = 0; i < 4000; i++) {
					newInt[i] = 100.00;
					if (intTot[i] == null)
						intTot[i] = 0.000;

					if (rescale) {
						if (intTot[i] != 0.00)
							intTot[i] = (intTot[i] / maxInt) * 100.00;
					}

					intTot[i] = intTot[i];

				}

			} else if (!flagCryVasp && !flagOutcar && !flagGauss && flagDmol) {
				var maxInt = 100.00;
				for ( var i = 0; i < 4000; i++) {
					newInt[i] = 100.00;
					if (intTot[i] == null)
						intTot[i] = 0.000;

					if (rescale) {
						if (intTot[i] != 0.00)
							intTot[i] = (intTot[i] / maxInt) * 100.00;
					}

					intTot[i] = intTot[i];

				}

				// alert(intTot)
			} else if (!flagCryVasp && !flagOutcar && flagGauss && !flagDmol) {
				var maxInt = 100.00;
				for ( var i = 0; i < 4000; i++) {

					if (intTot[i] == null)
						intTot[i] = 0.000;

					if (rescale) {
						if (intTot[i] != 0.00)
							intTot[i] = (intTot[i] / maxInt) * 100.00;
					}

					intTot[i] = intTot[i];

				}
				// alert(intTot)
			}

			break;
		} // end switch stick
		break;

	case "gaus":
		flagGaussian = true;

		irInt = [];
		RamanInt = [];
		sortInt = [];
		irInt = extractFreqData(freqCount);
		if (flagCryVasp && !flagOutcar && !flagGauss && !flagDmol) {
			RamanInt = extractRamanData(freqCount);
			var maxInt = maxValue(sortInt);
			defineSpectrum(radvalue, freqCount, irInt, RamanInt, maxInt, sigma,
					flagGaussian);
		} else if (!flagCryVasp && flagOutcar && !flagGauss && !flagDmol) {
			var maxInt = 100.00;
			RamanInt = [];
			defineSpectrum(radvalue, freqCount, irInt, RamanInt, maxInt, sigma,
					flagGaussian);
		} else if (!flagCryVasp && !flagOutcar && flagGauss && !flagDmol) {
			RamanInt = [];
			var maxInt = maxR;
			defineSpectrum(radvalue, freqCount, irInt, RamanInt, maxInt, sigma,
					flagGaussian);
		} else if (!flagCryVasp && !flagOutcar && flagGauss && flagDmol) {
			RamanInt = [];
			var maxInt = maxR;
			defineSpectrum(radvalue, freqCount, irInt, RamanInt, maxInt, sigma,
					flagGaussian);
		}
		break;

	case "lor":
		flagGaussian = false;

		irInt = [];
		RamanInt = [];
		sortInt = [];
		irInt = extractFreqData(freqCount);
		if (flagCryVasp && !flagOutcar && !flagGauss && !flagDmol) {
			var maxInt = maxValue(sortInt);
			RamanInt = extractRamanData(freqCount);
			defineSpectrum(radvalue, freqCount, irInt, RamanInt, maxInt, sigma,
					flagGaussian);
		} else if (!flagCryVasp && flagOutcar && !flagGauss && !flagDmol) {
			var maxInt = 100.00;
			RamanInt = [];
			defineSpectrum(radvalue, freqCount, irInt, RamanInt, maxInt, sigma,
					flagGaussian);
		} else if (!flagCryVasp && !flagOutcar && flagGauss && !flagDmol) {
			RamanInt = [];
			var maxInt = maxR;
			defineSpectrum(radvalue, freqCount, irInt, RamanInt, maxInt, sigma,
					flagGaussian);
		} else if (!flagCryVasp && !flagOutcar && flagGauss && flagDmol) {
			RamanInt = [];
			var maxInt = maxR;
			defineSpectrum(radvalue, freqCount, irInt, RamanInt, maxInt, sigma,
					flagGaussian);
		}

		break;
	}

	// this opens the window that contains the spectrum
	var newwin = open("spectrum.html");

}

function extractIrData(freqCount) {
	var irInt = new Array();
	for ( var i = 0; i < freqCount - 1; i++) { // populate IR array
		if (Info[i].name != null) {
			if (Info[i].modelProperties.IRactivity == "A") {
				irFreq[i] = roundoff(
						substringFreqToFloat(Info[i].modelProperties.Frequency),
						0);
				irInt[i] = roundoff(
						substringIntFreqToFloat(Info[i].modelProperties.IRintensity),
						0);
				sortInt[i] = roundoff(
						substringIntFreqToFloat(Info[i].modelProperties.IRintensity),
						0);
				intTot[irFreq[i]] = roundoff(
						substringIntFreqToFloat(Info[i].modelProperties.IRintensity),
						0);
				intTotNewboth[irFreq[i]] = roundoff(
						substringIntFreqToFloat(Info[i].modelProperties.IRintensity),
						0);
				// if(irInt[i]== 0.0){
				// irInt[i] = 100.00;
				// intTot[irFreq[i]]= 100.00;
				// intTotNewboth[irFreq[i]] = 100.00;
				// }
			}
		}
	}
	return irInt;
}

function extractFreqData(freqCount) {
	var irInt = new Array();
	if (flagCryVasp && !flagOutcar && !flagGauss) {
		for ( var i = 0; i < freqCount - 1; i++) { // populate IR array
			if (Info[i].name != null) {
				irFreq[i] = roundoff(
						substringFreqToFloat(Info[i].modelProperties.Frequency),
						0);
				irInt[i] = roundoff(
						substringIntFreqToFloat(Info[i].modelProperties.IRintensity),
						0);
				sortInt[i] = roundoff(
						substringIntFreqToFloat(Info[i].modelProperties.IRintensity),
						0);
				intTot[irFreq[i]] = roundoff(
						substringIntFreqToFloat(Info[i].modelProperties.IRintensity),
						0);
				// if(irInt[i]== 0.00){
				// irInt[i] = 100.00;
				// intTot[irFreq[i]]= 100.00;
				// }
			}
		}
	} else if (!flagCryVasp && flagOutcar && !flagGauss) {
		for ( var i = 0; i < freqCount; i++) {

			irFreq[i] = roundoff(substringFreqToFloat(freqData[i]), 0);
			intTot[irFreq[i]] = 100.00;
			irInt[i] = 100.00;
			if (i == 0)
				irInt[i] = 0.00;

		}

	} else if (!flagCryVasp && !flagOutcar && flagGauss) {
		for ( var i = 0; i < freqCount; i++) {
			irFreq[i] = roundoff(substringFreqToFloat(freqGauss[i]), 0);
			intTot[irFreq[i]] = freqIntensGauss[i].substring(1,
					freqIntensGauss[i].indexOf("K") - 1);
			irInt[i] = freqIntensGauss[i].substring(1, freqIntensGauss[i]
			.indexOf("K") - 1);
		}
	}
	return irInt;
}

function extractRamanData(freqCount) {
	var RamanInt = new Array();
	for ( var i = 0; i < (freqCount - 1); i++) {
		if (Info[i].name != null) {
			RamanInt[i] = 0.000;
			if (Info[i].modelProperties.Ramanactivity == "A") {
				RamanFreq[i] = roundoff(
						substringFreqToFloat(Info[i].modelProperties.Frequency),
						0);
				RamanInt[i] = 100.00;
				newRamanInt[RamanFreq[i]] = 100;
			}
		}
	}
	return RamanInt;
}

function defineSpectrum(radvalue, freqCount, irInt, RamanInt, maxInt, sigma,
		flagGaussian) {

	var sp = 0.000;
	// Gaussian Convolution
	var cx = 4 * Math.LN2;
	var ssa = sigma * sigma / cx;
	var sb = Math.sqrt(cx) / (sigma * Math.sqrt(PI));

	// Lorentzian Convolution
	var xgamma = sigma;
	var ssc = xgamma * 0.5 / PI; // old ss1
	var ssd = (xgamma * 0.5) ^ 2; // old ss2
	var radvalue;
	var summInt = new Array();
	sortInt = [];
	var rescale = null;

	// alert(maxInt)
	if (checkID("rescaleSpectra") == true) {
		rescale = true;

	} else {
		rescale = false;
	}

	if (flagGaussian == true) {

		for ( var i = 0; i < 4000; i++) {
			sp = 0.000;
			if (intTot[i] == null)
				intTot[i] = 0;
			for ( var k = 0; k < freqCount - 1; k++) {
				switch (radvalue) {
				case "ir":
					if (irInt[k] == null)
						irInt[k] == 0.00;
					summInt[k] = irInt[k];
					break;
				case "raman":
					if (RamanInt[k] == null)
						RamanInt[k] == 0.00;
					summInt[k] = RamanInt[k];
					break;
				case "both":
					if (irInt[k] == null)
						irInt[k] == 0.00;
					if (flagCryVasp && !flagOutcar && !flagGauss) { // CRYSTAL
						if (RamanInt[k] == null)
							RamanInt[k] == 0.00;
						summInt[k] = irInt[k] + RamanInt[k];
					} else if ((!flagCryVasp && flagOutcar && !flagGauss)
							|| (!flagCryVasp && !flagOutcar && flagGauss)) { // VASP
						summInt[k] = irInt[k]
						// OUTCAR
						// or
						// GAUSSIAN
						// summInt[k]
						// =
						// irInt[k];
					}

					break;
				} // end switch
				if (irFreq[k] != null) {
					var xnn = i - irFreq[k];
					var f1 = Math.exp(-xnn * xnn / ssa) * summInt[k] * sb;
					if (rescale == true)
						var f1 = Math.exp(-xnn * xnn / ssa) * summInt[k]
					/ maxInt * 100 * sb;
					sp = sp + f1;

				}

			}
			intTot[i] = sp;
		}
	} else {

		for ( var i = 0; i < 4000; i++) {
			sp = 0.000;
			if (intTot[i] == null)
				intTot[i] = 0;
			for ( var k = 0; k < freqCount - 1; k++) {
				switch (radvalue) {
				case "ir":
					if (irInt[k] == null)
						irInt[k] == 0.00;
					summInt[k] = irInt[k];
					break;
				case "raman":
					if (RamanInt[k] == null)
						RamanInt[k] == 0.00;
					summInt[k] = RamanInt[k];
					break;
				case "both":
					if (irInt[k] == null)
						irInt[k] == 0.00;
					if (flagCryVasp && !flagOutcar) {
						if (RamanInt[k] == null)
							RamanInt[k] == 0.00;
						summInt[k] = irInt[k] + RamanInt[k];
					} else if ((!flagCryVasp && flagOutcar && !flagGauss)
							|| (!flagCryVasp && !flagOutcar && flagGauss)) { // VASP
						// OUTCAR
						// or
						// GAUSSIAN
						summInt[k] = irInt[k]
					}
					break;
				} // end switch
				if (irFreq[k] != null) {
					var xnn = i - irFreq[k];
					var f1 = ssc * summInt[k] / (xnn * xnn + ssd);
					if (rescale == true)
						var f1 = ssc * summInt[k] / maxInt * 100
						/ (xnn * xnn + ssd);
					sp = sp + f1;
				}

				intTot[i] = sp;
			}
		}
	}
}

function rangeSpectrum() {
	var s = "Min Freq. " + createTextSpectrum("minValue", "", "5", "")
	+ " Max " + createTextSpectrum("maxValue", "", "5", "")
	+ " cm<sup>-1</sup> ";
	s += createButton("rescaleSpectraButton", "Rescale", "replotSpectra()", "");
	s += createButton("savespectra", "Save spectrum", "writeSpectum()", "");
	document.write(s);
}

/*
 * function scaleSpectrum(){
 * 
 * var vecorFreq = new Array(); var vecorChk = new Array(); var counter; for(var
 * i =0 ; i < Info.length; i++){ vecorFreq[i] = Info[i].name; vecorChk[i] = 0
 * if(i == 0) vecorChk[i] = 1 counter++ }
 * 
 * var s = " Shift spectrum "; s+= createList("Frequencies", "", 0, 1, counter ,
 * vecorFreq, vecorFreq, vecorChk) + "" s+=
 * createText2("rescaleSpectra","0.00","5","") + " cm<sup>-1</sup>"; s+=
 * createButton("rescaleSpectraButton","Shift","","") document.write(s); }
 */

function sortNumber(a, b) {
	return a - b;
}

function maxValue(irInt) {
	// BH 2018
	irInt.sort(sortNumber);
	var n = 0;
	while (irInt.length > 0 && isNaN(n = parseInt(irInt.pop()))){}
	return (isNaN(n) ? 0 : n);
}

function minValue(irInt) {
	return parseInt(irInt.sort(sortNumber)[0]);
}
      		
///js// Js/uff.js /////
/*  J-ICE library 
 *
 *   based on:
 *
 *  Copyright (C) 2010-2014 Pieremanuele Canepa http://j-ice.sourceforge.net/
 *
 *  Contact: pierocanepa@sourceforge.net
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA
 *  02111-1307  USA.
 */

//////////Following functions control the structural optimization of a structure using the embedded uff of Jmol
var counterUff = 0
function minimizeStructure() {
	var optCriterion = parseFloat(getValue("optciteria"));
	var optSteps = parseInt(getValue("maxsteps"));
	var form = getbyID("fixstructureUff");
	// alert(optCriterion + " " + optSteps)

	if (!optCriterion) {
		warningMsg("Please set the Opt. threshold. This must be not lower than 0.0001. ");
		return false;
	} else if (!optSteps) {
		warningMsg("Please set the Max No. of steps.");
		return false;
	} else if (!form.checked) {
		counterUff = 0;
		setV("set debugscript on ;set logLevel 5");
		setV('set MinimizationCallback "scriptUffCallback"')
		//setV('set  set MessageCallback "showmsg" ')
		setV("set minimizationCriterion " + optCriterion + "; minimize STEPS "
				+ optSteps + "; set minimizationRefresh TRUE;  minimize;");
	} else if (form.checked) {
		//alert("is selected")
		counterUff = 0;
		setV("set debugscript on ;set logLevel 5");
		setV('set MinimizationCallback "scriptUffCallback"')
		//setV('set  set MessageCallback "showmsg" ')
		setV("set minimizationCriterion " + optCriterion + "; minimize STEPS "
				+ optSteps
				+ "; set minimizationRefresh TRUE;  minimize FIX {selected};");
	}
}

function fixFragmentUff(form) {
	if (form.checked) {
		messageMsg("Now select the fragment you would like to optimize by the following options");
		//fragmentSelect
	} else {

	}
}

function stopOptimize() {
	setV('minimize STOP;');
}

function resetOptimize() {
	setV('minimize STOP;');
	setVbyID("optciteria", "0.001");
	setVbyID("maxsteps", "100");
	setVbyID("textUff", "");
}

function scriptUffCallback(a, b, step, d, e, f, g) {
	var text = ("s = " + counterUff + " E = " + parseFloat(d).toPrecision(10)
			+ " kJ/mol, dE = " + parseFloat(e).toPrecision(6) + " kJ/mol")
	getbyID("textUff").value = text
	counterUff++;
}
      		
///js// Js/form.js /////
/*  J-ICE library 

    based on:
 *
 * Copyright (C) 2010-2014 Pieremanuele Canepa http://j-ice.sourceforge.net/
 *
 * Contact: pierocanepa@sourceforge.net
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA
 *  02111-1307  USA.
 */

function createButton(name, text, onclick, disab) {
	var s = "<INPUT TYPE='BUTTON'";
	s += "NAME='" + name + "' ";
	s += "VALUE='" + text + "' ";
	s += "ID='" + name + "' ";
	s += "CLASS='button'";
	if (disab) {
		s += "DISABLED "
	}
	s += "OnClick='" + onclick + "'> ";
	return s;
}

//This includes the class
function createButton1(name, text, onclick, disab, style) {
	var s = "<INPUT TYPE='BUTTON'";
	s += "NAME='" + name + "' ";
	s += "VALUE='" + text + "' ";
	s += "ID='" + name + "' ";
	s += "CLASS='" + style + "'";
	if (disab) {
		s += "DISABLED "
	}
	s += "OnClick='" + onclick + "'> ";
	return s;
}

//This includes the style
function createButton2(name, text, onclick, disab, style) {
	var s = "<INPUT TYPE='BUTTON'";
	s += "NAME='" + name + "' ";
	s += "VALUE='" + text + "' ";
	s += "ID='" + name + "' ";
	s += "style='" + style + "'";
	s += "CLASS='button'";
	if (disab) {
		s += "DISABLED "
	}
	s += "OnClick='" + onclick + "'> ";
	return s;
}

function createText(name, text, onclick, disab) {
	var s = "<INPUT TYPE='TEXT'";
	s += "NAME='" + name + "' ";
	s += "VALUE='" + text + "' ";
	s += "ID='" + name + "' ";
	s += "CLASS='text'";
	if (disab) {
		s += "DISABLED "
	}
	s += "OnChange='" + onclick + "'> ";
	return s;
}
function createCheck(name, text, onclick, disab, def, value) {
	var s = "<INPUT TYPE='CHECKBOX' ";
	s += " NAME='" + name + "' ";
	s += " ID='" + name + "' ";
	s += " VALUE='" + value + "' ";
	s += " CLASS='checkbox'";
	if (def) {
		s += " CHECKED "
	}
	if (disab) {
		s += " DISABLED "
	}
	s += "OnClick='" + onclick + "'> ";
	s += text;
	// var i=tabForm.length;
	// tabForm[i]=new formItem();
	// tabForm[i].Id=name;
	// tabForm[i].def=def;
	return s;
}
function createRadio(name, text, onclick, disab, def, id, value) {
	var s = "<INPUT TYPE='RADIO' ";
	s += " NAME='" + name + "' ";
	s += " ID='" + id + "' ";
	s += " VALUE='" + value + "'";
	s += " CLASS='checkbox'";
	if (def) {
		s += " CHECKED "
	}
	if (disab) {
		s += " DISABLED "
	}
	s += "OnClick='" + onclick + "'> ";
	s += text;
	// var i=tabForm.length;
	// tabForm[i]=new formItem();
	// tabForm[i].Id=id;
	// tabForm[i].def=def;
	return s;
}

function createList(name, onclick, disab, size, optionValue, optionText, optionCheck, type, onkey) {
	optionText || (optionText = optionValue);
	optionCheck || (optionCheck = [1]);
	if (optionValue.length != optionText.length)
		alert("form.js#createList optionValue not same length as optionText: " + name);
	var optionN = optionValue.length
	var s = "<SELECT ";
	s += "NAME='" + name + "' ";
	s += "ID='" + name + "' ";
	s += "SIZE='" + size + "' ";	
	if (disab) {
		s += "DISABLED ";
	}
	s += "OnChange='" + onclick + "' ";
	if (onkey)
		s += "OnKeypress='" + onkey + "' ";
	s += " CLASS='select";
	switch (type) {
	case "menu":
		s += "menu' resizable='yes";
		break;
	case "elem":
		return s + "'><option value=0>select</option></SELECT>";
	case "func":
	default:
		break;
	}
	s += "'>";
	for ( var n = 0; n < optionN; n++) {
		s += "<OPTION VALUE='" + optionValue[n] + "'";
		if (optionCheck[n] == 1) {
			s += "checked";
		}
		s += ">";
		s += optionText[n];
		s += "</OPTION>";
	}
	s += "</SELECT>";
	return s;
}

function createListFunc(name, onclick, onkey, disab, size, optionValue, optionText, optionCheck) {
	return createList(name, onclick, disab, size, optionValue, optionText, optionCheck, "func", onkey);
}

function createListmenu(name, onclick, disab, size, optionValue, optionText, optionCheck) {
	return createList(name, onclick, disab, size, optionValue, optionText, optionCheck, "menu");
}

function createList2(name, onclick, disab, size) {
	return createList(name, onclick, disab, size, []);
}

function createListKey(name, onclick, onkey, disab, size) {
	return createList(name, onclick, disab, size, [], [], [], "key", onkey)
}

function createListElement(name, onclick, onkey, disab, size, ) {
	return createList(name, onclick, disab, size, [], [], [], "elem", onkey)
}

function createTextArea(name, text, rows, cols, disab) {
	var s = "<TEXTAREA ";
	s += "NAME='" + name + "' ";
	s += "ID='" + name + "' ";
	s += "CLASS='text'";
	if (disab) {
		s += "DISABLED "
	}
	s += " ROWS=" + rows + " ";
	s += " COLS=" + cols + " >";
	s += text;
	s += "</TEXTAREA> ";
	return s;
}

function createText2(name, text, size, disab) {
	var s = "<INPUT TYPE='TEXT'";
	s += "NAME='" + name + "' ";
	s += "VALUE='" + text + "' ";
	s += "ID='" + name + "' ";
	s += "CLASS='text'";
	if (disab) {
		s += "DISABLED "
	}
	s += "SIZE=" + size + "> ";
	return s;
}

function createTextSpectrum(name, text, size, disab) {
	var s = "<INPUT TYPE='TEXT'";
	s += "NAME='" + name + "' ";
	s += "VALUE='" + text + "' ";
	s += "ID='" + name + "' ";
	s += "style='background-color:6a86c4;'"
	if (disab) {
		s += "DISABLED ";
	}
	s += "SIZE=" + size + "> ";
	return s;
}

function createText3(name, text, value, onchange, disab) {
	var s = "<INPUT TYPE='TEXT'";
	s += "NAME='" + name + "' ";
	s += "VALUE='" + text + "' ";
	s += "ID='" + name + "' ";
	s += "CLASS='text'";
	s += "onChange='" + onchange + "'";
	if (disab) {
		s += "DISABLED "
	}
	s += "> ";
	return s;
}

function createText4(name, text, size, value, onchange, disab) {
	var s = "<INPUT TYPE='TEXT'";
	s += "NAME='" + name + "' ";
	s += "VALUE='" + text + "' ";
	s += "ID='" + name + "' ";
	s += "CLASS='text'";
	s += "SIZE=" + size;
	s += "onChange='" + onchange + "'";
	if (disab) {
		s += "DISABLED "
	}
	s += "> ";
	return s;
}

function createText5(name, text, size, value, onchange, disab) {
	var s = "<INPUT TYPE='TEXT'";
	s += "NAME='" + name + "' ";
	s += "VALUE='" + text + "' ";
	s += "ID='" + name + "' ";
	s += "CLASS='textwhite'";
	s += "SIZE=" + size;
	s += "onChange='" + onchange + "'";
	if (disab) {
		s += "DISABLED "
	}
	s += "> ";
	return s;
}

function createDiv(name, style) {
	var s = "<DIV ";
	s += "NAME='" + name + "'";
	s += "ID='" + name + "'";
	s += "STYLE='" + style + "'>";
	return s;
}

function createLine(color, style) {
	var s = "<HR ";
	s += "COLOR='#D8E4F8' "
	s += "STYLE='" + style + "' >";
	return s;
}

      		
///js// Js/menu.js /////
/*  J-ICE library 
 *
 *  based on:
 *
 *  Copyright (C) 2010-2014 Pieremanuele Canepa http://j-ice.sourceforge.net/
 *
 *  Contact: pierocanepa@sourceforge.net
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA
 *  02111-1307  USA.
 */

/*
 LAST CHANGES
 22nd 04 - 2012 Piero Canepa
 */

//Common variables 
function defineMenu() {
	var tl;
	tl = tabMenu.length;
	tabMenu[tl] = new menu();
	tabMenu[tl].name = "File"; // Name that will appear on the tab
	tabMenu[tl].grp = "fileGroup"; // Name of the form that is displayed
	// If atom picking is active or not (not used)
	tabMenu[tl].link = "Import, Export files.";

	//
	tl = tabMenu.length;
	tabMenu[tl] = new menu();
	tabMenu[tl].name = "App.";
	tabMenu[tl].grp = "apparenceGroup";
	tabMenu[tl].link = "Change atom, bond clours and dimensions.";

	//
	tl = tabMenu.length;
	tabMenu[tl] = new menu();
	tabMenu[tl].name = "Edit";
	tabMenu[tl].grp = "editGroup";
	tabMenu[tl].link = "Change connectivity and remove atoms.";

	// added the 11th 11 2010
	// Last removed Sat Jul 5 08:52:31 AST 2014
/*	tl = tabMenu.length;
	tabMenu[tl] = new menu();
	tabMenu[tl].name = "Build";
	tabMenu[tl].grp = "builGroup";
	tabMenu[tl].link = "Modify and optimize structure.";*/

	//
	tl = tabMenu.length;
	tabMenu[tl] = new menu();
	tabMenu[tl].name = "Meas.";
	tabMenu[tl].grp = "measureGroup";
	tabMenu[tl].link = "Measure bond distances, angles and torsionals.";

	//
	tl = tabMenu.length;
	tabMenu[tl] = new menu();
	tabMenu[tl].name = "Orient.";
	tabMenu[tl].grp = "orientGroup";
	tabMenu[tl].link = "Change orientations and views.";

	//
	tl = tabMenu.length;
	tabMenu[tl] = new menu();
	tabMenu[tl].name = "Cell";
	tabMenu[tl].grp = "cellGroup";
	tabMenu[tl].link = "Modify cell features and simmetry.";

	//
	tl = tabMenu.length;
	tabMenu[tl] = new menu();
	tabMenu[tl].name = "Poly.";
	tabMenu[tl].grp = "polyGroup";
	tabMenu[tl].link = "Create polyhedra.";

	//
	tl = tabMenu.length;
	tabMenu[tl] = new menu();
	tabMenu[tl].name = "IsoSur.";
	tabMenu[tl].grp = "isoGroup";
	tabMenu[tl].link = "Modify from CUBE files and create isosurface map.";

	//
	tl = tabMenu.length;
	tabMenu[tl] = new menu();
	tabMenu[tl].name = "Geom.";
	tabMenu[tl].grp = "geometryGroup";
	tabMenu[tl].link = "Follow geometry optimizations.";
	//
	tl = tabMenu.length;
	tabMenu[tl] = new menu();
	tabMenu[tl].name = "Freq.";
	tabMenu[tl].grp = "freqGroup";
	tabMenu[tl].link = "Animate IR/Raman frequencies and simulate spectra.";

	//
	tl = tabMenu.length;
	tabMenu[tl] = new menu();
	tabMenu[tl].name = "E&M";
	tabMenu[tl].grp = "elecGroup";
	tabMenu[tl].link = "Superimpose Mulliken charges, spin, magnetic moment onto your structure.";

	//
	tl = tabMenu.length;
	tabMenu[tl] = new menu();
	tabMenu[tl].name = "Main";
	tabMenu[tl].grp = "otherpropGroup";
	tabMenu[tl].link = "Change background, light settings and other.";
	/*
	 * tl=tabMenu.length; tabMenu[tl]= new menu(); tabMenu[tl].name="History";
	 * tabMenu[tl].grp="HistoryGroup";
	 */
}

//////////////////////////create Grp functions (for each menu)
///////////////////////////// create File Grp
function createFileGrp() { // Here the order is crucial
	var elOptionArr = new Array("default", "loadC", "reload", "loadcif",
			"loadxyz", "loadOutcastep", "loadcrystal", "loadDmol",
			"loadaimsfhi", "loadgauss", "loadgromacs", "loadGulp",
			"loadmaterial", "loadMolden", "loadpdb", "loadQuantum",
			"loadSiesta", "loadShel", "loadVASPoutcar", "loadVasp", "loadWien",
			"loadXcrysden", "loadCUBE", "loadJvxl", "loadstate");
	var elOptionText = new Array("Load New FILE", "General (*.*)",
			"Reload current", "CIF (*.cif)", "XYZ (*.XYZ)",
			"CASTEP (INPUT, OUTPUT)", "CRYSTAL (*.*)", "Dmol (*.*)",
			"FHI-aims (*.in)", "GAUSSIAN0X (*.*)", "GROMACS (*.gro)",
			"GULP (*.gout)", "Material Studio (*.*)", "Molden, QEfreq (*.*)",
			"PDB (*.pdb)", "QuantumESPRESSO (*.*)", "Siesta (*,*)",
			"ShelX (*.*)", "VASP (OUTCAR, POSCAR)", "VASP (*.xml)",
			"WIEN2k (*.struct)", "Xcrysden (*.xtal)", "map (*.CUBE)",
			"map (*.jvxl)", "Jmol state (*.spt,*.png)");
	var strFile = "<form id='fileGroup' name='fileGroup' style='display:inline' class='contents'>\n";
	strFile += "<h2>File manager</h2>\n";
	strFile += "Load File<BR>\n";
	strFile += createListmenu('Load File', 'onChangeLoad(value)', 0, 1,
			elOptionArr, elOptionText);
	strFile += "<BR><BR>\n";
	strFile += "Export/Save File<BR>\n";
	// Save section
	var elSOptionArr = new Array("default", "saveCASTEP", "saveCRYSTAL",
			"saveGULP", "saveGROMACS", "saveQuantum", "saveVASP", "saveXYZ",
			"saveFrac", /* "savefreqHtml", */"savePNG", "savepdb", "savePOV",
	"saveState", "savePNGJ");
	var elSOptionText = new Array("Export File", "CASTEP (*.cell)",
			"CRYSTAL (*.d12)", "GULP (*.gin)", "GROMACS (*.gro)",
			"PWscf QuantumESPRESSO (*.inp)", "VASP (POSCAR)", "XYZ (*.XYZ)",
			"frac. coord. (*.XYZfrac)",
			// "save Frequencies HTML (*.HTML)",
			"image PNG (*.png)", "coordinates PDB (*.PDB)",
			"image POV-ray (*.pov)", "current state (*.spt)", "image+state (PNGJ)");
	strFile += createListmenu('Export File', 'onChangeSave(value)', 0, 1,
			elSOptionArr, elSOptionText);
	strFile += "<p ><img src='images/j-ice.png' alt='logo'/></p>";
	strFile += "<p style='color:#f00; font-weight:bold'>New readers <br> CASTEP, VASP POSCAR, and XcrysDen</p>";
	strFile += "<div style='margin-top:230px;'><p style='color:#000'> <b style='color:#f00'>Please DO CITE:</b>";
	strFile += "<blockquote>\"J-ICE: a new Jmol interface for handling<br> and visualizing Crystallographic<br> and Electronics properties.<br>"
	strFile += "P. Canepa, R.M. Hanson, P. Ugliengo, M. Alfredsson, <br>  J. Appl. Cryst. 44, 225 (2011). <a href='http://dx.doi.org/10.1107/S0021889810049411' target'blank'>[doi]</a> \"</blockquote> </p></div>";
	
	strFile += "<div style='margin-top:10px;'><b style='color:#f00'>JAVA compatibility:</b><br>User who installed the last Java Virtual Machine (JVM 8.0) ";
	strFile += "<br>please follow these instructions to execute J-ICE. <a href='https://www.java.com/en/download/faq/exception_sitelist.xml' target='blank'>here</a></div>"
	strFile += "</form>\n";
	return strFile;
}

///////////////////////////// create Appearance Grp
function createAppearanceGrp() {
	var colorBondsName = new Array("select", "atom", "bond");
	var dotName = new Array("select", "1", "2", "3", "4");
	var strApp = "<form id='apparenceGroup' name='apparenceGroup' style='display:none' >";
	strApp += "<table class='contents'><tr><td colspan='2'>\n";
	strApp += "<h2>Structure Appearance</h2>\n";
	strApp += "Select atom/s by:</td><tr>\n";
	strApp += "<tr><td colspan='2'>";
	strApp += "by element "
		+ createListKey("colourbyElementList", "elementSelected(value)",
				"elementSelected(value)", "", 1) + "\n";
	// strApp += "&nbsp;by atom &nbsp;"
	// + createList2('colourbyAtomList', 'atomSelected(value)', '', 1)
	// + "\n";
	strApp += createCheck("byselection", "by picking &nbsp;",
			'setPicking(this)', 0, 0, "set picking");

	strApp += createCheck("bydistance", "within a sphere (&#197); &nbsp;",
			'setDistancehidehide(this)', 0, 0, "");
	strApp += "</td></tr><tr><td colspan='2'>\n";
	strApp += createCheck("byplane", "within a plane &nbsp;",
			'setPlanehide(this)', 0, 0, "");
	strApp += "</td></tr><tr><td colspan='2'>\n";
	strApp += createButton('select All', 'select All', 'selectAll()', '')
	+ "\n";
	strApp += createButton('unselect', 'unselect All',
			'setV("select *; halos off; label off ; draw off")', '')
			+ "\n";
	strApp += createButton('halooff', 'Halo/s off',
			'setV("halos off; selectionhalos off; draw off" )', '')
			+ "\n";
	strApp += createButton('label All', 'Label All',
			'setV("select *; label on; draw off")', '')
			+ "\n";
	strApp += createButton('label off', 'Label off',
			'setV("select *; label off; draw off")', '')
			+ "\n";
	strApp += createLine('blue', '');
	strApp += "</td></tr><tr><td colspan='2'>\n";
	strApp += "Atom/s & bond/s style</td></tr> \n";
	strApp += "<tr><td > \n";
	strApp += "Atom/s colour: "
		+ createButton("Atomcolor", "Default colour",
				'setV("select *; color Jmol; draw off")', 0);
	strApp += "</td><td align='left'><script type='text/javascript'>\n";
	strApp += "var colorScript = [setAtomColor, 'atomColor'];";
	strApp += 'jmolColorPickerBox(colorScript, "");';
	strApp += "</script> </td></tr>";
	strApp += "<tr><td>Bond colour: "
		+ createButton("bondcolor", "Default colour",
				'setV(" color bonds Jmol")', 0);
	strApp += "</td><td align='left'> <script type='text/javascript'> jmolColorPickerBox('select *; color bond $COLOR$',[255,255,255])</script></td>";
	strApp += "</td></tr>";
	strApp += "<tr><td colspan='2'> Atom/s & bond/s finish \n";
	strApp += createRadio(
			"abFashion",
			"opaque",
			'toggleDivRadioTrans(value,"transulcencyDiv") + setV("color " +  getValue("setFashion") + " OPAQUE")',
			0, 1, "on", "on")
			+ "\n";
	strApp += createRadio(
			"abFashion",
			"translucent",
			'toggleDivRadioTrans(value,"transulcencyDiv") + setV("color " +  getValue("setFashion") + " TRANSLUCENT")',
			0, 0, "off", "off")
			+ "\n";
	strApp += createList('setFashion', '', 0, 1, colorBondsName)
			+ "\n";
	strApp += "</td></tr>"
		strApp += "<tr><td><div id='transulcencyDiv' style='display:none; margin-top:20px'>	";
	strApp += '<div tabIndex="1" class="slider" id="transSlider-div" style="float:left;width:150px;" >';
	strApp += '<input class="slider-input" id="transSlider-input" name="transSlider-input" />';
	strApp += '</div><div id="transMsg" class="msgSlider"></div></div>';
	strApp += "</td></tr><tr><td>";
	strApp += "Dot surface ";
	strApp += createList('setDot',
			'setV("dots on; set dotScale " + value + "; draw off")', 0, 1,
			dotName);
	strApp += createRadio("dotStyle", "off", 'setV("dots off")', 0, 0, "off",
	"off");
	strApp += createLine('blue', '');
	strApp += "</td></tr>\n";
	strApp += "<tr><td colspan='2'> Atom/s & bond/s Size<br> \n";
	strApp += createButton('Stick & Ball', 'Stick & Ball', 'onClickBS()', '')
	+ " \n";
	strApp += createButton('Stick', 'Stick', 'onStickClick()', '') + " \n";
	strApp += createButton('Ball', 'Ball', 'onClickBall()', '') + "\n";
	strApp += createButton('CPK', 'CPK', 'onClickCPK()', '') + " \n";
	strApp += createButton('ionic', 'Ionic', 'onClickionic()', '') + "\n";
	strApp += createCheck("wireframe", "wire",
			"setVCheckbox(this, this.value)", 0, 1, "wireframe; draw off");

	strApp += "</td></tr>";
	strApp += "<tr><td >";
	strApp += "wireframe";
	strApp += "</td><td>"
		strApp += '<div tabIndex="1" class="slider" id="bondSlider-div" style="float:left;width:150px;" >';
	strApp += '<input class="slider-input" id="bondSlider-input" name="bondSlider-input" />';
	strApp += '</div><div id="bondMsg" class="msgSlider"></div>';
	strApp += "</td></tr>";
	strApp += "<tr><td >";
	strApp += "vdW radii";
	strApp += "</td><td>";
	strApp += '<div tabIndex="1" class="slider" id="radiiSlider-div" style="float:left;width:150px;" >';
	strApp += '<input class="slider-input" id="radiiSlider-input" name="radiiSlider-input" />';
	strApp += '</div><div id="radiiMsg" class="msgSlider"></div>';
	strApp += "</td></tr>";
	strApp += "<tr><td colspan='2'>";
	strApp += createLine('blue', '');
	strApp += "H-bonds: "
		+ createRadio("H-bond", "on", 'setV("script ./scripts/hbond.spt")',
				0, 0, "") + "\n";
	strApp += createRadio("H-bond", "off",
			'setV("script ./scripts/hbond_del.spt")', 0, 1, "")
			+ "\n";
	strApp += " / solid H-bond"
		+ createRadio("dash", " on", 'setV("set hbondsSolid TRUE")', 0, 0,
		"") + "\n";
	strApp += createRadio("dash", "off", 'setV("set hbondsSolid FALSE")', 0, 1,
	"")
	+ "\n";
	strApp += "</td></tr><tr><td>H-bond colour: "
		+ createButton("bondcolor", "Default colour",
				'setV("color HBONDS none")', 0) + "</td><td>\n";
	strApp += "<script type='text/javascript' align='left'>jmolColorPickerBox('color HBONDS $COLOR$',[255,255,255])</script>";
	strApp += "</td></tr><tr><td colspan='2'> \n";
	strApp += "View / Hide Hydrogen/s "
		+ createCheck("hydrogenView", "", "setVCheckbox(this, this.value)",
				0, 1, "set showHydrogens") + "\n";
	strApp += "</td></tr></table> \n";
	strApp += createLine('blue', '');
	strApp += "</form>\n";
	return strApp;
}

///////////////////////////// edit Group
function createEditGroup() {
	var bondValue = new Array("select", "single", "partial", "hbond", "double",
			"aromatic", "partialDouble", "triple", "partialTriple",
	"parialTriple2");
	var strEdit = "<form id='editGroup' name='editGroup' style='display:none'>";
	strEdit += "<table class='contents'><tr><td > \n";
	strEdit += "<h2>Edit structure</h2>\n";
	strEdit += "</td></tr>\n";
	strEdit += "<tr><td>\n";
	strEdit += "Select atom/s by:\n";
	strEdit += "</td><tr>\n";
	strEdit += "<tr><td colspan='2'>";
	strEdit += "by element "
		+ createList2(
				"deletebyElementList",
				"elementSelectedDelete(value) + elementSelectedHide(value) ",
				false, 1) + "\n";
	// strEdit += "&nbsp;by atom &nbsp;"
	// + createList2('deltebyAtomList',
	// 'atomSelectedDelete(value) + atomSelectedHide(value) ', '',
	// 1) + "\n";
	strEdit += createCheck("byselection", "by picking &nbsp;",
			'setPickingDelete(this) + setPickingHide(this)', 0, 0, "");
	;
	strEdit += createCheck("bydistance", "within a sphere (&#197); &nbsp;",
			'setDistancehidehide(this)', 0, 0, "");
	strEdit += "</td></tr><tr><td colspan='2'>\n"
		strEdit += createCheck("byplane", "within a plane &nbsp;",
				'setPlanehide(this)', 0, 0, "");
	strEdit += "</td></tr><tr><td colspan='2'>\n";
	strEdit += createButton('select All', 'select All',
			'selectAllDelete()  + selectAllHide()', '')
			+ "\n";
	strEdit += createButton('unselect', 'unselect All',
			'setV("select *; halos off; label off")', '')
			+ "\n";
	strEdit += createButton('halooff', 'Halo/s off',
			'setV("halos off; selectionhalos off" )', '')
			+ "\n";
	strEdit += createButton('label All', 'Label All',
			'setV("select *; label on")', '')
			+ "\n";
	strEdit += createButton('label off', 'Label off',
			'setV("select *; label off")', '')
			+ "\n";
	strEdit += createLine('blue', '');
	strEdit += "</td></tr>\n";
	strEdit += "<tr><td colspan='2'>\n";
	strEdit += "Rename atom/s<br>";
	strEdit += "Element Name ";
	strEdit += createList('renameEle', 'changeElement(value)', 0, 1,
			eleSymb);
	strEdit += createLine('blue', '');
	strEdit += "</td></tr>\n";
	strEdit += "<tr><td colspan='2'>\n";
	strEdit += "Remove / hide atom/s <br>";
	strEdit += createButton('Delete atom', 'Delete atom/s', 'deleteAtom()', '')
	+ "\n";
	strEdit += createButton('Hide atom/s', 'Hide atom/s', 'hideAtom()', '')
	+ "\n";
	strEdit += createButton('Display atom', 'Display hidden atom/s',
			'setV("select hidden; display")', '')
			+ "\n";
	strEdit += createLine('blue', '');
	strEdit += "</td></tr>\n";
	strEdit += "<tr><td >";
	strEdit += "Connectivity</a>";
	strEdit += "</td><td>";
	strEdit += '<div tabIndex="1" class="slider" id="radiiConnect-div" style="float:left;width:150px;" >';
	strEdit += '<input class="slider-input" id="radiiConnect-input" name="radiiConnect-input" />';
	strEdit += '</div><div id="radiiConnectMsg" class="msgSlider"></div>';
	strEdit += '<br>'
		+ createCheck('allBondconnect', 'apply to all structures', '', 0,
				1, '');
	strEdit += "</td></tr>";
	strEdit += "<tr><td colspan='2'>\n";
	strEdit += createButton('advanceEdit', '+',
			'toggleDivValue(true,"advanceEditDiv")', '')
			+ " Advanced options <br>"
			strEdit += "<div id='advanceEditDiv' style='display:none; margin-top:20px'>";
	strEdit += "Connect by:\n";
	strEdit += createRadio("connect", "selection", 'checkBondStatus(value)', 0,
			0, "connect", "selection");
	strEdit += createRadio("connect", "by element", 'checkBondStatus(value)',
			0, 0, "connect", "atom");
	strEdit += createRadio("connect", "all", 'checkBondStatus(value)', 0, 0,
			"connect", "all")
			+ "<br>\n";
	strEdit += "From " + createList2("connectbyElementList", "", false, 1) + " ";
	strEdit += "To " + createList2("connectbyElementListone", "", false, 1)
	+ "<br>\n";
	strEdit += "Mode "
		+ createRadio("range", "whithin", 'checkWhithin(value)', 'disab',
				0, "range", "just");
	strEdit += createRadio("range", "whithin a range", 'checkWhithin(value)',
			'disab', 0, "range", "range")
			+ "<br>\n";
	strEdit += "From / whithin "
		+ createText2("radiuscoonectFrom", "", "2", "disab") + " ";
	strEdit += " to " + createText2("radiuscoonectTo", "", "2", "disab")
	+ " &#197;";
	strEdit += "<br> Style bond "
		+ createList('setBondFashion', '', 0, 1, bondValue) + "<br> \n";
	strEdit += createButton('connect2', 'Connect atom', 'connectAtom()', '');
	strEdit += createButton('connect0', 'Delete bond', 'deleteBond()', '')
	+ "<br>\n";
	strEdit += "</div>";
	strEdit += createLine('blue', '');
	strEdit += "</td></tr>\n";
	strEdit += "</table></FORM>\n";
	return strEdit;
}

//////////////////////////////create BuildGroup
function createBuildGroup() {
	var periodicityName = new Array("select", "crystal", "film", "polymer");
	var periodicityValue = new Array("", "crystal", "slab", "polymer");

	var strBuild = "<form id='builGroup' name='builGroup' style='display:none'>";
	strBuild += "<table class='contents'><tr><td> \n";
	strBuild += "<h2>Build and modify</h2>\n";
	strBuild += "</td></tr>\n";
	/*
	 * strBuild += "<tr><td>\n"; strBuild += "Add new atom/s <i>via</i>
	 * internal coordinates (distance, angle and torsional)<br>" strBuild +=
	 * createCheck("addZnew", "Start procedure",
	 * 'toggleDiv(this,"addAtomZmatrix") + addAtomZmatrix(this)', "", "", "");
	 * strBuild += "<div id='addAtomZmatrix' style='display:none;
	 * margin-top:20px'>"; strBuild += "<br> Element: " + createList('addEleZ',
	 * '', 0, 1, 100, eleSymb, eleSymb); strBuild += "<br>"; strBuild +=
	 * createButton("addAtom", "add Atom", "addZatoms()", ""); strBuild += "</div>"
	 * strBuild += createLine('blue', ''); strBuild += "</td></tr>\n";
	 */
	strBuild += "<tr><td>\n";
	strBuild += "Add new atom/s<br>";
	strBuild += createCheck("addNewFrac", "Start procedure",
			'addAtomfrac()  + toggleDiv(this,"addAtomCrystal")', "", "", "");
	strBuild += "<div id='addAtomCrystal' style='display:none; margin-top:20px'>";
	strBuild += "<br> \n ";
	strBuild += "x <input type='text'  name='x_frac' id='x_frac' size='1' class='text'> ";
	strBuild += "y <input type='text'  name='y_frac' id='y_frac' size='1' class='text'> ";
	strBuild += "z <input type='text'  name='z_frac' id='z_frac' size='1' class='text'> ";
	strBuild += ", Element: "
		+ createList('addNewFracList', '', 0, 1, eleSymb);
	strBuild += createButton("addNewFracListBut", "add Atom", "addNewatom()",
	"");
	strBuild += "<br><br> Read out coordinates of neighbor atom/s";
	strBuild += createRadio("coord", "fractional", 'viewCoord(value)', '', 0,
			"", "fractional");
	strBuild += createRadio("coord", "cartesian", 'viewCoord(value)', '', 0,
			"", "cartesian");
	strBuild += "</div>";
	strBuild += createLine('blue', '');
	strBuild += "</td></tr>\n";
	strBuild += "<tr><td>\n";
	strBuild += "Create a molecular CRYSTAL, FILM, POLYMER<br>";

	strBuild += createCheck(
			"createCrystal",
			"Start procedure",
			'createCrystalStr(this) + toggleDiv(this,"createmolecularCrystal")  + cleanCreateCrystal()',
			"", "", "");
	strBuild += "<div id='createmolecularCrystal' style='display:none; margin-top:20px'>";
	strBuild += "<br> Periodicity: "
		+ createList('typeMole', 'checkIfThreeD(value)', 0, 1,
				periodicityValue, periodicityName);
	strBuild += "<br> Space group: "
		+ createList('periodMole', 'setCellParamSpaceGroup(value)', 0, 1,
				spaceGroupValue, spaceGroupName)
				+ " <a href=http://en.wikipedia.org/wiki/Hermann%E2%80%93Mauguin_notation target=_blank>Hermann-Mauguin</a>"; // space
	// group
	// list
	// spageGroupName
	strBuild += "<br> Cell parameters: <br><br>";
	strBuild += "<i>a</i> <input type='text'  name='a_frac' id='a_frac' size='7' class='text'> ";
	strBuild += "<i>b</i> <input type='text'  name='b_frac' id='b_frac' size='7' class='text'> ";
	strBuild += "<i>c</i> <input type='text'  name='c_frac' id='c_frac' size='7' class='text'> ";
	strBuild += " &#197; <br>";
	strBuild += "<i>&#945;</i> <input type='text'  name='alpha_frac' id='alpha_frac' size='7' class='text'> ";
	strBuild += "<i>&#946;</i> <input type='text'  name='beta_frac' id='beta_frac' size='7' class='text'> ";
	strBuild += "<i>&#947;</i> <input type='text'  name='gamma_frac' id='gamma_frac' size='7' class='text'> ";
	strBuild += " degrees <br><br> "
		+ createButton("createCrystal", "Create structure",
				"createMolecularCrystal()", "") + "</div>";
	strBuild += createLine('blue', '');
	strBuild += "</td></tr>\n";
	strBuild += "<tr><td>\n";
	strBuild += "Optimize (OPT.) structure  UFF force filed<br>";
	strBuild += "Rappe, A. K., <i>et. al.</i>; <i>J. Am. Chem. Soc.</i>, 1992, <b>114</b>, 10024-10035. <br><br>";
	strBuild += createButton("minuff", "Optimize", "minimizeStructure()", "");
	strBuild += createCheck("fixstructureUff", "fix fragment",
			'fixFragmentUff(this) + toggleDiv(this,"fragmentSelected")', "",
			"", "")
			+ " ";
	strBuild += createButton("stopuff", "Stop Opt.", "stopOptimize()", "");
	strBuild += createButton("resetuff", "Reset Opt.", "resetOptimize()", "");
	strBuild += "</td></tr><tr><td><div id='fragmentSelected' style='display:none; margin-top:20px'>Fragment selection options:<br>";
	// strBuild += "by element "
	// + createListKey("colourbyElementList", "elementSelected(value)",
	// "elementSelected(value)", "", 1) + "\n";
	// strBuild += "&nbsp;by atom &nbsp;"
	// + createList2('colourbyAtomList', 'atomSelected(value)', '', 1)
	// + "\n";
	strBuild += createCheck("byselection", "by picking &nbsp;",
			'setPicking(this)', 0, 0, "set picking");
	strBuild += createCheck("bydistance", "within a sphere (&#197) &nbsp;",
			'setDistancehidehide(this)', 0, 0, "");
	strBuild += createCheck("byplane", " within a plane &nbsp;",
			'setPlanehide(this)', 0, 0, "");
	strBuild += "</div>";
	strBuild += "</td></tr><tr><td>\n";
	strBuild += "<br> Structural optimization criterion: <br>";
	strBuild += "Opt. threshold <input type='text'  name='optciteria' id='optciteria' size='7'  value='0.001' class='text'> kJ*mol<sup>-1</sup> (Def.: 0.001, Min.: 0.0001) <br>";
	strBuild += "Max. No. Steps <input type='text'  name='maxsteps' id='maxsteps' size='7'  value='100' class='text'> (Def.: 100)";
	strBuild += "<tr><td>";
	strBuild += "<br> Optimization Output: <br>";
	strBuild += createTextArea("textUff", "", 4, 50, "");
	strBuild += createLine('blue', '');
	strBuild += "</td></tr>\n";
	strBuild += "</table>\n";
	strBuild += "</form>\n";
	return strBuild;
}

/////////////////////////////Measure Group

function createMeasureGroup() {
	var measureName = new Array("select", "Angstroms", "Bohr", "nanometers",
	"picometers");
	var measureValue = new Array("select", "angstroms", "BOHR", "nm", "pm");
	var textValue = new Array("0", "6", "8", "10", "12", "16", "20", "24", "30");
	var textText = new Array("select", "6 pt", "8 pt", "10 pt", "12 pt",
			"16 pt", "20 pt", "24 pt", "30 pt");
	
	var strMeas = "<form id='measureGroup' name='measureGroup' style='display:none'>";
	strMeas += "<table class='contents'><tr><td > \n";
	strMeas += "<h2>Measure and Info</h2>\n";
	strMeas += "</td></tr>\n";
	strMeas += "<tr><td colspan='2'>\n";
	strMeas += "Measure<br>\n";
	strMeas += createRadio("distance", "distance", 'checkMeasure(value)', '',
			0, "", "distance");
	strMeas += createListFunc('measureDist', 'setMeasureUnit(value)',
			'setTimeout("setMeasureUnit(value) ",50)', 0, 1, measureValue,
			measureName)
			+ " ";
	strMeas += createRadio("distance", "angle", 'checkMeasure(value)', '', 0,
			"", "angle");
	strMeas += createRadio("distance", "torsional", 'checkMeasure(value)', '',
			0, "", "torsional");
	strMeas += "<br><br> Measure value: <br>"
		+ createTextArea("textMeasure", "", 10, 60, "");
	strMeas += "<br>"
		+ createButton('resetMeasure', 'Delete Measure/s', 'mesReset()', '')
		+ "<br>";
	strMeas += "</td></tr>\n";
	strMeas += "<tr><td>Measure colour: "
		+ createButton("colorMeasure", "Default colour",
				'setV("color measures none")', 0) + "</td><td >\n";
	strMeas += "<script type='text/javascript' align='left'>jmolColorPickerBox('color measures $COLOR$',[255,255,255])</script>";
	strMeas += "</td></tr>";
	strMeas += "<tr><td colspan='2'>";
	strMeas += createLine('blue', '');
	strMeas += "</td></tr>";
	strMeas += "<tr><td colspan='2'>";
	strMeas += "View coordinates: ";
	strMeas += createRadio("coord", "fractional", 'viewCoord(value)', '', 0,
			"", "fractional");
	strMeas += createRadio("coord", "cartesian", 'viewCoord(value)', '', 0, "",
	"cartesian");
	strMeas += createLine('blue', '');
	strMeas += "</td></tr>";
	strMeas += "<tr><td colspan='2'>";
	strMeas += "Font size ";
	strMeas += createList("fSize", "setMeasureSize(value)", 0, 1,
			textValue, textText);
	strMeas += createLine('blue', '');
	strMeas += "</td></tr>";
	strMeas += "</table></FORM>  \n";
	return strMeas;
}

//////////////////////////////create orientationGroup

function createOrientGrp() {
	var motionValueName = new Array("select", "translate", "rotate");
	var strOrient = "<form id='orientGroup' name='orientGroup' style='display:none'>\n";
	strOrient += "<table class='contents' ><tr><td><h2>Orientation and Views</td><tr>\n";
	strOrient += "<tr><td>\n";
	strOrient += "Spin "
		+ createRadio("spin", "x", 'setV("spin x")', 0, 0, "", "") + "\n";
	strOrient += createRadio("spin", "y", 'setV("spin y")', 0, 0, "", "")
	+ "\n";
	strOrient += createRadio("spin", "z", 'setV("spin z")', 0, 0, "", "")
	+ "\n";
	strOrient += createRadio("spin", "off", 'setV("spin off")', 0, 1, "", "")
	+ "\n";
	strOrient += createLine('blue', '');
	strOrient += "</td></tr>\n";
	strOrient += "<tr><td>\n";
	strOrient += "Zoom " + createButton('in', 'in', 'setV("zoom in")', '')
	+ " \n";
	strOrient += createButton('out', 'out', 'setV("zoom out")', '') + " \n";
	strOrient += createLine('blue', '');
	strOrient += "</td></tr>\n";
	strOrient += "<tr><td>\n";
	strOrient += "View from"
		+ createButton('top', 'top', 'setV("moveto  0 1 0 0 -90")', '')
		+ " \n";
	strOrient += createButton('bottom', 'bottom', 'setV("moveto  0 1 0 0 90")',
	'')
	+ " \n";
	strOrient += createButton('left', 'left', 'setV("moveto  0 0 1 0 -90")', '')
	+ " \n";
	strOrient += createButton('right', 'right', 'setV("moveto  0 0 1 0 90")',
	'')
	+ " \n";
	strOrient += "<br> Orient along ";
	strOrient += createButton(
			'a',
			'a',
			'setV("moveto 1.0 front;var axisA = {1/1 0 0};var axisZ = {0 0 1};var rotAxisAZ = cross(axisA,axisZ);var rotAngleAZ = angle(axisA, {0 0 0}, rotAxisAZ, axisZ);moveto 1.0 @rotAxisAZ @{rotAngleAZ};var thetaA = angle({0 0 1}, {0 0 0 }, {1 0 0}, {1, 0, 1/});rotate z @{0-thetaA};")',
	'');
	strOrient += createButton(
			'b',
			'b',
			'setV("moveto 1.0 front;var axisB = {0 1/1 0};var axisZ = {0 0 1};var rotAxisBZ = cross(axisB,axisZ);var rotAngleBZ = angle(axisB, {0 0 0}, rotAxisBZ, axisZ);moveto 1.0 @rotAxisBZ @{rotAngleBZ}")',
	'');
	strOrient += createButton(
			'c',
			'c',
			'setV("moveto 1.0 front;var axisC = {0 0 1/1};var axisZ = {0 0 1};var rotAxisCZ = cross(axisC,axisZ);var rotAngleCZ = angle(axisC, {0 0 0}, rotAxisCZ, axisZ);moveto 1.0 @rotAxisCZ @{rotAngleCZ}")',
	'');
	strOrient += createLine('blue', '');
	strOrient += "</td></tr>\n";
	strOrient += "<tr><td>\n";
	strOrient += "Z-Clip functions<br>"
		+ createCheck("slabToggle", "Z-clip", 'toggleSlab()', 0, 0,
		"slabToggle");
	strOrient += "</td></tr>\n";
	strOrient += "<tr><td>\n";
	strOrient += "Front";
	strOrient += "</td></tr>\n";
	strOrient += "<tr><td>\n";
	strOrient += '<div tabIndex="1" class="slider" id="slabSlider-div" style="float:left;width:150px;" >';
	strOrient += '<input class="slider-input" id="slabSlider-input" name="slabSlider-input" />';
	strOrient += '</div><div id="slabSliderMsg" class="msgSlider"></div>';
	strOrient += "</td></tr>\n";
	strOrient += "<tr><td>\n";
	strOrient += "Back";
	strOrient += "</td></tr>\n";
	strOrient += "<tr><td>\n";
	strOrient += '<div tabIndex="1" class="slider" id="depthSlider-div" style="float:left;width:150px;" >';
	strOrient += '<input class="slider-input" id="depthSlider-input" name="depthSlider-input" />';
	strOrient += '</div><div id="depthSliderMsg" class="msgSlider"></div>';
	strOrient += "</td></tr>\n";
	strOrient += "<tr><td>\n";
	strOrient += createLine('blue', '');
	strOrient += "</td></tr>\n";
	strOrient += "<tr><td>\n";
	strOrient += "Fine orientation\n";
	strOrient += "<table class='contents'> \n";
	strOrient += "<tr><td colspan='3'>Motion "
		+ createListFunc('setmotion', 'setKindMotion(value)',
				'setTimeout("setKindMotion(value)",50)', 0, 1,
				motionValueName, motionValueName);
	strOrient += " magnitude\n";
	strOrient += "<input type='text' value='5' class='text' id='fineOrientMagn' size='3'> &#197 / degree;";
	strOrient += "</td></tr>\n";
	strOrient += "<tr><td colspan='2'> ";
	strOrient += createCheck(
			"moveByselection",
			"move only slected atom/s",
			"checkBoxStatus(this, 'byElementAtomMotion')  + checkBoxStatus(this, 'byAtomMotion')",
			0, 0, "moveByselection");
	strOrient += "</td></tr>\n";
	strOrient += "<tr><td colspan='2'> ";
	strOrient += "by element "
		+ createList2("byElementAtomMotion", "elementSelected(value)", false, 1) + "\n";
	// strOrient += "&nbsp;by atom &nbsp;"
	// + createList2('byAtomMotion', 'atomSelected(value)', '', 1) + "\n";
	strOrient += createCheck("byselectionOrient", "by picking &nbsp;",
			'setPicking(this)', 0, 0, "set picking");
	strOrient += "</td></tr><tr><td colspan='2'>\n";
	strOrient += createButton('select All', 'select All', 'selectAll()', '')
	+ "\n";
	strOrient += createButton('unselect', 'unselect All',
			'setV("select *; halos off; label off")', '')
			+ "\n";
	strOrient += createButton('halooff', 'Halo/s off',
			'setV("halos off; selectionhalos off" )', '')
			+ "\n";
	strOrient += createButton('label All', 'Label All',
			'setV("select *; label on")', '')
			+ "\n";
	strOrient += createButton('label off', 'Label off',
			'setV("select *; label off")', '')
			+ "\n";
	strOrient += "</td></tr><td ><tr>\n";
	strOrient += "<table >\n";
	strOrient += "<tr><td>"
		+ createButton2('-x', '-x', 'setMotion(id)', '', 'width:40px;')
		+ "</td><td>\n";
	strOrient += createButton2('x', '+x', 'setMotion(id)', '', 'width:40px;')
	+ "</td></tr>\n";
	strOrient += "<tr><td>"
		+ createButton2('-y', '-y', 'setMotion(id)', '', 'width:40px;')
		+ "</td><td>\n";
	strOrient += createButton2('y', '+y', 'setMotion(id)', '', 'width:40px;')
	+ "</td></tr>\n";
	strOrient += "<tr><td>"
		+ createButton2('-z', '-z', 'setMotion(id)', '', 'width:40px;')
		+ "</td><td>\n";
	strOrient += createButton2('z', '+z', 'setMotion(id)', '', 'width:40px;')
	+ "</td></tr>\n";
	strOrient += "</table> \n";
	strOrient += "<tr><td>\n";
	strOrient += "</td></tr>\n";
	strOrient += "</table>\n";
	strOrient += createLine('blue', '');
	strOrient += "</form>\n";
	return strOrient;
}

///////////////////////////// create cellGroup

function createCellGrp() {
	var unitcellName = new Array("0 0 0", "1/2 1/2 1/2", "1/2 0 0", "0 1/2 0",
			"0 0 1/2", "-1/2 -1/2 -1/2", "1 1 1", "-1 -1 -1", "1 0 0", "0 1 0",
	"0 0 1");
	var unitcellSize = new Array("1", "2", "3", "4", "5", "6", "7", "8", "9",
			"10", "11", "12", "13", "14", "15", "16", "17", "18", "19");
	var strCell = "<form id='cellGroup' name='cellGroup' style='display:none'>";
	strCell += "<table class='contents'><tr><td><h2>Cell properties</h2></td></tr>\n";
	strCell += "<tr><td colspan='2'>"
		+ createCheck("cell", "View Cell",
				"setVCheckbox(this, this.value)", 0, 1, "unitcell");
	strCell += createCheck("axes", "View axes",
			"setVCheckbox(this, this.value)", 0, 1, "set showAxes");
	strCell += "</td></tr><tr><td> Cell style:  \n";
	strCell += "size "
		+ createListFunc('offsetCell',
				'setV("set unitcell " + value + ";")',
				'setTimeout("setV("set unitcell " + value +";")",50)', 0,
				1, unitcellSize, unitcellSize) + "\n";
	strCell += " dotted "
		+ createCheck("cellDott", "dotted, ", "setCellDotted()", 0, 0,
		"DOTTED") + "  color ";
	strCell += "</td><td align='left'>\n";
	strCell += "<script type='text/javascript' align='left'>jmolColorPickerBox('set unitCellColor \"$COLOR$\"',[000,000,000])</script>";
	strCell += "</td></tr>\n";
	// strCell += createLine('blue', '');
	strCell += "<tr><td colspan='2'>Set cell:  \n";

	strCell += createRadio("cella", "primitive", 'setCellType(value)', 0, 1,
			"primitive", "primitive")
			+ "\n";
	strCell += createRadio("cella", "conventional", 'setCellType(value)', 0, 0,
			"conventional", "conventional")
			+ "\n";
	strCell += "</td></tr>\n";
	strCell += "<tr><td> \n";
	strCell += createCheck('superPack', 'Auto Pack', 'uncheckPack()', 0, 1, '')
	+ " ";
	strCell += createCheck('chPack', 'Choose Pack Range',
			'checkPack() + toggleDiv(this,"packDiv")', '', '', '');
	strCell += "</td></tr>\n";
	strCell += "<tr><td> \n";
	strCell += "<div id='packDiv' style='display:none; margin-top:30px'>";
	strCell += '<div tabIndex="1" class="slider" id="packSlider-div" style="float:left;width:150px;" >';
	strCell += '<input class="slider-input" id="packSlider-input" name="packSlider-input" />';
	strCell += '</div><div id="packMsg" class="msgSlider"></div></div></div>';
	strCell += "</td></tr>\n";
	strCell += "<tr><td colspan='2'> \n";
	strCell += createLine('blue', '');
	strCell += "Supercell: <br>";
	strCell += "</td></tr><tr><td colspan='2'>\n";
	strCell += "<i>a: </i>";
	strCell += "<input type='text'  name='par_a' id='par_a' size='1' class='text'>";
	strCell += "<i> b: </i>";
	strCell += "<input type='text' name='par_b' id='par_b' size='1' class='text'>";
	strCell += "<i> c: </i>";
	strCell += "<input type='text'  name='par_c' id='par_c' size='1' class='text'> &#197;";
	strCell += createCheck('supercellForce', 'force supercell (P1)', '', '',
			'', '')
			+ "<br>\n";
	strCell += createButton('set_pack', 'pack', 'setPackaging()', '') + " \n";
	strCell += createLine('blue', '');
	strCell += "</td></tr>\n";
	strCell += "<tr><td colspan='2'> \n";
	strCell += "Offset unitcell \n<br>";
	strCell += "Common sets "
		+ createListFunc('offsetCell', 'setUnitCellOrigin(value)',
				'setTimeout("setUnitCellOrigin(value)",50)', 0, 1,
				unitcellName, unitcellName) + "\n";
	strCell += "<br>  \n"
		strCell += createButton('advanceCelloffset', '+',
				'toggleDivValue(true,"advanceCelloff")', '')
				+ " Advanced cell-offset options <br>"
				strCell += "<div id='advanceCelloff' style='display:none; margin-top:20px'>"
					+ createCheck("manualCellset", "Manual set",
							'checkBoxStatus(this, "offsetCell")', 0, 0, "manualCellset")
							+ "\n";
	strCell += " x: ";
	strCell += "<input type='text'  name='par_x' id='par_x' size='3' class='text'>";
	strCell += " y: ";
	strCell += "<input type='text'  name='par_y' id='par_y' size='3' class='text'>";
	strCell += " z: ";
	strCell += "<input type='text'  name='par_z' id='par_z' size='3' class='text'>";
	strCell += createButton('setnewOrigin', 'set', 'setManualOrigin()', '')
	+ " \n";
	strCell += "</div>";
	strCell += createLine('blue', '');
	strCell += "</td></tr>\n";
	strCell += "<tr ><td colspan='2'>\n";
	strCell += "Cell parameters (selected model)<br>\n";
	strCell += "Unit: "
		+ createRadio("cellMeasure", "&#197", 'setCellMeasure(value)', 0,
				1, "", "a") + "\n";
	strCell += createRadio("cellMeasure", "Bohr", 'setCellMeasure(value)', 0,
			0, "", "b")
			+ "\n <br>";
	strCell += "<i>a</i> " + createText2("aCell", "", 7, "");
	strCell += "<i>b</i> " + createText2("bCell", "", 7, "");
	strCell += "<i>c</i> " + createText2("cCell", "", 7, "") + "<br><br>\n";
	strCell += "<i>&#945;</i> " + createText2("alphaCell", "", 7, "");
	strCell += "<i>&#946;</i> " + createText2("betaCell", "", 7, "");
	strCell += "<i>&#947;</i> " + createText2("gammaCell", "", 7, "")
	+ " degrees <br><br>\n";
	strCell += "Voulme cell " + createText2("volumeCell", "", 10, "")
	+ "  &#197<sup>3</sup><br><br>";
	strCell += createButton('advanceCellval', '+',
			'toggleDivValue(true,"advanceCellvalue")', '')
			+ " Advanced cell options <br>"
			strCell += "<div id='advanceCellvalue' style='display:none; margin-top:20px'>"
				strCell += "<i>b/a</i> " + createText2("bovera", "", 8, "") + " ";
	strCell += "<i>c/a</i> " + createText2("covera", "", 8, "");
	strCell += "</div>"
		strCell += createLine('blue', '');
	strCell += "</td></tr>\n";
	strCell += "<tr><td colspan='2'> \n";
	strCell += "Symmetry operators ";
	strCell += "<div id='syminfo'></div>";
	strCell += createLine('blue', '');
	strCell += "</td></tr>\n";
	strCell += "</table></FORM>\n";
	return strCell;
}

///////////////////////////// create polyGroup

function createPolyGrp() {
	var polyEdgeName = new Array("select", "4, 6", "4 ", "6", "8", "10", "12");
	var polyStyleName = new Array("select", "flat", "collapsed edges",
			"no edges", "edges", "frontedges");
	var polyStyleValue = new Array("NOEDGES", "flat edges", "collapsed",
			"noedges", "edges", "frontedges");
	var polyFaceName = new Array("0.0", "0.25", "0.5", "0.9", "1.2");
	var strPoly = "<FORM id='polyGroup' name='polyGroup' style='display:none'>\n";
	strPoly += "<table class='contents'>\n";
	strPoly += "<tr><td>\n";
	strPoly += "<h2>Polyhedron</h2>\n";
	strPoly += "</td></tr>\n";
	strPoly += "<tr><td colspan='2'>\n";
	strPoly += "Make polyhedra: \n";
	strPoly += "</td></tr>\n";
	strPoly += "<tr><td  colspan='2'>\n";
	strPoly += "</td></tr>\n";
	strPoly += "<tr><td colspan='2'>\n";
	strPoly += "&nbsp;a) Select central atom:  <br>\n";
	strPoly += "&nbsp;&nbsp;  by element "
		+ createList2('polybyElementList', "", false, 0);
	// strPoly+=createCheck("byselectionPoly", "&nbsp;by picking &nbsp;",
	// 'setPolybyPicking(this)', 0, 0, "set picking") + "<br>\n";
	strPoly += "<br>&nbsp;&nbsp;just central atom"
		+ createCheck("centralPoly", "",
				'checkBoxStatus(this, "poly2byElementList")', 0, 0, "");
	strPoly += "</td></tr>\n";
	strPoly += "<tr><td colspan='2'>\n";
	strPoly += "&nbsp; b) select vertex atoms:  <br>\n";
	strPoly += "&nbsp;&nbsp;  by element "
		+ createList2('poly2byElementList', "", false, 0) + "\n";
	strPoly += "</td></tr>\n";
	strPoly += "<tr><td colspan='2'>\n";
	strPoly += "&nbsp; c) based on <br>";
	strPoly += "&nbsp;"
		+ createRadio("bondPoly", "bond", 'makeDisable("polyDistance") ',
				0, 0, "bondPoly", "off");
	strPoly += createRadio("bondPoly", " max distance ",
			' makeEnable("polyDistance")', 0, 0, "bondPoly1", "on");
	strPoly += createText2("polyDistance", "2.0", "3", "") + " &#197;";
	strPoly += "</td></tr>\n";
	strPoly += "<tr><td colspan='2'>\n";
	strPoly += "&nbsp;d) number of vertex "
		+ createList('polyEdge', '', 0, 0, polyEdgeName) + "\n";
	strPoly += createLine('blue', '');
	strPoly += "</td></tr>\n";
	strPoly += "<tr><td colspan='2'>\n";
	strPoly += "Polyedra style:<br>\n";
	strPoly += "</td></tr><tr><td > &nbsp;a) colour polyhedra\n";
	strPoly += createButton("polyColor", "Default colour",
			'setV("set defaultColors Jmol")', 0);
	strPoly += "</td><td align='left'><script type='text/javascript'>\n";
	strPoly += "var Colorscript = [setPolyColor, 'color'];";
	strPoly += "jmolColorPickerBox(Colorscript, '');";
	strPoly += "</script> </td></tr>";
	strPoly += "<tr><td colspan='2'>\n";
	strPoly += createButton('advanceEdit', '+',
			'toggleDivValue(true,"advancePolyDiv")', '')
			+ " Advanced style options"
			strPoly += "<div id='advancePolyDiv' style='display:none; margin-top:20px'>"
				strPoly += "<br> &nbsp;b)"
					+ createRadio("polyFashion", "opaque",
							'setV("color polyhedra opaque") ', 0, 1, "opaque", "opaque")
							+ "\n";
	strPoly += createRadio("polyFashion", "translucent",
			'setV("color polyhedra translucent") ', 0, 0, "translucent",
	"translucent")
	+ "\n<br><br>";
	strPoly += "&nbsp;c) style edges\n"
		+ createList('polyVert', 'checkPolyValue(this.value)', 0, 0,
				polyStyleValue, polyStyleName) + "\n";
	strPoly += "<br>"
		strPoly += "&nbsp;&nbsp;collapsed faces Offset \n"
			+ createList('polyFace', '', 0, 0, polyFaceName) + "\n";
	strPoly += "</div>";
	strPoly += createLine('blue', '');
	strPoly += "</td></tr>\n";
	strPoly += "<tr><td colspan='2'>\n";
	strPoly += createButton('createPoly', 'create', 'createPolyedra()', '');
	strPoly += createButton('createpoly', 'create auto',
			'setV("polyhedra 4,6 " + getValue("polyVert"))', '');
	strPoly += createButton('deletePoly', 'delete', 'setV("polyhedra DELETE")',
	'');
	strPoly += "</td></tr>\n";
	strPoly += "</table>\n";
	strPoly += "</FORM>\n";
	return strPoly;
}

///////////////////////////// create isosurfaceGroup

///introduce keypress onkeypress=\"setTimeout('
function createIsoGrp() {
	var isoName = new Array("no isosurface", "Van der Waals",
			"solvent accessible", "molecular", "MEP", "geodesic VdW", "geodesic IONIC",
			"dots VdW", "dots IONIC");
	var isoValue = new Array('load ""; isosurface OFF',
			'load ""; isosurface VDW'/*BH Q: Why was this 2.0? 2.0'*/, 
			'load ""; isosurface SASURFACE',
			'load ""; isosurface MOLSURFACE resolution 0 molecular',
			'load ""; isosurface resolution 7 SOLVENT map MEP',
			'load ""; geoSurface VANDERWAALS', 'load ""; geoSurface IONIC',
			'load "";  dots VANDERWAALS', 'load "";  dots IONIC');
	var colSchemeName = new Array("Rainbow (default)", "Black & White",
			"Blue-White-Red", "Red-Green", "Green-Blue");
	var colSchemeValue = new Array("roygb", "bw", "bwr", "low", "high");
	/*
	 * TODO slab unitcell. /
	 * http://chemapps.stolaf.edu/jmol/docs/examples-11/new.htm isosurface /
	 * lattice {a b c}
	 */
	var strIso = "<FORM id='isoGroup' name='isoGroup' style='display:none'>\n";
	strIso += "<table class='contents'>\n";
	strIso += "<tr><td colspan='2'>\n";
	strIso += "<h2>IsoSurface</h2>\n";
	strIso += "</td></tr>\n";
	strIso += "<tr><td colspan='2'>\n";
	strIso += "Molecular (classic) isoSurfaces: \n <br>";
	strIso += createList('isoCommon', 'setIsoClassic(this.value)', 0, 0,
			isoValue, isoName)
			+ "&nbsp;";
	strIso += createButton('removeIso', 'remove iso', 'setV("isosurface OFF")',
	'');
	strIso += createLine('blue', '');
	strIso += "</td></tr>\n";
	strIso += "<tr><td colspan='2'>\n";
	strIso += "Color map settings<br>\n ";
	strIso += "<img src='images/band.png'><br><br>";
	strIso += "- " + createText2("dataMin", "", "12", 0) + " + "
	+ createText2("dataMax", "", "12", 0) + " e- *bohr^-3<br>";
	strIso += "<br> Colour-scheme "
		+ createList('isoColorScheme', 'setIsoColorscheme()', 0, 0,
				colSchemeValue, colSchemeName) + "&nbsp<br>";
	strIso += createButton('up', 'Update map', 'setIsoColorRange()', '');
	// + createButton('reverseColor', 'Reverse colour', 'setIsoColorReverse()',
	// '');
	strIso += createLine('blue', '');
	strIso += "<td><tr>\n";
	// strIso+="Volume isoSurface<br>"
	// strIso+=createButton('volIso', 'calculate', 'setV('isosurface
	// VOLUME')', '') + " \n";
	// strIso+=createText3('isoVol','','','',"");
	// strIso+=createLine('blue' , '');
	// strIso+="</td></tr>\n";
	strIso += "<tr><td colspan='2'>\n";
	strIso += "Expand isoSurface periodically <br>";
	strIso += "<i>a: </i>";
	strIso += "<input type='text'  name='iso_a' id='iso_a' size='1' class='text'>";
	strIso += "<i> b: </i>";
	strIso += "<input type='text'  name='iso_b' id='iso_b' size='1' class='text'>";
	strIso += "<i> c: </i>";
	strIso += "<input type='text'  name='iso_c' id='iso_c' size='1' class='text'>";
	strIso += createButton('set_Isopack', 'packIso', 'setIsoPack()', '')
	+ " \n";
	strIso += createLine('blue', '');
	strIso += "</td></tr>\n";
	strIso += "<tr><td colspan='2'>\n";
	strIso += "Style isoSurface:<br>";
	strIso += "</td></tr>\n";
	strIso += "<tr><td colspan='2'>\n";
	strIso += createRadio("isofashion", "opaque",
			'setV("color isosurface opaque") ', 0, 1, "", "");
	strIso += createRadio("isofashion", "translucent",
			'setV("color isosurface translucent") ', 0, 0, "", "")
			+ "<br>";
	strIso += createRadio("isofashion", "dots", 'setV("isosurface  dots;") ',
			0, 0, "", "");
	strIso += createRadio("isofashion", "no-fill mesh",
			'setV("isosurface nofill mesh") ', 0, 0, "", "");
	strIso += "</td></tr>\n";
	strIso += "<tr><td>\n";
	strIso += "Color Isosurface:\n";
	strIso += "</td><td><script type='text/javascript'>\n";
	strIso += "var Colorscript = [setIsoColor, 'color'];";
	strIso += "jmolColorPickerBox(Colorscript, '');";
	strIso += "</script>";
	strIso += "</td></tr>";
	strIso += "<tr><td>\n";
	strIso += createLine('blue', '');
	strIso += createCheck("measureIso", "Measure value", "pickIsoValue()", 0,
			0, "measureIso")
			+ "\n";
	// strIso += "<input type='text' name='isoMeasure' id='isoMeasure' size='5'
	// class='text'> a.u.\n";
	strIso += "</td></tr>\n";
	strIso += "<tr><td colspan='2'>\n";
	strIso += createCheck("removeStr", "Show structure beneath",
			"removeStructure()", 0, 1, "")
			+ " \n";
	strIso += createCheck("removeCellI", "Show cell", "removeCellIso()", 0, 1,
	"")
	+ " \n";
	strIso += createLine('blue', '');
	strIso += "</td></tr>\n";
	strIso += "</table>\n";
	strIso += "</FORM>\n";
	return strIso;
}

///////////////////////////// create Geometry Grp
function createGeometryGrp() {
	var vecAnimValue = new Array("", "set animationFps 5",
			"set animationFps 10", "set animationFps 15",
			"set animationFps 20", "set animationFps 25",
			"set animationFps 30", "set animationFps 35");
	var vecAnimText = new Array("select", "5", "10", "15", "20", "25", "30",
	"35");
	var vecUnitEnergyVal = new Array("h", "e", "r", "kj", "kc");
	var vecUnitEnergyText = new Array("Hartree", "eV", "Rydberg", "kJ*mol-1",
	"kcal*mol-1");
	var strGeom = "<form id='geometryGroup' name='modelsGeom' style='display:none'>";
	strGeom += "<table class='contents'><tr><td>";
	strGeom += "<h2>Geometry optimiziation</h2>\n";
	strGeom += "</td></tr>"
		strGeom += "<tr><td>\n";
	strGeom += createButton("<<", "<<",
			'setV("model FIRST");  preselectMyItem("0")', 0)
			+ "\n";
	strGeom += createButton(">", ">", 'setV("animation ON")+ selectFrame()', 0)
	+ "\n";
	strGeom += createButton("||", "||", 'setV("frame PAUSE")', 0) + "\n";
	strGeom += createButton(">>", ">>", 'setV("model LAST")', 0) + "\n";
	strGeom += createButton(
			"loop",
			"loop",
			'setV("frame REWIND; animation off;animation mode loop;animation on")',
			0)
			+ "\n";
	strGeom += createButton(
			"palindrome",
			"palindrome",
			'setV("frame REWIND; animation off;  animation mode palindrome;animation on")',
			0)
			+ "\n";
	strGeom += "<br>"
		+ createList("framepersec", "setV(value)", 0, 1, vecAnimValue,
				vecAnimText) + " motion speed | ";
	strGeom += createCheck('saveFrames', ' save video frames', 'saveFrame()',
			0, 0, "");
	strGeom += "<br> Energy unit measure: ";
	strGeom += createList("unitMeasureEnergy", "convertPlot(value)", 0, 1,
			vecUnitEnergyVal, vecUnitEnergyText);
	strGeom += "</td></tr><tr><td>";
	strGeom += "<select id='geom' name='models' onchange='showFrame(value)'  class='selectmodels' size='10'></select>";
	strGeom += "</td></tr><tr><td style='margin=0px; padding=0px;'><div id='appletdiv' style='display:none'>\n";
	strGeom += createDiv("graphdiv",
	"width:180;height:180;background-color:#EFEFEF; margin-left:0px;display:none")
	+ "\n";
	strGeom += createDiv("plottitle", "display:none")
	+ "&#916E (kJ/mol)</div>\n";
	strGeom += createDiv("plotarea",
	"width:180px;height:180px;background-color:#EFEFEF; display:none")
	+ "</div>\n";
	strGeom += "<div id='appletdiv1' style='display:none'>\n";
	strGeom += createDiv("graphdiv1",
	"width:180;height:180;background-color:#EFEFEF; margin-left:0px;display:none")
	+ "\n";
	strGeom += createDiv("plottitle1", "display:none") + "ForceMax </div>\n";
	strGeom += createDiv("plotarea1",
	"width:180px;height:180px;background-color:#efefEF;display:none")
	+ "</div>\n";
	strGeom += "</div></div></div>\n";
	strGeom += "</table></form>\n";
	return strGeom;
}

///////////////////////////// create FREQUENCIES Grp
function createFreqGrp() {
	var vecscaleValue = new Array("", "vectors SCALE 1", "vectors SCALE 3",
			"vectors SCALE 5", "vectors SCALE 7", "vectors SCALE 10",
			"vectors SCALE 15", "vectors SCALE 19");
	var vecsizeValue = new Array("", "vectors 1", "vectors  3", "vectors  5",
			"vectors  7", "vectors 10", "vectors 15", "vectors  19");
	var vibAmplitudeValue = new Array("", "vibration Scale 1",
			"vibration Scale 2", "vibration Scale 5", "vibration Scale 7",
	"vibration Scale 10");
	var vecscaleText = new Array("select", "1", "3", "5", "7", "10", "15", "19");
	var vibAmplitudeText = new Array("select", "1", "2", "5", "7", "10");

	var strFreq = "<table class='contents'><tr><td valign='top'><form id='freqGroup' name='modelsVib' style='display:none'>";
	strFreq += "<h2>IR-Raman Frequencies</h2>\n";
	strFreq += "<select id='vib' name='models' OnClick='showFrame(value)' class='selectmodels' size=15 style='width:120px; overflow: auto;'></select>";
	strFreq += "<BR>\n";
	strFreq += createRadio("modAct", "All", "onClickModSelLoad()", 0, 1, "",
	"all");
	strFreq += createRadio("modAct", "IR", "onClickModSelLoad()", 0, 0, "",
	"ir");
	strFreq += createRadio("modAct", "Raman", "onClickModSelLoad()", 0, 0, "",
	"raman");
	strFreq += "<BR>\n";
	strFreq += "Symmetry <select id='sym' name='vibSym' onchange='onChangeListDesSymm(value)' onkeypress='onChangeListDesSymm()' CLASS='select' >";
	strFreq += "</select> ";
	// strFreq += createButton("reload", "Reload", "onClickReloadSymm()", 0);
	strFreq += "<BR>\n";
	strFreq += "vibration ";
	strFreq += createRadio("vibration", "on", 'onClickVibrate(value)', 0, 0,
			"", "on");
	strFreq += createRadio("vibration", "off", 'onClickVibrate(value)', 0, 1,
			"", "off");
	strFreq += "<BR>\n";
	strFreq += createList("vecsamplitude", "setV(value)", 0, 1,
			vibAmplitudeValue, vibAmplitudeText)
			+ " vib. amplitude";
	strFreq += "<BR>\n";
	strFreq += createCheck("vectors", "view vectors",
			"setVCheckbox(this, this.value)", 0, 1, "vectors");
	strFreq += "<BR>\n";
	strFreq += createList("vecscale", "setV(value)", 0, 1, vecscaleValue,
			vecscaleText)
			+ " vector scale";
	strFreq += "<BR>\n";
	strFreq += createList("sizevec", "setV(value)", 0, 1, vecsizeValue,
			vecscaleText)
			+ " vector size";
	strFreq += "<BR>\n";
	strFreq += "<table class='contents'> <tr><td>vector color</td> <td><script type='text/javascript'>jmolColorPickerBox('color vectors $COLOR$',[255,255,255])</script></td>";
	strFreq += "</tr><tr><td>"
		+ createButton("vibVectcolor", "Default color",
				'setV("color vectors none")', 0) + "</td></tr></table>";
	strFreq += "</td><td valign='top'><div id='freqdiv' style='display:none'>\n";
	strFreq += createDiv("graphfreqdiv",
	"width:200;height:200;background-color:#EFEFEF; margin-left:5px; display:none")
	+ "\n";
	strFreq += createDiv("plottitlefreq", ";display:none")
	+ "IR - Raman  dispersion </div>\n";
	strFreq += createDiv("plotareafreq",
	"width:210;height:210px;background-color:#EFEFEF;display:none")
	+ "</div>\n";
	strFreq += "Raman intensities set to 0.0 kmMol<sup>-1</sup>";
	strFreq += "<br>\n";
	strFreq += createLine('blue', '');
	strFreq += "Simulate spectrum<br>";
	strFreq += createRadio("kindspectra", "IR", '', 0, 1, "", "ir");
	strFreq += createRadio("kindspectra", "Raman", '', 0, 1, "", "raman");
	strFreq += createRadio("kindspectra", "Both", '', 0, 1, "", "both");
	strFreq += "<br>Convolution with<br>";
	strFreq += createRadio("convol", "Stick", '', 0, 1, "", "stick");
	strFreq += createRadio("convol", "Gaussian", '', 0, 0, "", "gaus");
	strFreq += createRadio("convol", "Lorentzian", '', 0, 0, "", "lor");
	strFreq += "<br>Specrum setting <br>\n";
	strFreq += "band width " + createText2("sigma", "15", "3", "")
	+ " (cm<sup>-1</sup>)<br>";
	strFreq += "Min freq. " + createText2("nMin", "", "4", "");
	strFreq += " Max " + createText2("nMax", "", "4", "")
	+ "(cm<sup>-1</sup>)<br>";
	strFreq += createButton("simSpectra", "Simulate spectrum", "simSpectrum()",
			0)
			+ " ";
	strFreq += createCheck("rescaleSpectra", "Re-scale", "", 0, 1, "");
	strFreq += "</div></div>\n";
	strFreq += "</form></td></tr></table>";

	return strFreq;
}

///////////////////////////// electprop
function createElecpropGrp() {

	var colSchemeName = new Array("Rainbow (default)", "Black & White",
			"Blue-White-Red", "Red-Green", "Green-Blue");
	var colSchemeValue = new Array('roygb', 'bw', 'bwr', 'low', 'high');
	var strElec = "<form id='elecGroup' name='elecGroup' style='display:none'>\n";
	strElec += "<table class='contents'><tr><td ><h2>Electronic - Magnetic properties</h2> \n";
	strElec += "</td></tr>\n";
	strElec += "<tr><td>\n";
	strElec += "Mulliken population analysis\n <br>";
	strElec += createButton("mulliken", "view Mulliken",
			'setV("script scripts/mulliken.spt")', 0);
	strElec += "<br> Colour-scheme "
		+ createList('chergeColorScheme', 'setColorMulliken(value)', 0, 0,
				colSchemeValue, colSchemeName)
				+ "&nbsp<br>";
	strElec += "</td></tr>\n";
	strElec += "<tr><td>\n";
	strElec += "Spin arrangment\n <br>";
	strElec += createButton("spin", "view Spin",
			'setV("script scripts/spin.spt")', 0);
	strElec += " ";
	strElec += createButton("magnetiMoment", "view Magnetic Moment",
			'runJmolScript("script scripts/spin.spt")', 0);
	strElec += "<br> View only atoms with spin "
		+ createButton("spindown", "&#8595",
				'setV("display property_spin <= 0")', 0);
	strElec += createButton("spinup", "&#8593",
			'setV("display property_spin >= 0")', 0);
	// strElec+=createButton("magneticMoment","magn. Moment",'',0);
	strElec += "</td></tr>\n";
	strElec += "<tr><td>\n";
	strElec += createLine('blue', '');
	strElec += createButton("Removeall", "Remove", 'exitElecpropGrp()', 0);
	strElec += "</td></tr>\n";
	strElec += "<tr><td>\n";
	strElec += createLine('blue', '');
	strElec += "</td></tr>\n";
	strElec += "</table></form> \n";
	return strElec;
}

///////////////////////////// create other properties
function createotherpropGroup() {
	var textValue = new Array("0", "6", "8", "10", "12", "16", "20", "24", "30");
	var textText = new Array("select", "6 pt", "8 pt", "10 pt", "12 pt",
			"16 pt", "20 pt", "24 pt", "30 pt");

	var shadeName = new Array("select", "1", "2", "3")
	var shadeValue = new Array("0", "1", "2", "3")
	var strOther = "<form id='otherpropGroup' name='otherpropGroup' style='display:none' >";
	strOther += "<table class='contents'><tr><td> \n";
	strOther += "<h2>Other properties</h2></td></tr>\n";
	strOther += "<tr><td>Background colour:</td>\n";
	strOther += "<td align='left'><script type='text/javascript'>jmolColorPickerBox('set background $COLOR$',[255,255,255])</script></td></tr> \n";
	strOther += "<tr><td>"
		+ createLine('blue', '')
		+ createCheck(
				"perspective",
				"Perspective",
				'setVCheckbox(this, this.value) + toggleDiv(this,"perspectiveDiv") +initPerspective()',
				0, 0, "set perspectiveDepth");
	strOther += "</td></tr><tr><td>"
		strOther += "<div id='perspectiveDiv' style='display:none; margin-top:20px'>";
	strOther += '<div tabIndex="1" class="slider" id="persSlider-div" style="float:left;width:150px;" >';
	strOther += '<input class="slider-input" id="persSlider-input" name="persSlider-input" />';
	strOther += '</div><div id="perspMsg" class="msgSlider"></div></div>';
	strOther += "</td></tr>\n";
	strOther += "<tr><td>"
		+ createCheck("z-shade", "Z-Fog", "setVCheckbox(this, this.value)",
				0, 0, "set zShade");
	strOther += " ";
	strOther += createList(
			'setzShadePower ',
			'setV("set zShade; set zShadePower " + value + " ;") + setVCheckbox("z-shade","")',
			0, 1, shadeValue, shadeName)
			+ " Fog level";
	strOther += "</td></tr>\n";
	strOther += "<tr><td colspan='2'> Anti-aliasing"
		+ createRadio("aa", "on",
				'setV("antialiasDisplay = true; set hermiteLevel 5")', 0,
				0, "");
	strOther += createRadio("aa", "off",
			'setV("antialiasDisplay = false;set hermiteLevel 0")', 0, 1, "");
	strOther += createLine('blue', '');
	strOther += "</td></tr>";
	strOther += "<tr><td>";
	strOther += "Light settings";
	strOther += "</td></tr>";
	strOther += "<tr><td>";
	strOther += '<div tabIndex="1" class="slider" id="light1Slider-div" style="float:left;width:150px;" >';
	strOther += '<input class="slider-input" id="light1Slider-input" name="light1Slider-input" />';
	strOther += '</div>Reflection	<div id="light1Msg" class="msgSlider"></div></div>';
	strOther += "</td></tr><tr><td>";
	strOther += '<div tabIndex="1" class="slider" id="light2Slider-div" style="float:left;width:150px;" >';
	strOther += '<input class="slider-input" id="light2Slider-input" name="light2Slider-input" />';
	strOther += '</div>Ambient	<div id="light2Msg" class="msgSlider"></div></div>';
	strOther += "</td></tr><tr><td>";
	strOther += '<div tabIndex="1" class="slider" id="light3Slider-div" style="float:left;width:150px;" >';
	strOther += '<input class="slider-input" id="light3Slider-input" name="light3Slider-input" />';
	strOther += '</div>Diffuse	<div id="light3Msg" class="msgSlider"></div></div>';
	strOther += "</td></tr><tr><td colspan='2'>" + createLine('blue', '');
	strOther += "</tr><tr><td colspan='2'>"
		strOther += "3D settings <br>"
			+ createRadio("stereo", "R&B", 'setV("stereo REDBLUE")', 0, 0, "")
			+ "\n";
	strOther += createRadio("stereo", "R&C", 'setV("stereo REDCYAN")', 0, 0, "")
	+ "\n";
	strOther += createRadio("stereo", "R&G", 'setV("stereo REDGREEN")', 0, 0,
	"")
	+ "<br>\n";
	strOther += createRadio("stereo", "side-by-side", 'setV("stereo ON")', 0,
			0, "")
			+ "\n";
	strOther += createRadio("stereo", "3D off", 'setV("stereo off")', 0, 1, "")
	+ createLine('blue', '') + "</td></tr>\n";
	strOther += "<tr><td colspan='2'>";
	strOther += "Label controls <br>"
		strOther += createCheck("frameName", "Name model", "setNameModel(this)", 0,
				1, "frame title")
				+ " ";
	strOther += createCheck("jmollogo", "Jmol Logo",
			"setVCheckbox(this, this.value)", 0, 1, "set showFrank")
			+ "</td></tr>\n";
	strOther += "<tr><td colspan='2'>";
	strOther += "Font size ";
	strOther += createList("fontSize", "setTextSize(value)", 0, 1,
			textValue, textText);
	strOther += "</td></tr>";
	strOther += "<tr><td colspan='2'>"
		+ createButton("removeText", "Remove messages", 'setV("echo")', 0);
	strOther += createLine('blue', '');
	strOther += "</td></tr></table></FORM>  \n";
	return strOther;
}

///////////////////////////// create Hystory Grp var scriptColor = "'color iron
//$COLOR$'";

function createHistGrp() {
	var strHist = "<FORM id='HistoryGroup' name='HistoryGroup' style='display:none'>";
	strHist += "History<BR>\n";
	strHist += "Work in progress<BR>\n";
	strHist += "</form>";
	return strHist;
}

//////////////LOADING MENUS
function loadTabs() {
	document.write(createMenus());
}

function loadMenus() {
	document.write(createFileGrp());
	document.write(createAppearanceGrp());
	document.write(createEditGroup());
	//document.write(createBuildGroup());
	document.write(createMeasureGroup());
	document.write(createOrientGrp());
	document.write(createCellGrp());
	document.write(createPolyGrp());
	document.write(createIsoGrp());
	document.write(createGeometryGrp());
	document.write(createFreqGrp());
	document.write(createElecpropGrp());
	document.write(createotherpropGroup());
	// document.write(createHistGrp());
}
      		
///js// Js/tabs.js /////
/*  J-ICE library 

 based on:
 *
 * Copyright (C) 2010-2014 Pieremanuele Canepa http://j-ice.sourceforge.net/
 *
 * ** Contact: pierocanepa@sourceforge.net
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA
 *  02111-1307  USA.
 */

//tabmenus.js includes older tabs.js and menu.js
//last modified 16th Mar 2011 
///////////////////////////////// menu object definition
function Menu(name, grp, link) {
	this.name = name;
	this.grp = grp;
	this.link = link;
}

var tabMenu = [];

function addTab(name, group, link) {
	tabMenu.push(new Menu(name, group, link));
}

//Common variables
function defineMenu() {
	addTab("File", "fileGroup", "Import, Export files.");
	addTab("Show", "apparenceGroup",
	"Change atom, bond colours, and dimensions.");
	addTab("Edit", "editGroup", "Change connectivity and remove atoms.");
	//addTab("Build", "builGroup", "Modify and optimize structure.");
	addTab("Measure", "measureGroup",
	"Measure bond distances, angles, and torsionals.");
	addTab("Orient", "orientGroup", "Change orientation and views.");
	addTab("Cell", "cellGroup", "Modify cell features and symmetry.");
	addTab("Poly", "polyGroup", "Create polyhedra.");
	addTab("Surf.", "isoGroup", "Modify and create isosurface maps.");
	addTab("Optimize", "geometryGroup", "Geometry optimizations.");
	addTab("Spectra", "freqGroup", "IR/Raman frequencies and spectra.");
	addTab("E&M", "elecGroup", "Mulliken charges, spin, and magnetic moments.");
	addTab("Main", "otherpropGroup",
	"Change background, light settings and other.");
}

/////////////////////////////////////// Menu functions

//////////////LOADING MENUS

function getButtons() {
	return "<br>"
	+ createText('filename', '', 108, null, null, "textwhite", "disab")
	+ "<br>"
	+ createButton(
			"reload",
			"Reload",
			'runJmolScript("script ./scripts/reload.spt") + resetAll() + setName()',
			null, "specialbutton")
			+ createButton("reset", "Reset",
					'runJmolScript("script ./scripts/reset.spt")', null,
			"specialbutton")
			+ createButton("Console", "Console", 'runJmolScript("console")', null,
			"specialbutton")
			+ createButton("NewWindow", "New window", "newAppletWindow()")
			+ createButton("viewfile", "File content", "printFileContent()")
			+ createButton("saveState", 'Save state', 'saveCurrentState()',
					null, "savebutton")
					+ createButton("restoreState", 'Restore state',
							'reloadCurrentState()', null, "savebutton")
							+ createButton("Feedback", 'Feedback', 'newAppletWindowFeed()');
}

function getMenus() {
	return createFileGrp() + createAppearanceGrp() + createEditGroup()
	+ createBuildGroup() + createMeasureGroup() + createOrientGrp()
	+ createCellGrp() + createPolyGrp() + createIsoGrp()
	+ createGeometryGrp() + createFreqGrp() + createElecpropGrp()
	+ createotherpropGroup();
	// + createHistGrp();
}

function createMenus() {

	// strMenu = "<TABLE style='border-collapse: collapse;'><TR>";
	var strMenu = "<ul class='menu' id='menu'>";
	for ( var menuIndex = 0; menuIndex < tabMenu.length; menuIndex++) {
		strMenu += createMenuCell(menuIndex);
	}
	strMenu += "</ul>";
	// strMenu += "</TR></TABLE>";

	return strMenu;
}

var tabTimeouts = [];
var tabDelayMS = 1000;
var grpDispDelayed = function(n, isClick) {
	for (var i = tabTimeouts.length; --i >= 0;) {
		if (tabTimeouts[i])
			clearTimeout(tabTimeouts[i]);
		tabTimeouts = [];
	}	
	switch(isClick) {
	case 1:
		grpDisp(n);	
		break;
	case 2:
		return;
	default:
		tabTimeouts[n] = setTimeout(function(){grpDispDelayed(n,1)},tabDelayMS);
	}
}

function createMenuCell(i) {

	var sTab = "<li id='menu'+ i +' "; // Space is mandatory between i and "
	sTab += "onClick='grpDispDelayed(" + i + ",1)' onmouseover='grpDispDelayed("+i+",0)' onmouseout='grpDispDelayed("+i+",2)'"; // BH 2018
	sTab += "class = 'menu' ";
	sTab += ">";
	sTab += "<a class = 'menu'>";
	sTab += tabMenu[i].name;
	sTab += "<span>" + tabMenu[i].link + "</span>"
	sTab += "</a></li>"
		// sTab += "</TD>";
		return sTab;
}

/*
 * function menuIn(i){ var str = 'menu' + i ; var id= getbyID(str); id.class =
 * 'menuIn'; }
 * 
 * function menuOut(i){ var str = 'menu' + i; id.class = 'menuOut'; }
 */

function toggleElement(disp, me, index) {
	if (disp == 1) {
		getbyID(me).style.display = "inline";
	} else {
		getbyID(me).style.display = "none";
	}
}

function toggleSlab() {
	var ctl = getbyID("slabToggle")
	if (ctl.checked) {
		runJmolScript("spin off; slab on; slab 80;");
		slabSlider.setValue(20);
		applySlab(defaultFront);
		depthSlider.setValue(defaultBack);
		applyDepth(defaultBack);
	} else {
		runJmolScript("slab off; ")
		slabSlider.setValue(0);
		depthSlider.setValue(0);
	}
}

function grpDisp(i) {
	for ( var j = 0; j < tabMenu.length; j++) {
		if (j == i) {
			toggleElement(1, tabMenu[j].grp, i);
			tabMenu[j].disp = 1;
			showDiv(i);
		} else {
			toggleElement(0, tabMenu[j].grp, i);
			tabMenu[j].disp = 0;
		}
	}
	/*
	 * if (tabMenu[i].picking) { runJmolScript("set picking on;") } else {
	 * runJmolScript("set picking off;") }
	 */
}

var widget = null;

function showDiv(index) {
	var arrayGeomgrp = new Array("appletdiv", "graphdiv", "plottitle",
			"plotarea", "appletdiv1", "graphdiv1", "plottitle1", "plotarea1");
	var freqArrGr = new Array("freqdiv", "graphfreqdiv", "plottitlefreq",
	"plotareafreq");

	switch (index) {
	case 0:
		resetviewTab();
		widget = true;
		for ( var i = 0; i < arrayGeomgrp.length; i++)
			getbyID(arrayGeomgrp[i]).style.display = "none";
		for ( var j = 0; j < freqArrGr.length; j++)
			getbyID(freqArrGr[j]).style.display = "none";
		exitFreqGroup();
		break;
	case 1:
		resetviewTab();
		widget = true;
		enterAppreance();
		enterTab();
		for ( var i = 0; i < arrayGeomgrp.length; i++)
			getbyID(arrayGeomgrp[i]).style.display = "none";
		for ( var j = 0; j < freqArrGr.length; j++)
			getbyID(freqArrGr[j]).style.display = "none";
		exitIsosurface();
		exitFreqGroup();
		resetSymmetryView();
		break;
	case 2:
		resetviewTab();
		widget = true;
		enterEdit();
		enterTab();
		for ( var i = 0; i < arrayGeomgrp.length; i++)
			getbyID(arrayGeomgrp[i]).style.display = "none";
		for ( var j = 0; j < freqArrGr.length; j++)
			getbyID(freqArrGr[j]).style.display = "none";
		exitIsosurface();
		exitFreqGroup();
		resetSymmetryView();
		break;
/*	case 3: // Build
		resetviewTab();
		widget = true;
		enterTab();
		// removeDiv();
		for ( var i = 0; i < arrayGeomgrp.length; i++)
			getbyID(arrayGeomgrp[i]).style.display = "none";
		for ( var j = 0; j < freqArrGr.length; j++)
			getbyID(freqArrGr[j]).style.display = "none";
		exitIsosurface();
		exitFreqGroup();
		resetSymmetryView();
		break;*/
	case 3:
		resetviewTab();
		widget = true;
		enterTab();
		// removeDiv();
		for ( var i = 0; i < arrayGeomgrp.length; i++)
			getbyID(arrayGeomgrp[i]).style.display = "none";
		for ( var j = 0; j < freqArrGr.length; j++)
			getbyID(freqArrGr[j]).style.display = "none";
		exitIsosurface();
		exitFreqGroup();
		resetSymmetryView();
		break;
	case 4:
		widget = true;
		resetviewTab();
		for ( var i = 0; i < arrayGeomgrp.length; i++)
			getbyID(arrayGeomgrp[i]).style.display = "none";
		for ( var j = 0; j < freqArrGr.length; j++)
			getbyID(freqArrGr[j]).style.display = "none";
		// exitIsosurface();
		exitFreqGroup();
		resetSymmetryView();
		break;
	case 5:
		widget = true;
		resetviewTab();
		enterTab();
		for ( var i = 0; i < arrayGeomgrp.length; i++)
			getbyID(arrayGeomgrp[i]).style.display = "none";
		for ( var j = 0; j < freqArrGr.length; j++)
			getbyID(freqArrGr[j]).style.display = "none";

		exitIsosurface();
		exitFreqGroup();
		resetSymmetryView();
		getUnitcell(frameValue);
		getSymInfo();
		break;
	case 6:
		widget = true;
		resetviewTab();
		enterTab();
		for ( var i = 0; i < arrayGeomgrp.length; i++)
			getbyID(arrayGeomgrp[i]).style.display = "none";
		for ( var j = 0; j < freqArrGr.length; j++)
			getbyID(freqArrGr[j]).style.display = "none";
		exitIsosurface();
		exitFreqGroup();
		resetSymmetryView();
		break;
		// isosurface group
	case 7:
		widget = false;
		resetviewTab();
		// removeDiv();
		for ( var i = 0; i < arrayGeomgrp.length; i++)
			getbyID(arrayGeomgrp[i]).style.display = "none";
		for ( var j = 0; j < freqArrGr.length; j++)
			getbyID(freqArrGr[j]).style.display = "none";
		resetSymmetryView();
		break;
		// Geometry group
	case 8:
		widget = false;
		resetviewTab();
		resetSymmetryView();
		for ( var j = 0; j < freqArrGr.length; j++)
			getbyID(freqArrGr[j]).style.display = "none";
		for ( var i = 0; i < arrayGeomgrp.length; i++)
			getbyID(arrayGeomgrp[i]).style.display = "block";
		exitIsosurface();
		exitFreqGroup();
		// if(flagCryVasp)
		refresh();
		break;
		// Freq group
	case 9:
		widget = true;
		resetviewTab();
		resetSymmetryView();
		for ( var i = 0; i < arrayGeomgrp.length; i++)
			getbyID(arrayGeomgrp[i]).style.display = "none";
		for ( var j = 0; j < freqArrGr.length; j++)
			getbyID(freqArrGr[j]).style.display = "block";
		exitIsosurface();
		refreshFreq();
		break;
	case 10:
		widget = true;
		resetviewTab();
		for ( var i = 0; i < arrayGeomgrp.length; i++)
			getbyID(arrayGeomgrp[i]).style.display = "none";
		for ( var j = 0; j < freqArrGr.length; j++)
			getbyID(freqArrGr[j]).style.display = "none";
		exitIsosurface();
		exitFreqGroup();
		resetSymmetryView();
		break;
		// / Mulliken and spin
	case 11:

		widget = true;
		resetviewTab();
		for ( var i = 0; i < arrayGeomgrp.length; i++)
			getbyID(arrayGeomgrp[i]).style.display = "none";
		for ( var j = 0; j < freqArrGr.length; j++)
			getbyID(freqArrGr[j]).style.display = "none";
		saveOrientation();
		exitIsosurface();
		exitFreqGroup();
		resetSymmetryView();
		break;
	case 12:
		resetviewTab();
		widget = true;
		enterOther();
		for ( var i = 0; i < arrayGeomgrp.length; i++)
			getbyID(arrayGeomgrp[i]).style.display = "none";
		for ( var j = 0; j < freqArrGr.length; j++)
			getbyID(freqArrGr[j]).style.display = "none";
		exitIsosurface();
		exitFreqGroup();

		break;
	}

}
var firstTimeBond = true;
function enterAppreance() {
	if (firstTimeBond) {
		bondSlider.setValue(20);
		radiiSlider.setValue(22);
		getbyID('radiiMsg').innerHTML = 20 + " %";
		getbyID('bondMsg').innerHTML = 0.20 + " &#197";
	}
	firstTimeBond = false;
}

function enterOther() {
	light1Slider.setValue(50);
	light2Slider.setValue(50);
	light3Slider.setValue(50);
	getbyID("light1Msg").innerHTML = 40 + " %";
	getbyID("light2Msg").innerHTML = 40 + " %";
	getbyID("light3Msg").innerHTML = 40 + " %";

}

var firstTime = true;
function enterEdit() {
	if (firstTime) {
		radiiConnect.setValue(50);
		setV("set forceAutoBond ON; set bondMode AND");
	}
	getbyID("radiiConnectMsg").innerHTML = " " + 2.5 + " &#197";
	setTimeout("setV(\"restore BONDS bondEdit\");", 400);
	firstTime = false;
}

function resetviewTab() {
	setV('select all; label off; halos off');
	setV('showSelections FALSE; select none; set picking OFF; halos off; set LABEL off;');
	measureCoord = false;
}
      		
///js// Js/plotgraph.js /////
/* J-ICE 0.1 script library Piero Canepa 

    based on: http://chemapps.stolaf.edu/jmol/docs/examples-11/flot/ Bob Hanson
 *
 * Copyright (C) 2010-2014  Pieremanuele Canepa http://j-ice.sourceforge.net/
 *
 * Contact: pc229@kent.ac.uk
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA
 *  02111-1307  USA.
 */



var appletPrintable = (navigator.appName != "Netscape"); // Sorry, I don't
//know how to check
//for this

//This has changed
function $() {
	// document ready function
	if (!appletPrintable)$("#appletdiv").addClass("noprint"); 
}


var itemEnergy
var previousPoint = null
var itemForce
var previousPointForce = null
var itemFreq
var previousPointFreq = null


var theplot ; // global, mostly for testing.

function plotEnergies( a, b, c, d){

	// setImage()
	var data = [];
	var A = [];
	var nplots = 1;
	var modelCount = Info.length;
	var stringa = Info[3].name;
	var energy ="";
	var label = "";
	

	if(flagCryVasp  && !flagOutcar && !flagGauss && !flagQuantum && !flagGulp && !flagDmol  && !flagCast){
		// alert("crystal");
		if(stringa.search(/Energy/i) != -1){
			for (var i = 0; i < (modelCount - 1) ; i++) {
				var modelnumber = 0+ Info[i].modelNumber;
				// This is to check wheather we are dealing with an
				// optimization or a
				// frequency calculation
				var last = modelCount - 1;

				if(i > 0 && i < Info.length)
					var previous = i - 1 ;

				if((i == 0 && Info[i].name != null) ||
						(i > 0 && Info[i - 1].name == null &&  Info[i].name != null)){
					energy = (substringEnergyToFloat(Info[i].name) - substringEnergyToFloat(Info[last].name)) ;
					if (energy < 0) energy = +- energy;
				}
				if((Info[i].name != null) && (previous > 0) ){
					if (substringEnergyToFloat(Info[i].name) != substringEnergyToFloat(Info[i - 1].name))
						energy = (substringEnergyToFloat(Info[i-1].name) - substringEnergyToFloat(Info[i].name));
					if (energy < 0) energy = +- energy;			
				}

				label = 'Model = ' + modelnumber
				+ ', &#916 E = ' + energy + ' kJmol^-1';
				A.push([i+1,energy,modelnumber,label]);
			}
		}
		
		
	}else if (flagDmol && !flagCryVasp  && !flagOutcar && !flagGauss && !flagQuantum && !flagGulp  && !flagCast){ //Dmol
		// alert("crystal");
		if(stringa.search(/E/i) != -1){
			for (var i = 0; i < (modelCount - 1) ; i++) {
				var modelnumber = 0 + Info[i].modelNumber;
				// This is to check wheather we are dealing with an
				// optimization or a
				// frequency calculation
				var last = modelCount - 1;

				if(i > 0 && i < Info.length)
					var previous = i - 1 ;

				if((i == 0 && Info[i].name != null) ||
						(i > 0 && Info[i - 1].name == null &&  Info[i].name != null)){
					energy = (substringEnergyToFloat(Info[i].name) - substringEnergyToFloat(Info[last].name)) ;
					if (energy < 0) energy = +- energy;
				}
				if((Info[i].name != null) && (previous > 0) ){
					if (substringEnergyToFloat(Info[i].name) != substringEnergyToFloat(Info[i - 1].name))
						energy = (substringEnergyToFloat(Info[i-1].name) - substringEnergyToFloat(Info[i].name));
					if (energy < 0) energy = +- energy;			
				}

				label = 'Model = ' + modelnumber
				+ ', &#916 E = ' + energy + ' kJmol^-1';
				A.push([i+1,energy,modelnumber,label]);
			}
		}
	} else if (!flagCryVasp && !flagOutcar && !flagGauss && !flagQuantum && !flagGulp && !flagDmol  && !flagCast){ // VASP XML
		// alert("vasp r");
		for (var i = 0; i < (modelCount - 1) ; i++) {

			var modelnumber = 0 + Info[i].modelNumber;
			var last = modelCount - 1;
			if(i > 0 && i < Info.length)
				var previous = i - 1 ;
			if((i == 0 && Info[i].name != null) ||
					(i > 0 && Info[i - 1].name == null &&  Info[i].name != null)){
				energy = (substringEnergyVaspToFloat(Info[i].name) - substringEnergyVaspToFloat(Info[last].name)) ;
				if (energy < 0) energy = +- energy;
			}
			if((Info[i].name != null) && (previous > 0) ){
				if (substringEnergyVaspToFloat(Info[i].name) != substringEnergyVaspToFloat(Info[i - 1].name))
					energy = (substringEnergyVaspToFloat(Info[i-1].name) - substringEnergyVaspToFloat(Info[i].name));
				if (energy < 0) energy = +- energy;			
			}

			label = 'Model = ' + modelnumber
			+ ', &#916 E = ' + energy + ' kJmol^-1';
			A.push([i+1,energy,modelnumber,label]);
		}
	}else if (!flagCryVasp && flagOutcar && !flagGauss && !flagQuantum && !flagGulp && !flagDmol  && !flagCast){ // VASP OUTCAR
		// loader
		for (var i = 0; i < (modelCount - 1) ; i++) {
			var line = Info[i].name;
			if(line != null){
				if(line.search(/G =/i) != -1){
					var modelnumber = 0 + Info[i].modelNumber;
					var last = modelCount - 1;
					if(Info[i].name.search(/cm/i) == -1){
						if(i > 0 && i < Info.length)
							var previous = i - 1 ;
						if((i == 0 && Info[i].name != null) ||
								(i > 0 && Info[i - 1].name == null &&  Info[i].name != null)){
							energy = (substringEnergyVaspToFloat(Info[i].name) - substringEnergyVaspToFloat(Info[last].name)) ;
							if (energy < 0) energy = +- energy;
						}
						if((Info[i].name != null) && (previous > 0) ){
							if (substringEnergyVaspToFloat(Info[i].name) != substringEnergyVaspToFloat(Info[i - 1].name))
								energy = (substringEnergyVaspToFloat(Info[i-1].name) - substringEnergyVaspToFloat(Info[i].name));
							if (energy < 0) energy = +- energy;			
						}
					}

					label = 'Model = ' + modelnumber
					+ ', &#916 E = ' + energy + ' kJmol^-1';
					A.push([i+1,energy,modelnumber,label]);
				}
			}
		}
		
	}else if (!flagCryVasp && !flagOutcar && !flagGauss && flagQuantum && !flagGulp && !flagDmol  && !flagCast){ 
		//QuantumEspresso
		//alert("Quantum");
		for (var i = 0; i < (modelCount - 1) ; i++) {
			var line = Info[i].name;
			if(line != null){
				if(line.search(/E =/i) != -1){
					var modelnumber = 0 + Info[i].modelNumber;
					var last = modelCount - 1;
					if(Info[i].name.search(/cm/i) == -1){
						if(i > 0 && i < Info.length)
							var previous = i - 1 ;
						if((i == 0 && Info[i].name != null) ||
								(i > 0 && Info[i - 1].name == null &&  Info[i].name != null)){
							energy = (substringEnergyQuantumToFloat(Info[i].name) - substringEnergyQuantumToFloat(Info[last].name)) ;
							if (energy < 0) energy = +- energy;
						}
						if((Info[i].name != null) && (previous > 0) ){
							if (substringEnergyQuantumToFloat(Info[i].name) != substringEnergyQuantumToFloat(Info[i - 1].name))
								energy = (substringEnergyQuantumToFloat(Info[i-1].name) - substringEnergyQuantumToFloat(Info[i].name));
							if (energy < 0) energy = +- energy;			
						}
					}
					

					label = 'Model = ' + modelnumber
					+ ', &#916 E = ' + energy + ' kJmol^-1';
					A.push([i+1,energy,modelnumber,label]);
				}
			}
		}
		
	}else if (!flagCryVasp && !flagOutcar && !flagGauss && !flagQuantum && flagGulp && !flagDmol  && !flagCast){ //Gulp
		//alert("Gulp");
		for (var i = 0; i < (modelCount - 1) ; i++) {
			var line = Info[i].name;
			if(line != null){
				if(line.search(/E =/i) != -1){
					var modelnumber = 0 + Info[i].modelNumber;
					var last = modelCount - 1;
					if(Info[i].name.search(/cm/i) == -1){
						if(i > 0 && i < Info.length)
							var previous = i - 1 ;
						if((i == 0 && Info[i].name != null) ||
								(i > 0 && Info[i - 1].name == null &&  Info[i].name != null)){
							energy = (substringEnergyGulpToFloat(Info[i].name) - substringEnergyGulpToFloat(Info[last].name)) ;
							if (energy < 0) energy = +- energy;
						}
						if((Info[i].name != null) && (previous > 0) ){
							if (substringEnergyGulpToFloat(Info[i].name) != substringEnergyGulpToFloat(Info[i - 1].name))
								energy = (substringEnergyGulpToFloat(Info[i-1].name) - substringEnergyGulpToFloat(Info[i].name));
							if (energy < 0) energy = +- energy;			
						}
					}
					

					label = 'Model = ' + modelnumber
					+ ', &#916 E = ' + energy + ' kJmol^-1';
					A.push([i+1,energy,modelnumber,label]);
				}
			}
		}
	}else if (!flagCryVasp && !flagOutcar && flagGauss && !flagQuantum && !flagGulp && !flagDmol && !flagCast){ //GAussian

		for (var i = 1; i < energyGauss.length; i++) {

			var line = energyGauss[i];
			if(line != null){
				// alert(fromHartreetokJ(energyGauss[i]) + " " + i)

				var modelnumber = energyGauss.length -1;
				var last = energyGauss.length;

				if(i > 0 && i < Info.length)
					var previous = i - 1 ;
				if((i == 0 && energyGauss[i] != null) ||
						(i > 0 && energyGauss[i - 1] == null &&  energyGauss[i] != null)){
					energy = (fromHartreetokJ(energyGauss[i]) - fromHartreetokJ(energyGauss[last])) ;
					if (energy < 0) energy = +- energy;
				}
				if((energyGauss[i] != null) && (previous > 0) ){
					if (fromHartreetokJ(energyGauss[i]) != fromHartreetokJ(energyGauss[i - 1]))
						energy = (fromHartreetokJ(energyGauss[i-1]) - fromHartreetokJ(energyGauss[i]));
					if (energy < 0) energy = +- energy;			
				}
			}

			label = 'Model = ' + modelnumber
			+ ', &#916 E = ' + energy + ' kJmol^-1';
			A.push([i+1,energy,modelnumber,label]);
		}

	} /*else if ( !flagCast && !flagCryVasp && !flagOutcar && !flagGauss && !flagQuantum && !flagGulp && !flagDmol){
		// castep output
		//alert("Castep");
		for (var i = 0; i < (modelCount - 1) ; i++) {
			var line = Info[i].name;
			if(line != null){
				if(line.search(/Energy/i) != -1){
					var modelnumber = 0 + Info[i].modelNumber;
					var last = modelCount - 1;
					if(Info[i].name.search(/cm/i) == -1){
						if(i > 0 && i < Info.length)
							var previous = i - 1 ;
						if((i == 0 && Info[i].name != null) ||
								(i > 0 && Info[i - 1].name == null &&  Info[i].name != null)){
							energy = (substringEnergyCastepToFloat(Info[i].name) - substringEnergyCastepToFloat(Info[i].name)) ;
							alert(energy + "test1")
							if (energy < 0) energy = +- energy;
						}
						if((Info[i].name != null) && (previous > 0) ){
							if (substringEnergyCastepToFloat(Info[i].name) != substringEnergyCastepToFloat(Info[i - 1].name))
								energy = (substringEnergyCastepToFloat(Info[i-1].name) - substringEnergyCastepToFloat(Info[i].name));
							if (energy < 0) energy = +- energy;
							//alert( Info[i].name)
							alert(energy + "test2")
						}
					}
					

					label = 'Model = ' + modelnumber
					+ ', &#916 E = ' + energy + ' kJ/mol';
					A.push([i+1,energy,modelnumber,label]);
				}
			}
	
	}
	}*/





	data.push(A)
	var options = {
		lines: { show: true },
		points: {show: true, fill: true},
		xaxis: { ticks: 8, tickDecimals: 0 },
		yaxis: { ticks: 6,tickDecimals: 1 },
		selection: { mode: (nplots == 1 ? "x" : "xy"), hoverMode: (nplots == 1 ? "x" : "xy") },
		grid: { hoverable: true, clickable: true, hoverDelay: 10, hoverDelayDefault: 10 }
	}
	theplot = $.plot($('#plotarea'), data, options);


	previousPoint = null
	$("#plotarea").unbind("plothover plotclick", null);
	$("#plotarea").bind("plothover", plotHoverCallback);
	$("#plotarea").bind("plotclick", plotClickCallback);
	itemEnergy = {datapoint:A[0]}
	setTimeout('plotClickCallback(null,null,itemEnergy)',100);
	iamready = true;

}

//This prin the graph of the gradient
function plotGradient( a, b, c, d){

	// setImage()
	var data = [];
	            var A = [];
	                     var nplots = 1;
	                     var modelCount = Info.length;
	                     var stringa = Info[3].name;

	if(flagCryVasp  && !flagOutcar && !flagGauss  && !flagGulp && !flagCast ){
		if(stringa.search(/Energy/i) != -1){

			for (var i = 0; i < (modelCount - 1); i++) {
				var modelnumber = 0 + Info[i].modelNumber;
				// This is if is to check if we are dealing with an optimization
				// or
				// a
				// frequency calculation
				var last = modelCount - 1;

				if(i > 0 && i < Info.length)
					var previous = i - 1 ;

				if((i == 0 && Info[i].name != null) ||
						(i > 0 && Info[i - 1].name == null &&  Info[i].name != null))
					var  maxGra = parseFloat(Info[i].atomProperties.maxGradient) ;

				if((Info[i].name != null) && (previous > 0) ){
					if (substringEnergyToFloat(Info[i].name) != substringEnergyToFloat(Info[i - 1].name))
						var maxGra = parseFloat(Info[i].atomProperties.maxGradient);

				}


				var label = 'Model = ' + modelnumber
				+ ', ForceMAX = ' + maxGra;
				A.push([i+1,maxGra,modelnumber,label]);
			}
		}
	
	data.push(A);
	var options = {
		lines: { show: true },
		points: {show: true, fill: true},
		xaxis: { ticks: 8, tickDecimals: 0 },
		yaxis: { ticks: 6,tickDecimals: 5 },
		selection: { mode: (nplots == 1 ? "x" : "xy"), hoverMode: (nplots == 1 ? "x" : "xy") },
		grid: { hoverable: true, clickable: true, hoverDelay: 10, hoverDelayDefault: 10 }
		// hoverMode, hoverDelay, and hoverDelayDefault are not in the original
		// Flot package
	}
	theplot = $.plot($("#plotarea1"), data, options);

	previousPointForce = null
	$("#plotarea1").unbind("plothover plotclick", null);
	$("#plotarea1").bind("plothover", plotHoverCallbackforce);
	$("#plotarea1").bind("plotclick", plotClickCallbackForce);
	itemForce = {datapoint:A[0]}
	setTimeout('plotClickCallbackForce(null,null,itemForce)',100);
	iamready = true;
	}

}

var nullValues;
//This print the IR spectrum
function plotFrequencies(a, b, c, d){
	var data = [];
	var data2 =[];
	var A = [];
	var B =[];
	var nplots = 1;
	var modelCount = Info.length;
	var irFreq ;
	var irInt ;
	var ramanFreq;
	var ramanInt;
	var stringa = Info[4].name;
	
	if(flagCryVasp  && !flagOutcar){
		//This for crystal frequencies after geometry optimizations
		
		if(counterFreq != 0){
			stringa = Info[counterFreq + 1].name;
			if (stringa == null)
				stringa = Info[counterFreq + 2].name;
		}
		
		// This is a frequency calculation
		if(stringa.search(/Energy/i) == -1){
			nullValues = countNullModel(Info);
			var index = 0;
			if(counterFreq != 0)
				index = counterFreq +1;
			
			for (var i = index; i < (modelCount); i++) {
				//var modelnumber = Info[i].modelNumber - nullValues -1 ;
				// changed by Piero Sat Sep 20 09:25:18 EDT 2014
				var modelnumber = Info[i].modelNumber - nullValues -1 ;
				
				var last = modelCount - 1;
				
				if(i > 0 && i < Info.length)
					var previous = i - 1 ;

				if((i == 0 && Info[i].name != null) ||
						(i > 0 && Info[i - 1].name == null &&  Info[i].name != null)){
					var  freqValue = substringFreqToFloat(Info[i].modelProperties.Frequency) ;
					var  intValue = substringIntFreqToFloat(Info[i].modelProperties.IRintensity) ;
					
					if(intValue != 0)  {
						var irFreq = substringFreqToFloat(Info[i].modelProperties.Frequency);
						var irInt = substringIntFreqToFloat(Info[i].modelProperties.IRintensity);
						if(Info[i].modelProperties.Ramanactivity == "A"){ // This
							// is if
							// the frequency
							// is both raman
							// and IR active
							var ramanFreq =  substringFreqToFloat(Info[i].modelProperties.Frequency);
							var ramanInt = [100];
						}
					} else {
						var ramanFreq =  substringFreqToFloat(Info[i].modelProperties.Frequency);
						var ramanInt = [100];
					}
				}

				if((Info[i].name != null) && (previous > 0) ){
					if (substringEnergyToFloat(Info[i].name) != substringEnergyToFloat(Info[i - 1].name))
						var freqValue = substringFreqToFloat(Info[i].modelProperties.Frequency);
					var intValue = substringIntFreqToFloat(Info[i].modelProperties.IRintensity); 
					if(intValue != 0){
						var irFreq = substringFreqToFloat(Info[i].modelProperties.Frequency);
						var irInt = substringIntFreqToFloat(Info[i].modelProperties.IRintensity);
						if(Info[i].modelProperties.Ramanactivity == "A"){ 
							// This is when
							// the frequency
							// is both raman
							// and IR active
							var ramanFreq =  substringFreqToFloat(Info[i].modelProperties.Frequency);
							var ramanInt = [100];
						}
					} else {
						var ramanFreq =  substringFreqToFloat(Info[i].modelProperties.Frequency);
						var ramanInt = [100];
					}
				}

				var labelIr = 'Model = Frequency ' +   irFreq  + ', Intensity = ' + irInt + ' kmMol^-1';
				var labelRaman = 'Model = Frequency ' +   ramanFreq  + ', Intensity = ' + ramanInt + ' kmMol^-1';
				A.push([irFreq,irInt,modelnumber,labelIr]);
				B.push([ramanFreq,ramanInt,modelnumber,labelRaman]);
			}
			
		}




	} else if (!flagCryVasp && flagOutcar) {
		
		stringa = Info[4].name
		
		if(counterFreq != 0){
			stringa = Info[counterFreq + 1].name;
			if (stringa == null)
				stringa = Info[counterFreq + 2].name;
		}
		
		if(stringa.search(/G =/i) == -1){
			nullValues = countNullModel(Info);
		}
		
		for (var i = 0; i < freqData.length ; i++) {
			// freqData array defined in crystalfunction
			if(Info[i].name != null){
				var irFreq = substringFreqToFloat(freqData[i]);
				// alert(irFreq);
				var irInt = [0.00];
				var ramanFreq = [0.00];
				var ramanInt = [0.00];
				// Piero last modified Sat Sep 20 10:38:00 EDT 2014
				var modelnumber = Info[i].modelNumber + counterFreq  - nullValues -1 
				var labelIr = 'Model = Frequency ' +   irFreq  + ', Intensity = ' + irInt + ' kmMol^-1';
				// var labelRaman = 'Model = Frequency ' + ramanFreq + ',
				// Intensity
				// = ' + ramanInt + ' km/Mol';
				// alert("counterfreq" + counterFreq)
				A.push([irFreq,irInt,modelnumber,labelIr]);
				// B.push([ramanFreq,ramanInt,modelnumber,labelRaman]);
			}
		}
	}else if (!flagCryVasp && flagGauss){
		for (var i = 0; i < freqGauss.length ; i++) {
			// freqData array defined in crystalfunction
			if(Info[i].name != null){
				var irFreq = substringFreqToFloat(freqGauss[i]);
				// alert(irFreq);
				var irInt = substringIntGaussToFloat(freqIntensGauss[i]);
				var ramanFreq = [0.00];
				var ramanInt = [0.00];
				var modelnumber = counterGauss + i; 
				var labelIr = 'Model = Frequency ' +   irFreq  + ', Intensity = ' + irInt + ' kmMol^-1';
				// var labelRaman = 'Model = Frequency ' + ramanFreq + ',
				// Intensity
				// = ' + ramanInt + ' km/Mol';
				A.push([irFreq,irInt,modelnumber,labelIr]);
				// B.push([ramanFreq,ramanInt,modelnumber,labelRaman]);
			}
		}
	}

	// data.push(A)
	// data.push(B)

	var options = {
			lines: { show: false },
			points: {show: true, fill: true},
			xaxis: { ticks: 8, tickDecimals: 0 },
			yaxis: { ticks: 6,tickDecimals: 0 },
			selection: { mode: (nplots == 1 ? "x" : "xy"), hoverMode: (nplots == 1 ? "x" : "xy") },
			grid: { 
				hoverable: true, 
				clickable: true, 
				hoverDelay: 10, 
				hoverDelayDefault: 10
			}
	}

	if(flagCryVasp  && !flagOutcar  && !flagGauss){
		theplot = $.plot($("#plotareafreq"), [{label:"IR", data: A}, {label:"Raman", data: B}] , options)
	} else if((!flagCryVasp  && flagOutcar)  || (!flagCryVasp  && flagGauss) ){
		theplot = $.plot($("#plotareafreq"), [{label:"IR-Raman", data: A}], options)
	}

	previousPointFreq = null;

	$("#plotareafreq").unbind("plothover plotclick", null)
	$("#plotareafreq").bind("plothover", plotHoverCallbackFreq);
	$("#plotareafreq").bind("plotclick", plotClickCallbackFreq);
	itemFreq = {datapoint:A[0]}
	setTimeout('plotClickCallbackFreq(null,null,itemFreq)',100);
	iamready = true;
}


function plotClickCallback(event, pos, itemEnergy) {

	if (!itemEnergy)return
	var model = itemEnergy.datapoint[2];
	var label = itemEnergy.datapoint[3];
	runJmolScriptAndWait('model '+ model);
	// This select the element from the list of the geometry models
	// +1 keeps the right numeration of models
	getbyID('geom').value = model + 1 ;

}

function plotClickCallbackForce(event, pos, itemForce) {

	if (!itemForce)return
	var model = itemForce.datapoint[2];
	var label = itemForce.datapoint[3];
	runJmolScriptAndWait('model '+model);
	// This select the element from the list of the geometry models
	// +1 keeps the right numeration of models
	getbyID('geom').value = model + 1 ;

}


function plotHoverCallback(event, pos, itemEnergy) {
	if(!itemEnergy)return
	if (previousPoint != itemEnergy.datapoint) {
		$("#tooltip").remove();
		previousPoint = itemEnergy.datapoint  ;
		var y = roundoff(itemEnergy.datapoint[1],4);
		var model = itemEnergy.datapoint[2];
		var label = "&nbsp;&nbsp;Model "+ model + ", &#916 E = " + y +" kJmol^-1";
		showTooltip(itemEnergy.pageX, itemEnergy.pageY + 10, label, pos)
	}

	if (pos.canvasY > 350)plotClickCallback(event, pos, itemEnergy);


}


function plotHoverCallbackforce(event, pos, itemForce) {
	if(!itemForce)return
	if (previousPointForce != itemForce.datapoint) {
		$("#tooltip").remove();
		previousPointForce = itemForce.datapoint;
		var y = roundoff(itemForce.datapoint[1],6);
		var model = itemForce.datapoint[2];
		var label = "&nbsp;&nbsp;Model "+ model + ", MAX Force = " + y ;
		showTooltipForce(itemForce.pageX, itemForce.pageY + 10, label, pos);
	}

	if (pos.canvasY > 350)plotClickCallback(event, pos, itemForce);


}

function showTooltip(x, y, contents, pos) {

	if (pos.canvasY > 340) y += (340 - pos.canvasY)
	$('<div id="tooltip">' + contents + '</div>').css( {
		position: 'absolute',
		display: 'none',
		top: y + 5,
		left: x + 5,
		border: '1px solid #fdd',
		padding: '2px',
		'background-color': '#6a86c4',
		'color': '#FFFFCC',
		'font-weight': 'bold',
		opacity: 0.80
	}).appendTo("body").fadeIn(200);

}

function showTooltipForce(x, y, contents, pos) {

	if (pos.canvasY > 340) y += (340 - pos.canvasY);
	$('<div id="tooltip">' + contents + '</div>').css( {
		position: 'absolute',
		display: 'none',
		top: y + 5,
		left: x + 5,
		border: '1px solid #fdd',
		padding: '2px',
		'background-color': '#6a86c4',
		'color': '#FFFFCC',
		'font-weight': 'bold',
		opacity: 0.80
	}).appendTo("body").fadeIn(200);

}

function plotClickCallbackFreq(event, pos, itemFreq) {

	if (!itemFreq) return
	var model = itemFreq.datapoint[2];
	var label = itemFreq.datapoint[3];
	// loadAllFreq();
	var vibrationProp = 'vibration on; ' +  getValue("vecscale") + '; '+ getValue("vectors") + ';  '+ getValue("vecsamplitude") ; 
	if (flagCryVasp && !flagOutcar && !flagGauss){
		// Last Changed Thu Jul  3 08:37:51 AST 2014 //counterFreq
		var script = ' model '+ (model + nullValues ) +  '; ' + vibrationProp ;  // 'set
		if(counterFreq != 0)
			// Last Changed Thu Jul  3 08:37:51 AST 2014
			var script = ' model '+ (model + nullValues +1 ) +  '; ' + vibrationProp ;  // 'set
	}else{
		var script = ' model '+ ( model + 1 ) +  '; ' + vibrationProp ;  // 'set
	}
	runJmolScriptAndWait(script);
	onClickVibrate("on");
	// This select the element from the list of the geometry models
	// +1 keeps the right numeration of models
	if(counterFreq != 0 && (flagCryVasp && !flagOutcar && !flagGauss)){
		//getbyID('vib').value = model + counterFreq - nullValues - 1;
		// Last Changed Thu Jul  3 08:37:51 AST 2014
		getbyID('vib').value = model + counterFreq - nullValues  ;
	}else {
		getbyID('vib').value = model + 1;
	}

}

function plotHoverCallbackFreq(event, pos, itemFreq) {
	if(!itemFreq)return
	if (previousPointFreq != itemFreq.datapoint) {
		$("#tooltip").remove();
		previousPointFreq = itemFreq.datapoint  ;
		var x = roundoff(itemFreq.datapoint[0],2);
		var y = roundoff(itemFreq.datapoint[1],1);
		var model = itemFreq.datapoint[2];
		if (flagCryVasp && !flagOutcar && !flagGauss){
			var label = "&nbsp;&nbsp;Model "+ (model + 3 + nullValues)+ ", Freq (cm^-1) " + x + ", Int. (kmMol^-1) " + y ;
			
			if(counterFreq != 0)
				label = "&nbsp;&nbsp;Model "+ (model - counterFreq + nullValues+1) + ", Freq (cm^-1) " + x + ", Int. (kmMol^-1) " + y ;
				
		}else{
			var label = "&nbsp;&nbsp;Model "+ (model)  + ", Freq (cm^-1) " + x + ", Int. (kmMol^-1) " + y ;
		}
		showTooltipFreq(itemFreq.pageX, itemFreq.pageY + 10, label, pos);
	}

	if (pos.canvasY > 350)plotClickCallback(event, pos, itemFreq);

}

function showTooltipFreq(x, y, contents, pos) {

	if (pos.canvasY > 340) y += (340 - pos.canvasY);
	$('<div id="tooltip">' + contents + '</div>').css( 
	{
		position: 'absolute',
		display: 'none',
		top: y + 5,
		left: x + 5,
		border: '1px solid #fdd',
		padding: '2px',
		'background-color': '#6a86c4',
		'color': '#FFFFCC',
		'font-weight': 'bold',
		opacity: 0.80}
	).appendTo("body").fadeIn(200);

}

function jmolLoadStructCallback() {
	setTimeout('doPlot()');
}

//code that fakes an applet print by creating an image in its place! :)

function setImage() {
	if (appletPrintable)return
	var image = jmolGetPropertyAsString("image")
	var html = '<img src="data:image/jpeg;base64,'+image+'" />'
	getbyID("imagediv").innerHTML = html
}

var iamready = false;

function doHighlight(app, modelIndex) {
	if (!iamready)return;
	theplot.unhighlight(0,-1)
	theplot.highlight(0, modelIndex);
	var label = data[0][modelIndex][3];
        setTimeout('runJmolScript("set echo top left; echo ' + label+'")',100);
}


function doPrintAll() {
	setImage()
	window.print()
}
      		
///js// Js/sliders.js /////
/*  J-ICE library 

    based on: A toolkit for publishing enhanced figures; B. McMahon and R. M. Hanson; J. Appl. Cryst. (2008). 41, 811-814
 *
 *  Copyright (C) 2010-2014 Pieremanuele Canepa http://j-ice.sourceforge.net/
 *
 *  Contact: pierocanepa@sourceforge.net
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA
 *  02111-1307  USA.
 */

function applyBond(x) {
	if (firstTimeBond) {
		setV("wireframe .2;");
	} else {
		setV("wireframe " + (x / 100) + ";");
		getbyID('bondMsg').innerHTML = parseFloat(x / 100)
		.toPrecision(1)
		+ " &#197";
		setV("save BONDS bondEdit");
	}
}

function applyRadii(x) {
	setV("cpk " + x + " %;");
	getbyID('radiiMsg').innerHTML = parseFloat(x)
	.toPrecision(2)
	+ " %"
}

function applyConnect(x) {
	if (firstTime) {
		setV("connect (*) (*) DELETE; connect 2.0 (*) (*) single ModifyOrCreate;");
	} else {
		var flagBond = checkBoxX("allBondconnect");
		// alert(flagBond);
		// alert(frameNum);
		if (frameNum == null || frameNum == '') {
			getUnitcell("1");
			frameNum = 1.1;
		} else {

		}
		if (flagBond == 'off') {
			setV("select " + frameNum
					+ "; connect  (selected) (selected)  DELETE");
			setV("connect " + parseFloat(x / 20)
					+ " (selected) (selected) single ModifyOrCreate;");
		} else {
			setV("connect (*) (*) DELETE; connect " + parseFloat(x / 20.0)
					+ " (*) (*) single ModifyOrCreate;");
		}
		setV("save BONDS bondEdit");
	}
	getbyID('radiiConnectMsg').innerHTML = " "
		+ parseFloat(x / 20.0).toPrecision(2) + " &#197";
}

function applyTrans(x) {
	var dull = parseFloat(x);
	setV("color " + getValueSel("setFashion") + " TRANSLUCENT " + dull + ";");
	getbyID('transMsg').innerHTML = x + " %"
}

function applyPack(x) {
	packRange = parseFloat(x / 20.0).toPrecision(2);
	setPackRange();
	getbyID("packMsg").innerHTML = packRange + " &#197";
}

function applyPers(x) {
	var perp = x / 25;
	setV("set cameraDepth " + perp + ";")
	getbyID("perspMsg").innerHTML = perp
}

function applyLight1(x) {
	setV(" set specularPercent " + x + ";");
	getbyID("light1Msg").innerHTML = x + "%";
}

function applyLight2(x) {
	setV(" set ambient " + x + ";");
	getbyID("light2Msg").innerHTML = x + "%";
}

function applyLight3(x) {
	setV(" set diffusePercent " + x + ";");
	getbyID("light3Msg").innerHTML = x + "%";
}

var defaultFront = 20, defaultBack = 100;

function applySlab(x) {
	getbyID('slabSliderMsg').innerHTML = x + "%" // display
	// 0% for
	// frontplane,
	// 100% for
	// backplane:
	runJmolScript("slab " + (100 - x) + ";")
}

function applyDepth(x) { // alternative displays:
	// getbyID('backValue').innerHTML = x + "%" // 0% for
	// frontplane, 100% for backplane
	getbyID('depthSliderMsg').innerHTML = (100 - x) + "%" // 100%
	// for
	// frontplane,
	// 0%
	// for
	// backplane
	runJmolScript("depth " + (100 - x) + ";")
}

function toggleSlab() {
	var ctl = getbyID("slabToggle")
	if (ctl.checked) {
		setV("spin off; slab on; slab 80;");
		slabSlider.setValue(20);
		applySlab(defaultFront);
		depthSlider.setValue(defaultBack);
		applyDepth(defaultBack);
	} else {
		setV("slab off; ")
		slabSlider.setValue(0);
		depthSlider.setValue(0);
	}
}

loadSliders = function() {

	bondSlider = new Slider(getbyID("bondSlider-div"), getbyID("bondSlider-input"), "horizontal");
	bondSlider.setMaximum(100);
	//does not work with values < 1
	bondSlider.setMinimum(0);
	bondSlider.setUnitIncrement(5);
	//amount to increment the value when using the arrow keys
	bondSlider.setValue(15);
	bondSlider.onchange = function() { // onchange MUST BE all lowercase
		applyBond(getbyID("bondSlider-input").value)
	}
	
	radiiSlider = new Slider(getbyID("radiiSlider-div"), getbyID("radiiSlider-input"), "horizontal");
	radiiSlider.setMaximum(100);
	//does not work with values < 1
	radiiSlider.setMinimum(0);
	radiiSlider.setUnitIncrement(5);
	//amount to increment the value when using the arrow keys
	radiiSlider.setValue(26);
	radiiSlider.onchange = function() { // onchange MUST BE all lowercase
		applyRadii(getbyID("radiiSlider-input").value)
	}
	
	radiiConnect = new Slider(getbyID("radiiConnect-div"), getbyID("radiiConnect-input"), "horizontal");
	radiiConnect.setMaximum(100);
	//does not work with values < 1
	radiiConnect.setMinimum(0);
	radiiConnect.setUnitIncrement(1);
	//amount to increment the value when using the arrow keys
	radiiConnect.setValue(80);
	radiiConnect.onchange = function() { // onchange MUST BE all lowercase
		applyConnect(getbyID("radiiConnect-input").value)
	}
	
	transSlider = new Slider(getbyID("transSlider-div"), getbyID("transSlider-input"), "horizontal");
	transSlider.setMaximum(100);
	//does not work with values < 1
	transSlider.setMinimum(0);
	transSlider.setUnitIncrement(4);
	//amount to increment the value when using the arrow keys
	transSlider.setValue(100);
	transSlider.onchange = function() { // onchange MUST BE all lowercase
		applyTrans(getbyID("transSlider-input").value)
	}
	
	packSlider = new Slider(getbyID("packSlider-div"), getbyID("packSlider-input"), "horizontal");
	packSlider.setMaximum(100);
	//does not work with values < 1
	packSlider.setMinimum(0);
	packSlider.setUnitIncrement(0.5);
	//amount to increment the value when using the arrow keys
	packSlider.setValue(10);
	packSlider.onchange = function() { // onchange MUST BE all lowercase
		applyPack(getbyID("packSlider-input").value)
	}
	
	persSlider = new Slider(getbyID("persSlider-div"), getbyID("persSlider-input"), "horizontal");
	persSlider.setMaximum(100);
	//does not work with values < 1
	persSlider.setMinimum(0);
	persSlider.setUnitIncrement(2);
	//amount to increment the value when using the arrow keys
	persSlider.setValue(5);
	persSlider.onchange = function() { // onchange MUST BE all lowercase
		applyPers(getbyID("persSlider-input").value)
	}
	
	light1Slider = new Slider(getbyID("light1Slider-div"), getbyID("light1Slider-input"), "horizontal");
	light1Slider.setMaximum(100);
	//does not work with values < 1
	light1Slider.setMinimum(0);
	light1Slider.setUnitIncrement(2);
	//amount to increment the value when using the arrow keys
	light1Slider.setValue(5);
	light1Slider.onchange = function() { // onchange MUST BE all lowercase
		applyLight1(getbyID("light1Slider-input").value)
	}
	
	light2Slider = new Slider(getbyID("light2Slider-div"), getbyID("light2Slider-input"), "horizontal");
	light2Slider.setMaximum(100);
	//does not work with values < 1
	light2Slider.setMinimum(0);
	light2Slider.setUnitIncrement(2);
	//amount to increment the value when using the arrow keys
	light2Slider.setValue(5);
	light2Slider.onchange = function() { // onchange MUST BE all lowercase
		applyLight2(getbyID("light2Slider-input").value)
	}
	
	light3Slider = new Slider(getbyID("light3Slider-div"), getbyID("light3Slider-input"), "horizontal");
	light3Slider.setMaximum(100);
	//does not work with values < 1
	light3Slider.setMinimum(0);
	light3Slider.setUnitIncrement(2);
	//amount to increment the value when using the arrow keys
	light3Slider.setValue(5);
	light3Slider.onchange = function() { // onchange MUST BE all lowercase
		applyLight3(getbyID("light3Slider-input").value)
	}
	
	slabSlider = new Slider(getbyID("slabSlider-div"), getbyID("slabSlider-input"), "horizontal");
	slabSlider.setMaximum(100)
	slabSlider.setMinimum(0)
	slabSlider.setUnitIncrement(2) // amount to increment the value when using the
	// arrow keys
	slabSlider.setValue(defaultFront)
	slabSlider.onchange = function() { // onchange MUST BE all lowercase
		applySlab(getbyID("slabSlider-input").value)
	}
	
	depthSlider = new Slider(getbyID("depthSlider-div"), getbyID("depthSlider-input"), "horizontal");
	depthSlider.setMaximum(100);
	depthSlider.setMinimum(0);
	depthSlider.setUnitIncrement(2); // amount to increment the value when using
	// the arrow keys
	depthSlider.setValue(defaultBack);
	depthSlider.onchange = function() { // onchange MUST BE all lowercase
		applyDepth(getbyID("depthSlider-input").value)
	}
}

      		
///js// Js/freqhtml.js /////
/*  J-ICE library 

    based on:
 *
 *  Copyright (C) 2010-2014 Pieremanuele Canepa http://j-ice.sourceforge.net/
 *
 *  Contact: pierocanepa@sourceforge.net
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA
 *  02111-1307  USA.
 */

//Last Modified 5nd 03 2011
function createHTML() {
	var stringWebPage;

	initialMessages();
	createTitle();
	createAuthors();
	saveOutputFreq();
	saveOutputStatefreq();

	// <HTML>

	stringWebPage = 'var webpage = \" ' + createTag("HTML", "", "", false);

	// <HEAD>
	stringWebPage += createTag("HEAD", "", "", false);

	// <Title>
	stringWebPage += createTag("title", "", namePage, true);

	// Here goes the Java script tab
	// <script language="JavaScript" type="text/javascript">
	stringWebPage += "<script  src='jmol/Jmol.js'></script>\n";

	// / this defines the style
	stringWebPage += createTag("link",
			"rel=\'stylesheet\' href=\'style.css\' type=\'text\/css\'", "",
			false);

	// <style type="text/css">
	stringWebPage += createTag("style", "type='text/css'", "", false);

	stringWebPage += createSaveStyle();

	// </style>
	stringWebPage += closeTag("style");

	stringWebPage += "\n <script language='JavaScript'>";

	stringWebPage += "\n function activateVib(){ \n if(document.butopt.vibration.checked){ \n runJmolScript(\' select all;vibration On; vibration scale 7;\') \n}else{ runJmolScript(\' vibration off\') \n} \n\n }";
	stringWebPage += "\n function vectorsOn(){ \n if(document.butopt.vectors.checked){ \n runJmolScript(\' select all;vectors on;color vector yellow;vector scale 14;vector 0.08;\') \n} else{ runJmolScript(\'vector off\') \n} } \n\n";
	stringWebPage += "\n function cellOn(){ \n if(document.butopt.cell.checked){ \n runJmolScript(\' unitcell on \') \n} else{ runJmolScript(\'unitcell off\') \n} \n}\n\n";
	stringWebPage += "\n  function perspOn(){ \n if(document.butopt.persp.checked){ \n runJmolScript(\' set perspectiveDepth on \') \n} else{ runJmolScript(\'set perspectiveDepth off\') \n} \n} \n\n";
	stringWebPage += "\n function polyOn(){ \n  if(document.butopt.poly.checked){ \n runJmolScript(\' polyhedra on;\') \n} else{ \n runJmolScript(\' polyhedra off; \') \n } \n} \n\n";
	stringWebPage += "\n function persptraspOn(){ \n if(document.butopt.polytrans.checked){ \n runJmolScript(\'select *; color polyhedra translucent orange; \') \n }else{ \n runJmolScript(\'select *; color polyhedra opaque orange; \') \n  } \n } \n\n";
	stringWebPage += "\n function sbOn(){ \n  runJmolScript(\' wireframe 0.15;spacefill 20%;cartoon off;backbone off; draw off ;\')  \n} \n\n";
	stringWebPage += "\n function sOn(){ \n  runJmolScript(\' wireframe 0.15;spacefill 0%;cartoon off;backbone off; draw off ;\')  \n} \n\n";
	stringWebPage += "\n function bOn(){ \n  runJmolScript(\' select *; spacefill 20%; wireframe off ; draw of ;\')  \n} \n\n";
	stringWebPage += "\n function cpkOn(){ \n  runJmolScript(\' wireframe 0.30;spacefill 100%;cartoon off;backbone off; draw off\')  \n} \n\n";
	stringWebPage += "\n function wifiOn(){ \n if(document.butopt.wifi.checked){ \n runJmolScript(\'select *; wireframe .05;\') \n }else{ \n runJmolScript(\'select *; wireframe 0;\') \n  } \n } \n\n";
	// += "\n function bondOn(){ \n if(document.butopt.wifi.checked){ \n
	// runJmolScript(\'select *; wireframe .05;\') \n }else{ \n runJmolScript(\'select
	// *; wireframe 0;\') \n } \n } \n\n";
	stringWebPage += "\n function showFrame(i){ \n runJmolScript(\'frame \' + i); \n  runJmolScript('select all;vibration On; vibration scale 7;');}";
	stringWebPage += "\n </script>";
	// Close Head
	stringWebPage += closeTag("HEAD");

	// Open body
	stringWebPage += createTag("BODY", "", "", false);
	// ////////////Here goes the HTML content

	// / Create main <div> id whole
	stringWebPage += createTag("div", "id=\'whole\'", "", false);

	stringWebPage += createTag("div", "id=\'middle\'", "", false);

	stringWebPage += createTag("div", "class=\'title\'", "", false);
	stringWebPage += createTag("H2", "", authorPage, true);
	stringWebPage += createTag("H1", "", namePage, true);
	stringWebPage += closeTag("div");

	// div lateral frame
	stringWebPage += createTag("div", "class=\'leftframe\'", "", false);

	stringWebPage += "<form name='butopt'>";
	/*
	 * //<table> stringWebPage += createTag("table", "" , "", false)
	 * stringWebPage += createTag("tr", "", "", false); stringWebPage +=
	 * createTag("td", "", "", false);
	 */

	stringWebPage += closeTag("td");
	stringWebPage += createTag("td", "", "", false);
	stringWebPage += "<select id='vib' name='models' OnClick='showFrame(value)' class='selectmodels' size='15' style='width:280px; overflow: auto;'>";
	for (i = 0; i < freqData.length + 1; i++)
		if (freqData[i] != null || freqData[i] != ""
			|| freqData[i] == "undefined") {
			stringWebPage += createTag("option", "value='"
					+ (i + counterFreq + 1) + "' id='" + (i + counterFreq)
					+ "' name='" + (i + counterFreq + 1) + "'", freqData[i],
					true);
		}
	stringWebPage += "</select>";
	/*
	 * stringWebPage += closeTag("td"); stringWebPage += closeTag("tr");
	 * stringWebPage += closeTag("table");
	 */
	stringWebPage += "<br><br> ";
	stringWebPage += "Vibration <br>";

	stringWebPage += "<input type='checkbox' name='vibration'  checked  OnClick='activateVib()'>Animation";
	stringWebPage += "<input type='checkbox' name='vectors'  checked  OnClick='vectorsOn()'>Vectors <br>";
	stringWebPage += "<br>View <br>";
	stringWebPage += "<input type='checkbox' name='cell' checked   OnClick='cellOn()'>Cell";
	stringWebPage += "<input type='checkbox' name='persp'    OnClick='perspOn()'>Perspective <br>";
	stringWebPage += "<br>Polyhedron<br>";
	stringWebPage += "<input type='checkbox' name='poly'    OnClick='polyOn()'>active";
	stringWebPage += "<input type='checkbox' name='polytrans'    OnClick='persptraspOn()'>translucency <br>";
	stringWebPage += "<br>Atom and bond style<br>";
	stringWebPage += "<input type='button' name='sb'  value='S&B'  OnClick='sbOn()'> ";
	stringWebPage += "<input type='button' name='s' value='Stick'   OnClick='sOn()'> ";
	stringWebPage += "<input type='button' name='b' value='Ball'   OnClick='bOn()'> ";
	stringWebPage += "<input type='button' name='cpk' value='CPK'   OnClick='cpkOn()'> <br>";
	stringWebPage += "<input type='checkbox' name='wifi'    OnClick='wifiOn()'>Wireframe <br><br>";
	stringWebPage += " ";
	stringWebPage += "</form>";

	// close div lateral
	stringWebPage += closeTag("div");

	// create jmol tag
	stringWebPage += createTag("div", "class=\'japplet\' ", "", false);

	stringWebPage += "<script>"

		stringWebPage += '\n jmolInitialize\(\'.\', \'jmol/JmolAppletSigned0.jar\'\) ; \n'; // To
	// change
	// to
	// propper
	// java
	stringWebPage += '\njmolApplet\(\[ \'430\', \'430\'\],\'load output.dat; script current.spt; select all;vibration On; vibration scale 7; vectors on;color vector yellow;vector scale 14;vector 0.08;\'\) ; \n';

	// </script> jmol
	stringWebPage += closeTag("script");

	// close jmol tag
	stringWebPage += closeTag("div");

	// close middle tag
	stringWebPage += closeTag("div");

	// Close whole dive
	stringWebPage += closeTag("div");

	// //////////Here stops html
	// Close body
	stringWebPage += closeTag("BODY");
	// Close HTML </HTML>
	stringWebPage += closeTag("HTML");

	stringWebPage += '\"; write VAR webpage "?webpage.html"';
	// alert(stringWebPage)
	saveHtml(stringWebPage);

}

///Save the page
function saveHtml(stringWeb) {
	runJmolScript(stringWeb);
}

/// Example <title>kaolinite vibration modes</title>
//tagName = title

function createTag(tagName, tagOptions, tagCont, tagClosure) {
	var newTag;
	if (tagClosure) {
		newTag = " \n <" + tagName + " " + tagOptions + " >" + tagCont + "</"
		+ tagName + ">\n";
	} else {
		newTag = "\n <" + tagName + " " + tagOptions + ">\n"
	}

	return newTag;
}

function createTable(tableOptinos, tableClass, tagClose) {
	tagOptions = tableOptinos + " " + tableClass;
	if (tagClose) {
		createTag("Table", tagOptions, "", false);
	} else {
		closeTag("Table");
	}

}

function createRow(rowOptions, numColumn, colCont) {
	createTag("tr", rowOptions, "", false);
	for (i = 0; i < numColumn; i++) {
		createTag("td", "", colCont[i], true);
	}
	closeTag("tr")
}

function closeTag(tagName) {
	var oldTag = "\n </" + tagName + ">\n";
	return oldTag;
}

function initialMessages() {
	messageMsg("This function allows you to prepare HTML page showing frequencies. \n Follow the multi-step procedure!");
	messageMsg("Is it this one going to be the final look of your structure? \n Make sure it is.");
}

var namePage = "No title was given"
	function createTitle() {

	namePage = prompt("Please, enter the page title", " ");

	// /if(namePage == null)
	// /namePage = "No title was given"
}

var authorPage;
function createAuthors() {
	authorPage = prompt(
			"Please, enter Authors' names \n e.g.: E. Fermi, A. Einstein, etc.",
	"");
	authorPage = authorPage
	+ " "
	+ prompt(
			"Please, enter the pubblication details \n (e.g.:(1901), Annalen der Physik 4: 513.",
	"");

}

var outputNamefreq = null;
function saveOutputFreq() {
	messageMsg("Please save the output files as: output.dat. \n DON'T change its NAME");
	runJmolScript("write FILE ?output.dat");
}

function saveOutputStatefreq() {
	messageMsg("Now please save the file containing the style and orientation of your file; \n DON'T change its NAME");
	runJmolScript('write STATE LOCALPATH "." "current.spt"');
}

function createSaveStyle() {
	var styleStr;
	// messageMsg("Now save in the same directory of the index.html file. \n
	// Don't save its name.");
	styleStr = '*{ \n font-family: Arial, Helvetica, Verdana; \n font-size: 12px; \n} \n\n';
	styleStr += '#whole{ \n width: 800px; \n background-color: white; \n border:none; \n margin: 20px auto 20px auto; \n padding: 0px 20px 0 20px; \n } \n\n';
	styleStr += '#middle{ \n float:left; \n border: \n #E5E5E5 2px solid; width: 800px; \n } \n\n';
	styleStr += '.japplet {  \n border:none;  \n padding: 0px; \n margin: 0px; \n margin-left:370px; \n background-color: #fff; \n width:400px; } \n\n';
	styleStr += '.leftframe {  \n float:left; \n color:#3456f3; \n border:none; \n border-left:none; \n margin: 0px; \n min-height:400px; \n padding:10px; \n max-width:400px; \n} \n\n';
	styleStr += '.title{ \n margin-left:5px; padding:10px; \n } \n\n';
	styleStr += '.select, .selectmodels { \nborder: 1px solid #d8d8d8; \n padding: 0px; \n margin-top: 5px; \n overflow: hidden; \n } \n\n';
	styleStr += 'h1 { \n text-transform: uppercase; \n  color:black; font-family: Arial, Helvetica, Verdana; \n font-size: 16px;\n } \n\n';
	styleStr += 'h3 { \n text-transform: uppercase; \n } \n\n';
	styleStr += 'h2, h3, h4 { \n  \n  color:black; \n } \n\n';

	return styleStr;
	// alert(styleStr)
}
