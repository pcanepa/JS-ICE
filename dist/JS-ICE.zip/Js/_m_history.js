// not implemented

function enterHistory() {
	
}

function exitHistory() {
}

function createHistGrp() {
	var strHist = "<form autocomplete='nope'  id='HistoryGroup' name='HistoryGroup' style='display:none'>";
	strHist += "History<BR>\n";
	strHist += "Work in progress<BR>\n";
	strHist += "</form>";
	return strHist;
}


