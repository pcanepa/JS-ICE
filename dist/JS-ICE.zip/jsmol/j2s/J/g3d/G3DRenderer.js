Clazz.declarePackage ("J.g3d");
Clazz.declareInterface (J.g3d, "G3DRenderer");
