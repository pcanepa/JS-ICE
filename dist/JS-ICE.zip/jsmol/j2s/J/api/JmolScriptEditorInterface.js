Clazz.declarePackage ("J.api");
Clazz.load (["J.api.JmolDropEditor"], "J.api.JmolScriptEditorInterface", null, function () {
Clazz.declareInterface (J.api, "JmolScriptEditorInterface", J.api.JmolDropEditor);
});
