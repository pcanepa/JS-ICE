Clazz.declarePackage ("J.dssx");
c$ = Clazz.declareType (J.dssx, "DSSR0");
