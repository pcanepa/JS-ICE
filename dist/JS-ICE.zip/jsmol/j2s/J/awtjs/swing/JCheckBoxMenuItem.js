Clazz.declarePackage ("J.awtjs.swing");
Clazz.load (["J.awtjs.swing.JMenuItem"], "J.awtjs.swing.JCheckBoxMenuItem", null, function () {
c$ = Clazz.declareType (J.awtjs.swing, "JCheckBoxMenuItem", J.awtjs.swing.JMenuItem);
Clazz.makeConstructor (c$, 
function () {
Clazz.superConstructor (this, J.awtjs.swing.JCheckBoxMenuItem, ["chk", 2]);
});
});
