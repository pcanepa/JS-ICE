Clazz.declarePackage ("J.jvxl.api");
Clazz.load (["J.jvxl.api.VertexDataServer"], "J.jvxl.api.MeshDataServer", null, function () {
Clazz.declareInterface (J.jvxl.api, "MeshDataServer", J.jvxl.api.VertexDataServer);
});
